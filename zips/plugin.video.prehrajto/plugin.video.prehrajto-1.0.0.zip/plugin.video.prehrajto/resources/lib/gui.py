import re

import xbmcaddon
import xbmcgui

from resources.lib import scraper

_ADDON = xbmcaddon.Addon()
_FRAME_RE = re.compile(r"/\d+\.jpg$")


def _(sid):
    return _ADDON.getLocalizedString(sid)


def _result_label(result):
    if result.size:
        return result.title + "  •  " + result.size
    return result.title


def _fanart_from_thumb(thumb):
    if not thumb:
        return thumb
    return _FRAME_RE.sub("/8.jpg", thumb)


def make_video_item(result):
    li = xbmcgui.ListItem(label=_result_label(result))
    if result.thumb:
        li.setArt({"thumb": result.thumb,
                   "icon": result.thumb,
                   "poster": result.thumb,
                   "fanart": _fanart_from_thumb(result.thumb)})
    info = {"title": result.title, "mediatype": "video"}
    secs = scraper.duration_to_seconds(result.duration)
    if secs:
        info["duration"] = secs
    plot = []
    if result.size:
        plot.append(result.size)
    if result.likes:
        plot.append("%s: %s" % (_(30014), result.likes))
    if plot:
        info["plot"] = "  •  ".join(plot)
    li.setInfo("video", info)
    li.setProperty("IsPlayable", "true")
    return li


def make_folder_item(label):
    return xbmcgui.ListItem(label=label)
