import json
import os


class History:
    def __init__(self, path, limit=20):
        self._path = path
        self._limit = limit

    def _load(self):
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [x for x in data if isinstance(x, str)]
            return []
        except (OSError, ValueError):
            return []

    def recent(self):
        return self._load()

    def add(self, query):
        q = (query or "").strip()
        if not q:
            return
        items = [x for x in self._load() if x.lower() != q.lower()]
        items.insert(0, q)
        items = items[:self._limit]
        dirname = os.path.dirname(self._path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)

    def clear(self):
        try:
            os.remove(self._path)
        except OSError:
            pass


class EpisodeHistory:
    """Per-show record of the last-watched season/episode.

    Stored as a JSON list of {"show": str, "season": int, "episode": int},
    deduped by show (case-insensitive), most-recent-first, capped at `limit`.
    Tolerates a legacy string-list file by dropping non-record entries.
    """

    def __init__(self, path, limit=20):
        self._path = path
        self._limit = limit

    def _load(self):
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        records = []
        for item in data:
            if not isinstance(item, dict):
                continue
            show = item.get("show")
            if not isinstance(show, str) or not show:
                continue
            try:
                season = int(item.get("season"))
                episode = int(item.get("episode"))
            except (TypeError, ValueError):
                continue
            records.append({"show": show, "season": season, "episode": episode})
        return records

    def recent(self):
        return self._load()

    def add(self, show, season, episode):
        show = (show or "").strip()
        if not show:
            return
        try:
            season = int(season)
            episode = int(episode)
        except (TypeError, ValueError):
            return
        items = [r for r in self._load() if r["show"].lower() != show.lower()]
        items.insert(0, {"show": show, "season": season, "episode": episode})
        items = items[:self._limit]
        dirname = os.path.dirname(self._path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)

    def get(self, show):
        key = (show or "").strip().lower()
        for r in self._load():
            if r["show"].lower() == key:
                return r
        return None

    def clear(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
