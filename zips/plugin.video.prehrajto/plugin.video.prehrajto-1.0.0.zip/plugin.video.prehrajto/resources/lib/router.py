import os
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import gui, history, scraper

_ADDON = xbmcaddon.Addon()


def _(sid):
    return _ADDON.getLocalizedString(sid)


def _timeout():
    try:
        return int(float(_ADDON.getSetting("timeout")))
    except (ValueError, TypeError):
        return scraper.DEFAULT_TIMEOUT


def _history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.History(os.path.join(profile, "history.json"))


def _tv_history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.EpisodeHistory(os.path.join(profile, "tv_history.json"))


def _episode_query(show, season, episode):
    return "%s S%02dE%02d" % (show, int(season), int(episode))


def _compose_query(params):
    query = params.get("query", "")
    season = params.get("season")
    episode = params.get("episode")
    if season and episode:
        try:
            return _episode_query(query, season, episode)
        except (TypeError, ValueError):
            pass
    year = params.get("year")
    if year:
        return "%s %s" % (query, year)
    return query


def _episode_label(entry):
    return "%s  •  S%02dE%02d" % (entry["show"], entry["season"], entry["episode"])


def _notify(message):
    xbmcgui.Dialog().notification(_ADDON.getAddonInfo("name"), message)


def _prepare_subtitles(tracks):
    """Download subtitle tracks to the profile subs/ dir, named by label.
    Returns local file paths; skips any that fail to download/write."""
    if not tracks:
        return []
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subs")
    try:
        if os.path.isdir(subs_dir):
            for fname in os.listdir(subs_dir):
                try:
                    os.remove(os.path.join(subs_dir, fname))
                except OSError:
                    pass
        os.makedirs(subs_dir, exist_ok=True)
    except OSError:
        return []
    paths = []
    seen = set()
    for label, url in tracks:
        path = os.path.join(subs_dir, scraper.sanitize_filename(label) + ".vtt")
        if path in seen:
            continue
        try:
            data = scraper.download(url, _timeout())
        except Exception:
            continue
        try:
            with open(path, "wb") as f:
                f.write(data)
        except OSError:
            continue
        paths.append(path)
        seen.add(path)
    return paths


class Ctx:
    def __init__(self, base, handle):
        self.base = base
        self.handle = handle

    def url(self, **kwargs):
        return self.base + "?" + urllib.parse.urlencode(kwargs)


def show_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="movies_menu"),
        gui.make_folder_item(_(30015)), True)       # Movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_menu"),
        gui.make_folder_item(_(30016)), True)        # TV shows
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="install_tmdb_player"),
        gui.make_folder_item(_(30017)), True)        # Install TMDb Helper player
    xbmcplugin.endOfDirectory(ctx.handle)


def _install_player_file(src_path, dst_dir):
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, "prehrajto.json")
    with open(src_path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(data)
    return dst


def install_tmdb_player(ctx):
    src = os.path.join(_ADDON.getAddonInfo("path"),
                       "resources", "players", "prehrajto.json")
    dst_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.themoviedb.helper/players/")
    try:
        _install_player_file(src, dst_dir)
        _notify(_(30018))
    except OSError:
        _notify(_(30019))
    xbmc.executebuiltin("Container.Refresh")


def show_movies_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="search"),
        gui.make_folder_item(_(30001)), True)        # Search movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="history"),
        gui.make_folder_item(_(30002)), True)        # Recent movie searches
    xbmcplugin.endOfDirectory(ctx.handle)


def show_tv_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_search"),
        gui.make_folder_item(_(30010)), True)        # Search TV show
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_history"),
        gui.make_folder_item(_(30011)), True)        # Recent TV shows
    xbmcplugin.endOfDirectory(ctx.handle)


def do_search(ctx):
    query = (xbmcgui.Dialog().input(_(30005)) or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    _history().add(query)
    _go_to_results(ctx, query)


def _go_to_results(ctx, query):
    # End the transient dialog directory, then navigate to the idempotent
    # results directory (replacing the dialog step in history). This keeps the
    # results container dialog-free so returning from playback never re-prompts.
    xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
    xbmc.executebuiltin(
        "Container.Update(%s,replace)" % ctx.url(action="results", query=query))


def render_results(ctx, query, page):
    try:
        results, has_next = scraper.search(query, page, _timeout())
    except Exception:
        _notify(_(30007))
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    if not results and page == 1:
        _notify(_(30006))
    for r in results:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="play", path=r.path),
            gui.make_video_item(r), False)
    if has_next:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=query, page=page + 1),
            gui.make_folder_item(_(30004)), True)
    xbmcplugin.setContent(ctx.handle, "videos")
    xbmcplugin.endOfDirectory(ctx.handle)


def show_history(ctx):
    recent = _history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="history_clear"),
            gui.make_folder_item(_(30003)), True)
    for term in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=term, page=1),
            gui.make_folder_item(term), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_history(ctx):
    _history().clear()
    xbmc.executebuiltin("Container.Refresh")


def do_tv_search(ctx):
    show = (xbmcgui.Dialog().input(_(30010)) or "").strip()
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    pick_and_play_episode(ctx, show)


def pick_and_play_episode(ctx, show):
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    season = xbmcgui.Dialog().numeric(0, _(30012))   # Season (blank, not pre-filled)
    if not season:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    episode = xbmcgui.Dialog().numeric(0, _(30013))  # Episode (blank, not pre-filled)
    if not episode:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    _tv_history().add(show, season, episode)
    _go_to_results(ctx, _episode_query(show, season, episode))


def show_tv_history(ctx):
    recent = _tv_history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_history_clear"),
            gui.make_folder_item(_(30003)), True)
    for record in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_episode", show=record["show"]),
            gui.make_folder_item(_episode_label(record)), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_tv_history(ctx):
    _tv_history().clear()
    xbmc.executebuiltin("Container.Refresh")


def play(ctx, path):
    try:
        stream = scraper.resolve(path, _timeout())
    except Exception:
        stream = None
    if not stream or not stream.sources:
        _notify(_(30008))
        xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())
        return
    sources = stream.sources
    if len(sources) == 1:
        chosen = sources[0]
    else:
        labels = [label for label, _url in sources]
        index = xbmcgui.Dialog().select(_(30009), labels)
        if index < 0:                      # user cancelled
            xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())
            return
        chosen = sources[index]
    play_url = chosen[1] + "|User-Agent=" + urllib.parse.quote(scraper.USER_AGENT)
    li = xbmcgui.ListItem(path=play_url)
    subs = _prepare_subtitles(stream.subtitles)
    if subs:
        li.setSubtitles(subs)
    xbmcplugin.setResolvedUrl(ctx.handle, True, li)


def run(argv):
    base, handle, qs = argv[0], int(argv[1]), argv[2]
    params = dict(urllib.parse.parse_qsl(qs.lstrip("?")))
    ctx = Ctx(base, handle)
    action = params.get("action", "menu")
    if action == "search":
        do_search(ctx)
    elif action == "results":
        render_results(ctx, _compose_query(params),
                       int(params.get("page", "1")))
    elif action == "history":
        show_history(ctx)
    elif action == "history_clear":
        clear_history(ctx)
    elif action == "tv_search":
        do_tv_search(ctx)
    elif action == "tv_episode":
        pick_and_play_episode(ctx, params.get("show", ""))
    elif action == "tv_history":
        show_tv_history(ctx)
    elif action == "tv_history_clear":
        clear_tv_history(ctx)
    elif action == "play":
        play(ctx, params.get("path", ""))
    elif action == "movies_menu":
        show_movies_menu(ctx)
    elif action == "tv_menu":
        show_tv_menu(ctx)
    elif action == "install_tmdb_player":
        install_tmdb_player(ctx)
    else:
        show_menu(ctx)
