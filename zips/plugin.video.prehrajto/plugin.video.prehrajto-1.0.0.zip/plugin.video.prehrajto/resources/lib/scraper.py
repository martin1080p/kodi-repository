import html as html_mod
import re
import urllib.parse
import urllib.request
from collections import namedtuple

BASE_URL = "https://prehraj.to"
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
DEFAULT_TIMEOUT = 20

Result = namedtuple("Result", "path title thumb duration size likes")
Result.__new__.__defaults__ = ("",)  # likes is optional metadata
Stream = namedtuple("Stream", "sources subtitles")

_CARD_RE = re.compile(
    r'<a\b([^>]*?href="(/[^"]+/[0-9a-f]{16})"[^>]*?)>(.*?)</a>', re.S)
_TITLE_RE = re.compile(
    r'<h3[^>]*class="[^"]*video__title[^"]*"[^>]*>(.*?)</h3>', re.S)
_TITLE_ATTR_RE = re.compile(r'\btitle="([^"]*)"')
_TIME_RE = re.compile(r'video__tag--time[^"]*"[^>]*>\s*([0-9:]+)')
_SIZE_RE = re.compile(r'video__tag--size[^"]*"[^>]*>\s*([^<]+?)\s*<')
_THUMB_RE = re.compile(r'class="thumb thumb1"[^>]*src="([^"]+)"')
_LIKE_RE = re.compile(
    r'video__tag--like"[^>]*>[\s\S]*?</picture>\s*([0-9]+)', re.S)
_PAGE_RE = re.compile(r'visualPaginator-page=(\d+)')

# NOTE: assumes `file:` is followed by `label:` in that order within an
# entry object. This matches the current JWPlayer markup on the site; the
# VideoJS fallback block uses `src:`/`label:` (no `file:` key) and so never
# matches here, which is intentional.
_SRC_ENTRY_RE = re.compile(
    r'\{\s*file:\s*"([^"]+)"\s*,\s*label:\s*[\'"]([^\'"]+)[\'"]', re.S)
_TRACK_ENTRY_RE = re.compile(
    r'file:\s*"([^"]+)"[^}]*?label:\s*[\'"]([^\'"]+)[\'"]', re.S)


def _js_array_bodies(html, name):
    """Return the bodies (contents between [ and ]) of every JS array
    literal assigned to `name` in the page, e.g. `NAME = [ ... ];`.

    The detail page can contain more than one similarly-named block (the
    active JWPlayer block plus an inactive VideoJS fallback, or vice versa),
    so we must not assume the first match is the right one. Collecting all
    bodies lets the callers merge results and dedupe, making the extraction
    independent of which block happens to appear first in the HTML.
    """
    return re.compile(name + r"\s*=\s*\[(.*?)\]\s*;", re.S).findall(html)


def parse_results(html):
    results = []
    for m in _CARD_RE.finditer(html):
        attrs, path, inner = m.group(1), m.group(2), m.group(3)
        tm = _TITLE_RE.search(inner)
        if tm:
            title = html_mod.unescape(re.sub(r"<[^>]+>", "", tm.group(1))).strip()
        else:
            am = _TITLE_ATTR_RE.search(attrs)
            title = html_mod.unescape(am.group(1)).strip() if am else ""
        if not title:
            continue
        th = _THUMB_RE.search(inner)
        dm = _TIME_RE.search(inner)
        sm = _SIZE_RE.search(inner)
        lk = _LIKE_RE.search(inner)
        results.append(Result(
            path=path,
            title=title,
            thumb=th.group(1) if th else "",
            duration=dm.group(1) if dm else "",
            size=html_mod.unescape(sm.group(1)).strip() if sm else "",
            likes=lk.group(1) if lk else "",
        ))
    return results


def parse_has_next(html, page):
    pages = [int(p) for p in _PAGE_RE.findall(html)]
    return bool(pages) and max(pages) > int(page)


def duration_to_seconds(text):
    parts = (text or "").strip().split(":")
    if not parts or not all(p.isdigit() for p in parts):
        return 0
    secs = 0
    for p in parts:
        secs = secs * 60 + int(p)
    return secs


_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def sanitize_filename(label):
    # Whitespace must be collapsed *before* unsafe-char substitution: tab
    # (and other control chars) match both \s and \x00-\x1f, so replacing
    # unsafe chars first would turn a literal tab into "_" instead of " ".
    name = re.sub(r"\s+", " ", label or "").strip()
    name = _UNSAFE_FILENAME_RE.sub("_", name)
    return name[:100] or "subtitle"


def parse_sources(html):
    seen = set()
    result = []
    for body in _js_array_bodies(html, "sources"):
        for url, label in _SRC_ENTRY_RE.findall(body):
            if url not in seen:
                seen.add(url)
                result.append((label, url))
    return result


def parse_subtitles(html):
    seen = set()
    result = []
    for body in _js_array_bodies(html, "tracks"):
        for url, label in _TRACK_ENTRY_RE.findall(body):
            if url not in seen:
                seen.add(url)
                result.append((label, url))
    return result


def _quality_score(label):
    low = label.lower()
    digits = re.sub(r"\D", "", low)
    score = int(digits) if digits else 0
    if "k" in low:
        score *= 1000
    return score


def sort_sources(sources):
    """Return sources (list of (label, url)) sorted highest-quality-first."""
    return sorted(sources, key=lambda s: _quality_score(s[0]), reverse=True)


def parse_stream(html):
    sources = sort_sources(parse_sources(html))
    if not sources:
        return None
    return Stream(sources=sources, subtitles=parse_subtitles(html))


def download(url, timeout=DEFAULT_TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _get(url, timeout=DEFAULT_TIMEOUT):
    return download(url, timeout).decode("utf-8", "replace")


def search(query, page=1, timeout=DEFAULT_TIMEOUT):
    url = BASE_URL + "/hledej/" + urllib.parse.quote(query)
    if int(page) > 1:
        url += "?videoListing-visualPaginator-page=" + str(int(page))
    html = _get(url, timeout)
    return parse_results(html), parse_has_next(html, page)


def resolve(path, timeout=DEFAULT_TIMEOUT):
    html = _get(BASE_URL + path, timeout)
    return parse_stream(html)
