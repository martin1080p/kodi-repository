# plugin.video.prehrajto

Unofficial Kodi video addon that searches [prehraj.to](https://prehraj.to)
and plays results anonymously (no login).

## Features
- Search by term, with pagination
- Recent-search history
- Result metadata (thumbnail, duration, file size)
- Automatic highest-quality stream selection and subtitle attachment

## Build
Run `./package.sh` to produce `plugin.video.prehrajto.zip`.

## Install
In Kodi: Settings → Add-ons → Install from zip file → select
`plugin.video.prehrajto.zip`. (Enable "Unknown sources" first.)

## Develop / test
`python3 -m pytest` — runs unit tests with fake Kodi modules (no Kodi needed).

Target: Kodi 19 (Matrix) and newer.
