import os
import sys
import types

ROOT = os.path.dirname(os.path.abspath(__file__))
# The add-on now lives at the repo root, so `resources` is importable from here.
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def _install_fake_kodi():
    xbmc = types.ModuleType("xbmc")
    xbmc.LOGINFO = 1
    xbmc.LOGERROR = 4
    xbmc.log = lambda *a, **k: None
    xbmc.builtins = []
    xbmc.executebuiltin = lambda s, *a, **k: xbmc.builtins.append(s)

    xbmcgui = types.ModuleType("xbmcgui")

    class ListItem:
        def __init__(self, label="", label2="", path="", offscreen=False):
            self.label = label
            self.path = path
            self.art = {}
            self.info = {}
            self.props = {}
            self.subs = []

        def setArt(self, d):
            self.art.update(d)

        def setInfo(self, type_, d):
            self.info.update(d)

        def setProperty(self, k, v):
            self.props[k] = v

        def getProperty(self, k):
            return self.props.get(k, "")

        def setSubtitles(self, subs):
            self.subs = list(subs)

    class Dialog:
        _next_input = "test query"
        _next_select = 0
        _next_numeric = "1"
        _numeric_returns = []
        notifications = []
        selects = []
        numerics = []

        def input(self, *a, **k):
            return Dialog._next_input

        def notification(self, heading, message, icon=None, time=5000, sound=True):
            Dialog.notifications.append((heading, message))

        def select(self, heading, options, *a, **k):
            Dialog.selects.append((heading, list(options)))
            return Dialog._next_select

        def numeric(self, ntype, heading, default="", *a, **k):
            Dialog.numerics.append((ntype, heading, default))
            if Dialog._numeric_returns:
                return Dialog._numeric_returns.pop(0)
            return Dialog._next_numeric

    xbmcgui.ListItem = ListItem
    xbmcgui.Dialog = Dialog

    xbmcplugin = types.ModuleType("xbmcplugin")
    xbmcplugin.items = []
    xbmcplugin.resolved = []
    xbmcplugin.ended = []

    def add_directory_item(handle, url, li, isFolder=False):
        xbmcplugin.items.append((handle, url, li, isFolder))
        return True

    def end_of_directory(handle, succeeded=True, *a, **k):
        xbmcplugin.ended.append(succeeded)

    xbmcplugin.addDirectoryItem = add_directory_item
    xbmcplugin.endOfDirectory = end_of_directory
    xbmcplugin.setResolvedUrl = (
        lambda handle, ok, li: xbmcplugin.resolved.append((handle, ok, li)))
    xbmcplugin.setContent = lambda *a, **k: None
    xbmcplugin.addSortMethod = lambda *a, **k: None

    xbmcaddon = types.ModuleType("xbmcaddon")

    class Addon:
        def __init__(self, *a, **k):
            pass

        def getAddonInfo(self, key):
            return {"name": "prehraj.to",
                    "profile": os.path.join(ROOT, ".test_profile")}.get(key, "")

        def getLocalizedString(self, sid):
            return "S%d" % sid

        def getSetting(self, key):
            return ""

    xbmcaddon.Addon = Addon

    xbmcvfs = types.ModuleType("xbmcvfs")
    xbmcvfs.translatePath = lambda p: p

    for mod in (xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs):
        sys.modules[mod.__name__] = mod


_install_fake_kodi()
