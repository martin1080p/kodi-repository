# prehraj.to Addon Enhancements Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add likes to results, show size+likes inline, let the user pick quality when multiple sources exist, and use the prehraj.to icon as the addon icon.

**Architecture:** Extend the existing pure-Python `scraper.py` (new `Result.likes`; `Stream` now carries all sources), format the inline label in `gui.py`, and add a quality-selection dialog in the `router.py` play handler. All logic stays unit-testable via the fake `xbmc*` modules in `conftest.py`.

**Tech Stack:** Python 3 (Kodi 19+ bundled), `xbmc*` APIs, `pytest`. PIL/ImageMagick are build-time only (icon generation), not imported by the addon.

## Global Constraints

- Target Kodi 19 (Matrix)+; no external Python **runtime** dependencies (stdlib + `xbmc*` only).
- Anonymous access only; never store/send credentials.
- All user-facing text via `getLocalizedString` string IDs; Czech (`cs_cz`) default, English (`en_gb`) fallback. Both `.po` files define the same ID set.
- Signed stream URLs resolved on demand at play time; never cached.
- Test runner is the repo virtualenv: `.venv/bin/python -m pytest` (system `python3` has no pytest).
- Work on branch `feature/prehrajto-addon`; do NOT switch branches. `git add` only the files each task lists (never `.venv/`, `.superpowers/`, `docs/`, `__pycache__/`).
- Addon lives under `plugin.video.prehrajto/`.
- Likes are optional metadata (only ~6/25 result cards carry a count); absent → empty string `""`.

---

## File Structure

Files touched (all exist except the icon):

```
plugin.video.prehrajto/
├── addon.xml                              MODIFY (Task 3: add <assets><icon>)
├── resources/
│   ├── icon.png                           CREATE (Task 3: 512×512 PNG)
│   ├── language/resource.language.cs_cz/strings.po   MODIFY (Task 2: id 30009)
│   ├── language/resource.language.en_gb/strings.po   MODIFY (Task 2: id 30009)
│   └── lib/
│       ├── scraper.py                     MODIFY (Task 1: likes; Task 2: Stream.sources)
│       ├── gui.py                         MODIFY (Task 1: inline label)
│       └── router.py                      MODIFY (Task 2: quality dialog)
conftest.py                                MODIFY (Task 2: fake Dialog.select)
tests/
├── test_scraper.py                        MODIFY (Task 1 & 2)
├── test_gui.py                            MODIFY (Task 1)
├── test_router.py                         MODIFY (Task 2)
└── test_manifest.py                       MODIFY (Task 3: icon asset)
```

---

### Task 1: Result likes + inline size/likes label

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/scraper.py`
- Modify: `plugin.video.prehrajto/resources/lib/gui.py`
- Test: `tests/test_scraper.py`, `tests/test_gui.py`

**Interfaces:**
- Consumes: existing `scraper.Result`, `scraper.duration_to_seconds`.
- Produces:
  - `Result = namedtuple("Result", "path title thumb duration size likes")` with `likes` defaulting to `""` (so existing 5-arg constructions keep working).
  - `parse_results` sets `likes` (digits from `video__tag--like`, else `""`).
  - `gui._result_label(result) -> str` — title, then non-empty `size` and `♥ likes` joined with `"  •  "`.

- [ ] **Step 1: Write the failing scraper test**

Add to `tests/test_scraper.py` (near the other `parse_results` tests; `load` helper already exists):

```python
def test_parse_results_likes():
    results = scraper.parse_results(load("search.html"))
    by_path = {r.path: r for r in results}
    # Known card with a like count in the fixture:
    assert by_path["/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/"
                   "89d453af0b2a71d2"].likes == "1"
    # Known card with no likes tag → empty string:
    assert by_path["/matrix-4k-cz/895d830c58fa0caf"].likes == ""
    # Every result exposes a likes field (str):
    assert all(isinstance(r.likes, str) for r in results)
```

- [ ] **Step 2: Run it to verify it fails**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py::test_parse_results_likes -v`
Expected: FAIL — `AttributeError: 'Result' object has no attribute 'likes'`.

- [ ] **Step 3: Implement likes parsing in scraper.py**

In `plugin.video.prehrajto/resources/lib/scraper.py`:

Change the `Result` definition (line 12) from:
```python
Result = namedtuple("Result", "path title thumb duration size")
```
to:
```python
Result = namedtuple("Result", "path title thumb duration size likes")
Result.__new__.__defaults__ = ("",)  # likes is optional metadata
```

Add this regex next to the other card regexes (after `_THUMB_RE`, around line 22):
```python
_LIKE_RE = re.compile(
    r'video__tag--like"[^>]*>[\s\S]*?</picture>\s*([0-9]+)', re.S)
```

In `parse_results`, add a likes extraction and pass it to `Result(...)`. The loop body becomes:
```python
        th = _THUMB_RE.search(inner)
        dm = _TIME_RE.search(inner)
        sm = _SIZE_RE.search(inner)
        lk = _LIKE_RE.search(inner)
        results.append(Result(
            path=path,
            title=title,
            thumb=th.group(1) if th else "",
            duration=dm.group(1) if dm else "",
            size=html_mod.unescape(sm.group(1)).strip() if sm else "",
            likes=lk.group(1) if lk else "",
        ))
```

- [ ] **Step 4: Run it to verify it passes**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py -v`
Expected: PASS (all scraper tests, including the new one).

- [ ] **Step 5: Write the failing gui test**

Replace the body of `tests/test_gui.py` with (updates the two existing Result constructions to include `likes` and adds label assertions):

```python
from resources.lib import gui, scraper


def _result(**over):
    base = dict(path="/x/" + "0" * 16, title="T", thumb="http://th/1.jpg",
                duration="01:02:03", size="1.5 GB", likes="7")
    base.update(over)
    return scraper.Result(**base)


def test_make_video_item_full():
    li = gui.make_video_item(_result())
    assert li.getProperty("IsPlayable") == "true"
    assert li.info.get("mediatype") == "video"
    assert li.info.get("duration") == 3723
    assert li.info.get("title") == "T"            # clean title in info
    assert li.art.get("thumb") == "http://th/1.jpg"


def test_make_video_item_no_thumb_no_duration():
    li = gui.make_video_item(_result(thumb="", duration=""))
    assert li.art == {}
    assert "duration" not in li.info


def test_result_label_includes_size_and_likes():
    label = gui._result_label(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert label == "Matrix  •  6.05 GB  •  ♥ 18"


def test_result_label_size_only():
    assert gui._result_label(_result(title="Matrix", size="6.05 GB", likes="")) \
        == "Matrix  •  6.05 GB"


def test_result_label_title_only():
    assert gui._result_label(_result(title="Matrix", size="", likes="")) == "Matrix"


def test_make_video_item_label_has_metadata():
    li = gui.make_video_item(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert "6.05 GB" in li.label and "18" in li.label
```

- [ ] **Step 6: Run it to verify it fails**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_gui.py -v`
Expected: FAIL — `AttributeError: module 'resources.lib.gui' has no attribute '_result_label'`.

- [ ] **Step 7: Implement the label in gui.py**

Replace `plugin.video.prehrajto/resources/lib/gui.py` with:

```python
import xbmcgui

from resources.lib import scraper


def _result_label(result):
    extras = []
    if result.size:
        extras.append(result.size)
    if result.likes:
        extras.append("♥ " + result.likes)
    if not extras:
        return result.title
    return result.title + "  •  " + "  •  ".join(extras)


def make_video_item(result):
    li = xbmcgui.ListItem(label=_result_label(result))
    if result.thumb:
        li.setArt({"thumb": result.thumb,
                   "icon": result.thumb,
                   "poster": result.thumb})
    info = {"title": result.title, "mediatype": "video"}
    secs = scraper.duration_to_seconds(result.duration)
    if secs:
        info["duration"] = secs
    plot = []
    if result.size:
        plot.append(result.size)
    if result.likes:
        plot.append("♥ " + result.likes)
    if plot:
        info["plot"] = "  •  ".join(plot)
    li.setInfo("video", info)
    li.setProperty("IsPlayable", "true")
    return li


def make_folder_item(label):
    return xbmcgui.ListItem(label=label)
```

- [ ] **Step 8: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all previous tests plus the new ones; the `Result` default keeps `test_router.py`'s 5-arg constructions working).

- [ ] **Step 9: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py plugin.video.prehrajto/resources/lib/gui.py tests/test_scraper.py tests/test_gui.py
git commit -m "feat: parse result likes and show size+likes inline in the list"
```

---

### Task 2: Quality selection at play time

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/scraper.py`
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `conftest.py`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`
- Test: `tests/test_scraper.py`, `tests/test_router.py`

**Interfaces:**
- Consumes: `scraper.parse_sources`, `scraper._quality_score`, `scraper.parse_subtitles`, `scraper.resolve`, `scraper.USER_AGENT`.
- Produces:
  - `Stream = namedtuple("Stream", "sources subtitles")`; `sources` is `[(label, url), …]` sorted highest-quality-first.
  - `parse_stream(html) -> Stream | None`; `resolve(path, timeout) -> Stream | None`.
  - Fake `xbmcgui.Dialog.select(heading, options) -> int` in `conftest.py` (records calls; returns `Dialog._next_select`).
  - `router.play` shows a quality dialog for 2+ sources; localized string id `30009`.

- [ ] **Step 1: Update the failing scraper tests**

In `tests/test_scraper.py`, replace the existing stream assertions.

Find the test asserting `stream.url == best_url` (the `parse_stream` test) and replace that test with:
```python
def test_parse_stream_sources_and_subs():
    html = load("detail.html")
    stream = scraper.parse_stream(html)
    labels = [label for label, _url in stream.sources]
    assert labels == ["1080p", "720p"]          # highest quality first
    assert all(".mp4" in url for _label, url in stream.sources)
    assert len(stream.subtitles) == 4
```

Find the `resolve` test asserting `".mp4" in stream.url` and replace those two lines with:
```python
    assert stream.sources and ".mp4" in stream.sources[0][1]
    assert len(stream.subtitles) == 4
```

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py -k "stream or resolve" -v`
Expected: FAIL — `Stream` has no field `sources` / `AttributeError`.

- [ ] **Step 3: Change Stream + parse_stream in scraper.py**

In `plugin.video.prehrajto/resources/lib/scraper.py`:

Change the `Stream` definition (line 13) to:
```python
Stream = namedtuple("Stream", "sources subtitles")
```

Replace `parse_stream` (currently returns a single-url Stream) with:
```python
def parse_stream(html):
    sources = parse_sources(html)
    if not sources:
        return None
    sources = sorted(sources, key=lambda s: _quality_score(s[0]), reverse=True)
    return Stream(sources=sources, subtitles=parse_subtitles(html))
```

Leave `pick_best`, `parse_sources`, `parse_subtitles`, `resolve`, and `_get` unchanged (`resolve` already returns `parse_stream(...)`).

- [ ] **Step 4: Run scraper tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py -v`
Expected: PASS.

- [ ] **Step 5: Add the fake Dialog.select and reset hooks**

In `conftest.py`, replace the `Dialog` class (lines 44–52) with:
```python
    class Dialog:
        _next_input = "test query"
        _next_select = 0
        notifications = []
        selects = []

        def input(self, *a, **k):
            return Dialog._next_input

        def notification(self, heading, message, icon=None, time=5000, sound=True):
            Dialog.notifications.append((heading, message))

        def select(self, heading, options, *a, **k):
            Dialog.selects.append((heading, list(options)))
            return Dialog._next_select
```

- [ ] **Step 6: Write the failing router tests**

In `tests/test_router.py`:

Update `setup_function` to also reset select state:
```python
def setup_function(_):
    xbmcplugin.items.clear()
    xbmcplugin.resolved.clear()
    xbmcgui.Dialog.notifications.clear()
    xbmcgui.Dialog.selects.clear()
    xbmcgui.Dialog._next_select = 0
```

Replace the existing `test_play_resolves_with_headers_and_subs` test with these three:
```python
def test_play_single_source_no_dialog(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")], ["http://x/s.vtt"]))
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcgui.Dialog.selects) == 0          # no prompt for one source
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert li.path.startswith("http://x/v.mp4|User-Agent=")
    assert li.subs == ["http://x/s.vtt"]


def test_play_multi_source_shows_dialog_and_uses_choice(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "u1080"), ("720p", "u720")], []))
    xbmcgui.Dialog._next_select = 1                   # user picks 720p
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcgui.Dialog.selects) == 1
    _heading, options = xbmcgui.Dialog.selects[0]
    assert options == ["1080p", "720p"]
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert li.path.startswith("u720|User-Agent=")


def test_play_multi_source_cancel(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "u1080"), ("720p", "u720")], []))
    xbmcgui.Dialog._next_select = -1                  # user cancels
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, _li = xbmcplugin.resolved[0]
    assert ok is False
```

(The existing `test_play_missing_stream_fails_gracefully`, which monkeypatches `resolve` to return `None`, stays as-is and still passes.)

- [ ] **Step 7: Run router tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v`
Expected: FAIL — `play` still reads `stream.url` (AttributeError) / no dialog logic yet.

- [ ] **Step 8: Rewrite the play handler in router.py**

Replace `play` (lines 102–115) in `plugin.video.prehrajto/resources/lib/router.py` with:
```python
def play(ctx, path):
    try:
        stream = scraper.resolve(path, _timeout())
    except Exception:
        stream = None
    if not stream or not stream.sources:
        _notify(_(30008))
        xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())
        return
    sources = stream.sources
    if len(sources) == 1:
        chosen = sources[0]
    else:
        labels = [label for label, _url in sources]
        index = xbmcgui.Dialog().select(_(30009), labels)
        if index < 0:                      # user cancelled
            xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())
            return
        chosen = sources[index]
    play_url = chosen[1] + "|User-Agent=" + urllib.parse.quote(scraper.USER_AGENT)
    li = xbmcgui.ListItem(path=play_url)
    if stream.subtitles:
        li.setSubtitles(stream.subtitles)
    xbmcplugin.setResolvedUrl(ctx.handle, True, li)
```

- [ ] **Step 9: Add localized string 30009 to both .po files**

In `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`, append:
```po

msgctxt "#30009"
msgid "Select quality"
msgstr ""
```

In `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`, append:
```po

msgctxt "#30009"
msgid "Select quality"
msgstr "Vyberte kvalitu"
```

- [ ] **Step 10: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all tests).

- [ ] **Step 11: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py plugin.video.prehrajto/resources/lib/router.py conftest.py plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po tests/test_scraper.py tests/test_router.py
git commit -m "feat: let the user choose quality when a video has multiple sources"
```

---

### Task 3: Addon icon

**Files:**
- Create: `plugin.video.prehrajto/resources/icon.png`
- Modify: `plugin.video.prehrajto/addon.xml`
- Test: `tests/test_manifest.py`

**Interfaces:**
- Consumes: nothing.
- Produces: a 512×512 PNG addon icon declared in `addon.xml`.

- [ ] **Step 1: Write the failing manifest test**

Add to `tests/test_manifest.py`:
```python
def test_icon_declared_and_present():
    tree = ET.parse(ADDON_XML)
    icons = [e.text for e in tree.getroot().iter("icon")]
    assert "resources/icon.png" in icons
    icon_path = os.path.join(ROOT, "plugin.video.prehrajto",
                             "resources", "icon.png")
    assert os.path.exists(icon_path)
    with open(icon_path, "rb") as f:
        header = f.read(8)
    # PNG magic number
    assert header == b"\x89PNG\r\n\x1a\n"
    assert os.path.getsize(icon_path) > 1000
```

- [ ] **Step 2: Run it to verify it fails**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_manifest.py::test_icon_declared_and_present -v`
Expected: FAIL — no `<icon>` element / file missing.

- [ ] **Step 3: Generate the icon**

Fetch prehraj.to's app icon and upscale it to a square 512×512 PNG (the addon's runtime does not use PIL — this is a one-time build step):
```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
curl -sL -A "Mozilla/5.0" "https://prehraj.to/apple-touch-icon.png" -o /tmp/prehrajto-icon-src.png
.venv/bin/python - <<'PY'
from PIL import Image
im = Image.open("/tmp/prehrajto-icon-src.png").convert("RGBA")
im = im.resize((512, 512), Image.LANCZOS)
im.save("plugin.video.prehrajto/resources/icon.png")
print("wrote", im.size)
PY
file plugin.video.prehrajto/resources/icon.png
```
Expected: `... PNG image data, 512 x 512 ...`.

(If PIL is unavailable, fall back to: `convert /tmp/prehrajto-icon-src.png -resize 512x512! plugin.video.prehrajto/resources/icon.png`.)

- [ ] **Step 4: Declare the icon in addon.xml**

In `plugin.video.prehrajto/addon.xml`, inside the `<extension point="xbmc.addon.metadata">` element (e.g. right after the `<platform>all</platform>` line), add:
```xml
        <assets>
            <icon>resources/icon.png</icon>
        </assets>
```

- [ ] **Step 5: Run the manifest tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_manifest.py -v`
Expected: PASS (well-formed XML + icon test).

- [ ] **Step 6: Verify packaging includes the icon**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && ./package.sh && unzip -l plugin.video.prehrajto.zip | grep icon.png`
Expected: the listing shows `plugin.video.prehrajto/resources/icon.png`.

- [ ] **Step 7: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all tests).

- [ ] **Step 8: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/addon.xml plugin.video.prehrajto/resources/icon.png tests/test_manifest.py
git commit -m "feat: add prehraj.to addon icon"
```

---

## Self-Review

**Spec coverage:**
- Likes parsed into results → Task 1 (`_LIKE_RE`, `Result.likes`). ✓
- Size + likes shown inline in the list → Task 1 (`gui._result_label`, label + plot). ✓
- Quality selection when multiple sources → Task 2 (`Stream.sources`, `play` dialog, id 30009). ✓
- Multiple subtitles → already handled by `parse_subtitles`/`setSubtitles`; no change (noted in spec). ✓
- prehraj.to icon as addon icon → Task 3 (`resources/icon.png`, `<assets><icon>`). ✓
- Localization parity (30009 in both `.po`) → Task 2 Step 9. ✓
- Dependency-free runtime (PIL only build-time) → Task 3 uses PIL in a build step, not imported by the addon. ✓

**Placeholder scan:** No TBD/TODO; every code step has complete code. Fallback command for the icon is a concrete alternative, not a placeholder.

**Type consistency:** `Result` gains `likes` (default `""`) — used in `parse_results`, `gui`, and tests consistently. `Stream(sources, subtitles)` — `parse_stream`/`resolve` produce it; `router.play` and tests consume `stream.sources` (list of `(label, url)`) and `stream.subtitles`. Fake `Dialog.select(heading, options)->int` matches the real Kodi signature and the `router.play` call. String id `30009` defined in Task 2 and referenced in `router.play`.
