# prehraj.to Kodi Addon Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Kodi video addon that searches prehraj.to for a user-typed term and plays the results, anonymously.

**Architecture:** A standard Kodi `xbmc.python.pluginsource` addon. Pure-Python scraping (stdlib `urllib` + `re`, no external deps) is isolated in `scraper.py` so it is unit-testable without Kodi. Kodi-facing code (`router.py`, `gui.py`) is testable via fake `xbmc*` modules installed in `conftest.py`. Search history persists as JSON in the addon profile dir.

**Tech Stack:** Python 3 (Kodi 19+ bundled), Kodi `xbmc/xbmcgui/xbmcplugin/xbmcaddon/xbmcvfs` APIs, `pytest` for tests.

## Global Constraints

- Target Kodi 19 (Matrix) and newer; `addon.xml` requires `xbmc.python` version `3.0.0`.
- No external Python dependencies — Kodi-bundled stdlib + `xbmc*` modules only.
- Anonymous access only; never store or send credentials.
- Signed stream URLs (`token`/`expires`/`signature`) expire — resolve them at play time, never cache.
- All user-facing text goes through `strings.po` string IDs (range 30001+). Czech (`cs_cz`) is the default language; English (`en_gb`) is provided and is Kodi's fallback.
- Base site URL: `https://prehraj.to`. Requests use a desktop-browser `User-Agent`.
- The Kodi addon lives in the `plugin.video.prehrajto/` subfolder so it can be zipped directly for install. Tests, `conftest.py`, and `docs/` live at the repo root, outside the addon folder.
- Commit after every task with the exact message shown.

---

## File Structure

```
prehrajto-kodi/                              (git repo root)
├── plugin.video.prehrajto/                  (the Kodi addon — zip this)
│   ├── addon.py                             entry point → router.run(sys.argv)
│   ├── addon.xml                            addon manifest
│   ├── LICENSE
│   └── resources/
│       ├── __init__.py
│       ├── settings.xml                     HTTP timeout setting
│       ├── language/
│       │   ├── resource.language.cs_cz/strings.po   Czech (default)
│       │   └── resource.language.en_gb/strings.po   English (fallback)
│       └── lib/
│           ├── __init__.py
│           ├── scraper.py                   HTTP + pure HTML parsing
│           ├── history.py                   recent-search persistence
│           ├── gui.py                       ListItem builders (needs xbmcgui)
│           └── router.py                    plugin:// routing (needs xbmc*)
├── tests/
│   ├── fixtures/{search.html,detail.html}   saved real pages
│   ├── test_scraper.py
│   ├── test_history.py
│   └── test_router.py
├── conftest.py                              installs fake xbmc* + sys.path
├── package.sh                               builds installable zip
├── .gitignore
└── docs/superpowers/…                       spec + this plan
```

---

### Task 1: Project scaffold, manifest, and localization

**Files:**
- Create: `plugin.video.prehrajto/addon.xml`
- Create: `plugin.video.prehrajto/addon.py`
- Create: `plugin.video.prehrajto/LICENSE`
- Create: `plugin.video.prehrajto/resources/__init__.py` (empty)
- Create: `plugin.video.prehrajto/resources/lib/__init__.py` (empty)
- Create: `plugin.video.prehrajto/resources/settings.xml`
- Create: `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`
- Create: `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`
- Create: `.gitignore`
- Test: `tests/test_manifest.py`

**Interfaces:**
- Consumes: nothing.
- Produces: valid addon manifest with id `plugin.video.prehrajto`, version `1.0.0`; string IDs 30001–30008 and 30050–30051 available to later tasks. `addon.py` calls `resources.lib.router.run(sys.argv)` (router created in Task 6).

- [ ] **Step 1: Write the failing test**

Create `tests/test_manifest.py`:

```python
import os
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ADDON_XML = os.path.join(ROOT, "plugin.video.prehrajto", "addon.xml")


def test_addon_xml_wellformed_and_ids():
    tree = ET.parse(ADDON_XML)
    root = tree.getroot()
    assert root.get("id") == "plugin.video.prehrajto"
    assert root.get("version") == "1.0.0"
    imports = [e.get("addon") for e in root.iter("import")]
    assert "xbmc.python" in imports
    src = [e for e in root.iter("extension")
           if e.get("point") == "xbmc.python.pluginsource"]
    assert src and src[0].get("library") == "addon.py"


def test_language_files_present():
    base = os.path.join(ROOT, "plugin.video.prehrajto",
                        "resources", "language")
    for lang in ("resource.language.cs_cz", "resource.language.en_gb"):
        assert os.path.exists(os.path.join(base, lang, "strings.po"))
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_manifest.py -v`
Expected: FAIL — `addon.xml` does not exist (`ET.parse` raises / FileNotFoundError).

- [ ] **Step 3: Create the addon manifest**

Create `plugin.video.prehrajto/addon.xml`:

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="plugin.video.prehrajto"
       name="prehraj.to"
       version="1.0.0"
       provider-name="martin">
    <requires>
        <import addon="xbmc.python" version="3.0.0"/>
    </requires>
    <extension point="xbmc.python.pluginsource" library="addon.py">
        <provides>video</provides>
    </extension>
    <extension point="xbmc.addon.metadata">
        <summary lang="cs_cz">Vyhledávání a přehrávání videí z prehraj.to</summary>
        <summary lang="en_gb">Search and play videos from prehraj.to</summary>
        <description lang="cs_cz">Neoficiální doplněk pro vyhledávání a přehrávání videí ze serveru prehraj.to. Bez přihlášení.</description>
        <description lang="en_gb">Unofficial addon to search and play videos from prehraj.to. Anonymous, no login.</description>
        <platform>all</platform>
        <license>MIT</license>
        <language>cs en</language>
    </extension>
</addon>
```

- [ ] **Step 4: Create `addon.py` entry point**

Create `plugin.video.prehrajto/addon.py`:

```python
import sys

from resources.lib.router import run

if __name__ == "__main__":
    run(sys.argv)
```

- [ ] **Step 5: Create empty package markers and settings**

Create `plugin.video.prehrajto/resources/__init__.py` (empty file).
Create `plugin.video.prehrajto/resources/lib/__init__.py` (empty file).

Create `plugin.video.prehrajto/resources/settings.xml`:

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<settings>
    <category label="30050">
        <setting id="timeout" type="slider" label="30051" default="20"
                 range="5,5,60" option="int"/>
    </category>
</settings>
```

Create `plugin.video.prehrajto/LICENSE` with the standard MIT License text (copyright holder: `martin`, year `2026`).

- [ ] **Step 6: Create localization files**

Create `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`:

```po
# prehraj.to addon language file
msgid ""
msgstr ""
"Project-Id-Version: plugin.video.prehrajto\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Language: en_gb\n"

msgctxt "#30001"
msgid "Search"
msgstr ""

msgctxt "#30002"
msgid "Recent searches"
msgstr ""

msgctxt "#30003"
msgid "Clear history"
msgstr ""

msgctxt "#30004"
msgid "Next page"
msgstr ""

msgctxt "#30005"
msgid "Search prehraj.to"
msgstr ""

msgctxt "#30006"
msgid "Nothing found"
msgstr ""

msgctxt "#30007"
msgid "Network error"
msgstr ""

msgctxt "#30008"
msgid "Cannot play this video"
msgstr ""

msgctxt "#30050"
msgid "General"
msgstr ""

msgctxt "#30051"
msgid "Connection timeout (seconds)"
msgstr ""
```

Create `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po` (same IDs and English `msgid`, Czech in `msgstr`):

```po
# prehraj.to addon language file
msgid ""
msgstr ""
"Project-Id-Version: plugin.video.prehrajto\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Language: cs_cz\n"

msgctxt "#30001"
msgid "Search"
msgstr "Hledat"

msgctxt "#30002"
msgid "Recent searches"
msgstr "Poslední hledání"

msgctxt "#30003"
msgid "Clear history"
msgstr "Vymazat historii"

msgctxt "#30004"
msgid "Next page"
msgstr "Další stránka"

msgctxt "#30005"
msgid "Search prehraj.to"
msgstr "Hledat na prehraj.to"

msgctxt "#30006"
msgid "Nothing found"
msgstr "Nic nenalezeno"

msgctxt "#30007"
msgid "Network error"
msgstr "Chyba sítě"

msgctxt "#30008"
msgid "Cannot play this video"
msgstr "Video nelze přehrát"

msgctxt "#30050"
msgid "General"
msgstr "Obecné"

msgctxt "#30051"
msgid "Connection timeout (seconds)"
msgstr "Časový limit připojení (s)"
```

- [ ] **Step 7: Create `.gitignore`**

Create `.gitignore`:

```gitignore
__pycache__/
*.pyc
*.zip
.pytest_cache/
```

- [ ] **Step 8: Run the test to verify it passes**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_manifest.py -v`
Expected: PASS (2 passed). (`addon.py` importing a not-yet-existing router is fine — the manifest test never imports it.)

- [ ] **Step 9: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto .gitignore tests/test_manifest.py
git commit -m "feat: scaffold addon manifest, settings, and localization"
```

---

### Task 2: Results-list parsing

**Files:**
- Create: `plugin.video.prehrajto/resources/lib/scraper.py`
- Create: `tests/fixtures/search.html` (copied real page)
- Create: `tests/test_scraper.py`

**Interfaces:**
- Consumes: nothing.
- Produces:
  - `Result = namedtuple("Result", "path title thumb duration size")`
  - `parse_results(html: str) -> list[Result]` — `path` is site-relative (`/slug/hash`).
  - `parse_has_next(html: str, page: int) -> bool`
  - `duration_to_seconds(text: str) -> int`
  - Constants `BASE_URL`, `USER_AGENT`, `DEFAULT_TIMEOUT`.

- [ ] **Step 1: Add the search-page fixture**

Copy the real page already fetched during design (it contains the stable markers the tests assert on):

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
mkdir -p tests/fixtures
cp "/tmp/claude-1000/-media-hdd-martin-Codes-own-python-prehrajto-kodi/f2323657-2027-4c1d-aa5a-f73c696d898f/scratchpad/search.html" tests/fixtures/search.html
```

If that file is gone, re-fetch (the asserted video id `89d453af0b2a71d2` and its duration/size are stable on the site):

```bash
curl -sL -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36" \
  "https://prehraj.to/hledej/matrix" -o tests/fixtures/search.html
```

Verify: `grep -c 'video__tag--time' tests/fixtures/search.html` prints a number > 0.

- [ ] **Step 2: Write the failing tests**

Create `tests/test_scraper.py`:

```python
import os
import re

from resources.lib import scraper

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def load(name):
    with open(os.path.join(FIXTURES, name), encoding="utf-8") as f:
        return f.read()


def test_parse_results_specific_card():
    results = scraper.parse_results(load("search.html"))
    assert len(results) >= 5
    by_path = {r.path: r for r in results}
    key = "/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/89d453af0b2a71d2"
    assert key in by_path
    r = by_path[key]
    assert "Matrix 1" in r.title
    assert r.duration == "02:16:18"
    assert r.size == "6.05 GB"
    assert r.thumb.startswith("https://thumb.prehrajto.cz")


def test_parse_results_all_valid():
    for r in scraper.parse_results(load("search.html")):
        assert r.title
        assert re.match(r"^/.+/[0-9a-f]{16}$", r.path)


def test_parse_has_next():
    html = load("search.html")
    assert scraper.parse_has_next(html, 1) is True
    assert scraper.parse_has_next(html, 999) is False


def test_duration_to_seconds():
    assert scraper.duration_to_seconds("02:16:18") == 8178
    assert scraper.duration_to_seconds("01:00") == 60
    assert scraper.duration_to_seconds("") == 0
    assert scraper.duration_to_seconds("N/A") == 0
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'resources'` OR `AttributeError` (scraper functions not defined). (`conftest.py` from Task 6 puts the addon dir on the path; until then, run after creating `scraper.py` — the import error resolves once Step 4 lands and pytest's rootdir insertion picks up the addon package via the path shim below.)

> Note: `resources` is importable in tests because `conftest.py` (Task 6) inserts the addon dir into `sys.path`. To keep Tasks 2–5 runnable before Task 6, create a minimal root `conftest.py` now containing only the path shim; Task 6 extends it with the fake `xbmc*` modules.

Create `conftest.py` at the repo root (minimal, extended in Task 6):

```python
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
ADDON = os.path.join(ROOT, "plugin.video.prehrajto")
if ADDON not in sys.path:
    sys.path.insert(0, ADDON)
```

Re-run the tests; expected: FAIL with `AttributeError`/`ModuleNotFoundError: resources.lib.scraper` (module not created yet).

- [ ] **Step 4: Implement the results parser**

Create `plugin.video.prehrajto/resources/lib/scraper.py`:

```python
import html as html_mod
import re
import urllib.parse
import urllib.request
from collections import namedtuple

BASE_URL = "https://prehraj.to"
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
DEFAULT_TIMEOUT = 20

Result = namedtuple("Result", "path title thumb duration size")

_CARD_RE = re.compile(
    r'<a\b([^>]*?href="(/[^"]+/[0-9a-f]{16})"[^>]*?)>(.*?)</a>', re.S)
_TITLE_RE = re.compile(
    r'<h3[^>]*class="[^"]*video__title[^"]*"[^>]*>(.*?)</h3>', re.S)
_TITLE_ATTR_RE = re.compile(r'\btitle="([^"]*)"')
_TIME_RE = re.compile(r'video__tag--time"[^>]*>\s*([0-9:]+)')
_SIZE_RE = re.compile(r'video__tag--size"[^>]*>\s*([^<]+?)\s*<')
_THUMB_RE = re.compile(r'class="thumb thumb1"[^>]*src="([^"]+)"')
_PAGE_RE = re.compile(r'visualPaginator-page=(\d+)')


def parse_results(html):
    results = []
    for m in _CARD_RE.finditer(html):
        attrs, path, inner = m.group(1), m.group(2), m.group(3)
        tm = _TITLE_RE.search(inner)
        if tm:
            title = html_mod.unescape(re.sub(r"<[^>]+>", "", tm.group(1))).strip()
        else:
            am = _TITLE_ATTR_RE.search(attrs)
            title = html_mod.unescape(am.group(1)).strip() if am else ""
        if not title:
            continue
        th = _THUMB_RE.search(inner)
        dm = _TIME_RE.search(inner)
        sm = _SIZE_RE.search(inner)
        results.append(Result(
            path=path,
            title=title,
            thumb=th.group(1) if th else "",
            duration=dm.group(1) if dm else "",
            size=html_mod.unescape(sm.group(1)).strip() if sm else "",
        ))
    return results


def parse_has_next(html, page):
    pages = [int(p) for p in _PAGE_RE.findall(html)]
    return bool(pages) and max(pages) > int(page)


def duration_to_seconds(text):
    parts = (text or "").strip().split(":")
    if not parts or not all(p.isdigit() for p in parts):
        return 0
    secs = 0
    for p in parts:
        secs = secs * 60 + int(p)
    return secs
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -v`
Expected: PASS (4 passed).

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py tests/test_scraper.py tests/fixtures/search.html conftest.py
git commit -m "feat: parse prehraj.to search results and pagination"
```

---

### Task 3: Stream & subtitle resolution parsing

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/scraper.py` (add stream parsing)
- Create: `tests/fixtures/detail.html` (copied real page)
- Modify: `tests/test_scraper.py` (add stream tests)

**Interfaces:**
- Consumes: `scraper` module from Task 2.
- Produces:
  - `Stream = namedtuple("Stream", "url subtitles")`
  - `parse_sources(html) -> list[tuple[str, str]]` — list of `(label, url)`.
  - `parse_subtitles(html) -> list[str]`
  - `pick_best(sources) -> str | None` — highest-quality url.
  - `parse_stream(html) -> Stream | None`

- [ ] **Step 1: Add the detail-page fixture**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
cp "/tmp/claude-1000/-media-hdd-martin-Codes-own-python-prehrajto-kodi/f2323657-2027-4c1d-aa5a-f73c696d898f/scratchpad/detail.html" tests/fixtures/detail.html
```

If gone, re-fetch (signed URLs will differ but the tests assert only on labels/counts/structure, not on hashes):

```bash
curl -sL -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36" \
  "https://prehraj.to/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/89d453af0b2a71d2" -o tests/fixtures/detail.html
```

Verify: `grep -c 'sources = \[' tests/fixtures/detail.html` prints `1`.

- [ ] **Step 2: Write the failing tests**

Append to `tests/test_scraper.py`:

```python
def test_parse_sources_labels_and_urls():
    src = scraper.parse_sources(load("detail.html"))
    labels = {label for label, _ in src}
    assert "1080p" in labels
    assert "720p" in labels
    for _, url in src:
        assert ".mp4" in url


def test_pick_best():
    assert scraper.pick_best([("720p", "a"), ("1080p", "b")]) == "b"
    assert scraper.pick_best([("480p", "x"), ("4k", "y"), ("1080p", "z")]) == "y"
    assert scraper.pick_best([]) is None


def test_parse_subtitles():
    subs = scraper.parse_subtitles(load("detail.html"))
    assert len(subs) == 4
    for s in subs:
        assert ".vtt" in s


def test_parse_stream_picks_1080p():
    html = load("detail.html")
    best_url = dict(scraper.parse_sources(html))["1080p"]
    stream = scraper.parse_stream(html)
    assert stream.url == best_url
    assert len(stream.subtitles) == 4
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -k "sources or pick_best or subtitles or stream" -v`
Expected: FAIL — `AttributeError: module ... has no attribute 'parse_sources'`.

- [ ] **Step 4: Implement stream parsing**

Add to `plugin.video.prehrajto/resources/lib/scraper.py` (after the `Result` definition, add `Stream`; add the regexes near the others; append the functions):

```python
Stream = namedtuple("Stream", "url subtitles")

_SOURCES_RE = re.compile(r"sources\s*=\s*\[(.*?)\]\s*;", re.S)
_SRC_ENTRY_RE = re.compile(
    r'\{\s*file:\s*"([^"]+)"\s*,\s*label:\s*[\'"]([^\'"]+)[\'"]', re.S)
_TRACKS_RE = re.compile(r"tracks\s*=\s*\[(.*?)\]\s*;", re.S)
_TRACK_FILE_RE = re.compile(r'file:\s*"([^"]+)"')


def parse_sources(html):
    m = _SOURCES_RE.search(html)
    if not m:
        return []
    return [(label, url) for url, label in _SRC_ENTRY_RE.findall(m.group(1))]


def parse_subtitles(html):
    m = _TRACKS_RE.search(html)
    if not m:
        return []
    return _TRACK_FILE_RE.findall(m.group(1))


def _quality_score(label):
    low = label.lower()
    digits = re.sub(r"\D", "", low)
    score = int(digits) if digits else 0
    if "k" in low:
        score *= 1000
    return score


def pick_best(sources):
    if not sources:
        return None
    return max(sources, key=lambda s: _quality_score(s[0]))[1]


def parse_stream(html):
    url = pick_best(parse_sources(html))
    if not url:
        return None
    return Stream(url=url, subtitles=parse_subtitles(html))
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -v`
Expected: PASS (8 passed).

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py tests/test_scraper.py tests/fixtures/detail.html
git commit -m "feat: extract highest-quality stream and subtitles from detail page"
```

---

### Task 4: HTTP layer (search & resolve)

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/scraper.py` (add `_get`, `search`, `resolve`)
- Modify: `tests/test_scraper.py` (add tests with `_get` monkeypatched)

**Interfaces:**
- Consumes: `parse_results`, `parse_has_next`, `parse_stream` from Tasks 2–3.
- Produces:
  - `_get(url, timeout=DEFAULT_TIMEOUT) -> str`
  - `search(query, page=1, timeout=DEFAULT_TIMEOUT) -> tuple[list[Result], bool]`
  - `resolve(path, timeout=DEFAULT_TIMEOUT) -> Stream | None`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_scraper.py`:

```python
def test_search_uses_parser(monkeypatch):
    captured = {}

    def fake_get(url, timeout=None):
        captured["url"] = url
        return load("search.html")

    monkeypatch.setattr(scraper, "_get", fake_get)
    results, has_next = scraper.search("matrix", 1)
    assert captured["url"] == "https://prehraj.to/hledej/matrix"
    assert len(results) >= 5
    assert has_next is True


def test_search_page_two_url(monkeypatch):
    captured = {}

    def fake_get(url, timeout=None):
        captured["url"] = url
        return load("search.html")

    monkeypatch.setattr(scraper, "_get", fake_get)
    scraper.search("star wars", 2)
    assert captured["url"] == (
        "https://prehraj.to/hledej/star%20wars"
        "?videoListing-visualPaginator-page=2")


def test_resolve_returns_stream(monkeypatch):
    monkeypatch.setattr(scraper, "_get", lambda url, timeout=None: load("detail.html"))
    stream = scraper.resolve("/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/89d453af0b2a71d2")
    assert stream is not None
    assert ".mp4" in stream.url
    assert len(stream.subtitles) == 4
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -k "search or resolve" -v`
Expected: FAIL — `AttributeError: module ... has no attribute '_get'` / `'search'`.

- [ ] **Step 3: Implement the HTTP layer**

Append to `plugin.video.prehrajto/resources/lib/scraper.py`:

```python
def _get(url, timeout=DEFAULT_TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


def search(query, page=1, timeout=DEFAULT_TIMEOUT):
    url = BASE_URL + "/hledej/" + urllib.parse.quote(query)
    if int(page) > 1:
        url += "?videoListing-visualPaginator-page=" + str(int(page))
    html = _get(url, timeout)
    return parse_results(html), parse_has_next(html, page)


def resolve(path, timeout=DEFAULT_TIMEOUT):
    html = _get(BASE_URL + path, timeout)
    return parse_stream(html)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_scraper.py -v`
Expected: PASS (11 passed).

- [ ] **Step 5: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py tests/test_scraper.py
git commit -m "feat: add HTTP layer for search and stream resolution"
```

---

### Task 5: Search-history persistence

**Files:**
- Create: `plugin.video.prehrajto/resources/lib/history.py`
- Create: `tests/test_history.py`

**Interfaces:**
- Consumes: nothing.
- Produces: `History(path, limit=20)` with methods `add(query)`, `recent() -> list[str]`, `clear()`. Most-recent-first, case-insensitive dedupe, capped at `limit`.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_history.py`:

```python
from resources.lib.history import History


def test_add_and_recent(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("matrix")
    h.add("avatar")
    h.add("matrix")  # moves to front, no duplicate
    assert h.recent() == ["matrix", "avatar"]


def test_add_ignores_blank(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("   ")
    assert h.recent() == []


def test_limit(tmp_path):
    h = History(str(tmp_path / "h.json"), limit=3)
    for q in ["a", "b", "c", "d"]:
        h.add(q)
    assert h.recent() == ["d", "c", "b"]


def test_clear(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("x")
    h.clear()
    assert h.recent() == []


def test_recent_missing_file(tmp_path):
    h = History(str(tmp_path / "does_not_exist.json"))
    assert h.recent() == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_history.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'resources.lib.history'`.

- [ ] **Step 3: Implement history**

Create `plugin.video.prehrajto/resources/lib/history.py`:

```python
import json
import os


class History:
    def __init__(self, path, limit=20):
        self._path = path
        self._limit = limit

    def _load(self):
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def recent(self):
        return self._load()

    def add(self, query):
        q = (query or "").strip()
        if not q:
            return
        items = [x for x in self._load() if x.lower() != q.lower()]
        items.insert(0, q)
        items = items[:self._limit]
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)

    def clear(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_history.py -v`
Expected: PASS (5 passed).

- [ ] **Step 5: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/history.py tests/test_history.py
git commit -m "feat: add search-history persistence"
```

---

### Task 6: Kodi GUI helpers and router

**Files:**
- Create: `plugin.video.prehrajto/resources/lib/gui.py`
- Create: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `conftest.py` (add fake `xbmc*` modules)
- Create: `tests/test_router.py`

**Interfaces:**
- Consumes: `scraper` (Tasks 2–4), `history` (Task 5), string IDs from Task 1.
- Produces:
  - `gui.make_video_item(result) -> xbmcgui.ListItem`
  - `gui.make_folder_item(label) -> xbmcgui.ListItem`
  - `router.Ctx(base, handle)` with `url(**kw) -> str`
  - `router.run(argv)` dispatching actions: `menu`, `search`, `results`, `history`, `history_clear`, `play`.

- [ ] **Step 1: Extend `conftest.py` with fake Kodi modules**

Replace the contents of `conftest.py` (repo root) with:

```python
import os
import sys
import types

ROOT = os.path.dirname(os.path.abspath(__file__))
ADDON = os.path.join(ROOT, "plugin.video.prehrajto")
if ADDON not in sys.path:
    sys.path.insert(0, ADDON)


def _install_fake_kodi():
    xbmc = types.ModuleType("xbmc")
    xbmc.LOGINFO = 1
    xbmc.LOGERROR = 4
    xbmc.log = lambda *a, **k: None
    xbmc.executebuiltin = lambda *a, **k: None

    xbmcgui = types.ModuleType("xbmcgui")

    class ListItem:
        def __init__(self, label="", label2="", path="", offscreen=False):
            self.label = label
            self.path = path
            self.art = {}
            self.info = {}
            self.props = {}
            self.subs = []

        def setArt(self, d):
            self.art.update(d)

        def setInfo(self, type_, d):
            self.info.update(d)

        def setProperty(self, k, v):
            self.props[k] = v

        def getProperty(self, k):
            return self.props.get(k, "")

        def setSubtitles(self, subs):
            self.subs = list(subs)

    class Dialog:
        _next_input = "test query"

        def input(self, *a, **k):
            return Dialog._next_input

        def notification(self, *a, **k):
            pass

    xbmcgui.ListItem = ListItem
    xbmcgui.Dialog = Dialog

    xbmcplugin = types.ModuleType("xbmcplugin")
    xbmcplugin.items = []
    xbmcplugin.resolved = []

    def add_directory_item(handle, url, li, isFolder=False):
        xbmcplugin.items.append((handle, url, li, isFolder))
        return True

    xbmcplugin.addDirectoryItem = add_directory_item
    xbmcplugin.endOfDirectory = lambda handle, succeeded=True, *a, **k: None
    xbmcplugin.setResolvedUrl = (
        lambda handle, ok, li: xbmcplugin.resolved.append((handle, ok, li)))
    xbmcplugin.setContent = lambda *a, **k: None
    xbmcplugin.addSortMethod = lambda *a, **k: None

    xbmcaddon = types.ModuleType("xbmcaddon")

    class Addon:
        def __init__(self, *a, **k):
            pass

        def getAddonInfo(self, key):
            return {"name": "prehraj.to",
                    "profile": os.path.join(ROOT, ".test_profile")}.get(key, "")

        def getLocalizedString(self, sid):
            return "S%d" % sid

        def getSetting(self, key):
            return ""

    xbmcaddon.Addon = Addon

    xbmcvfs = types.ModuleType("xbmcvfs")
    xbmcvfs.translatePath = lambda p: p

    for mod in (xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs):
        sys.modules[mod.__name__] = mod


_install_fake_kodi()
```

- [ ] **Step 2: Write the failing tests**

Create `tests/test_router.py`:

```python
import urllib.parse

import xbmcplugin

from resources.lib import router, scraper


def setup_function(_):
    xbmcplugin.items.clear()
    xbmcplugin.resolved.clear()


def test_ctx_url_roundtrip():
    ctx = router.Ctx("plugin://plugin.video.prehrajto/", 7)
    url = ctx.url(action="play", path="/a/b")
    assert url.startswith("plugin://plugin.video.prehrajto/?")
    q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
    assert q["action"] == "play"
    assert q["path"] == "/a/b"


def test_menu_lists_two_entries():
    router.run(["plugin://plugin.video.prehrajto/", "7", ""])
    assert len(xbmcplugin.items) == 2
    assert all(item[3] is True for item in xbmcplugin.items)  # both folders


def test_results_renders_videos_plus_next(monkeypatch):
    def fake_search(query, page, timeout=None):
        hash16 = "0" * 16
        return ([scraper.Result("/a/" + hash16, "A", "t", "01:00", "1 GB"),
                 scraper.Result("/b/" + hash16, "B", "t", "02:00", "2 GB")], True)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=matrix&page=1"])
    assert len(xbmcplugin.items) == 3          # 2 videos + Next page
    assert xbmcplugin.items[-1][3] is True     # last is a folder
    assert xbmcplugin.items[0][3] is False     # videos are not folders


def test_play_resolves_with_headers_and_subs(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream("http://x/v.mp4",
                                                  ["http://x/s.vtt"]))
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcplugin.resolved) == 1
    _, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert "|User-Agent=" in li.path
    assert li.subs == ["http://x/s.vtt"]


def test_play_missing_stream_fails_gracefully(monkeypatch):
    monkeypatch.setattr(scraper, "resolve", lambda path, timeout=None: None)
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _, ok, _li = xbmcplugin.resolved[0]
    assert ok is False
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_router.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'resources.lib.router'`.

- [ ] **Step 4: Implement `gui.py`**

Create `plugin.video.prehrajto/resources/lib/gui.py`:

```python
import xbmcgui

from resources.lib import scraper


def make_video_item(result):
    li = xbmcgui.ListItem(label=result.title)
    if result.thumb:
        li.setArt({"thumb": result.thumb,
                   "icon": result.thumb,
                   "poster": result.thumb})
    info = {"title": result.title, "mediatype": "video"}
    secs = scraper.duration_to_seconds(result.duration)
    if secs:
        info["duration"] = secs
    if result.size:
        info["plot"] = result.size
    li.setInfo("video", info)
    li.setProperty("IsPlayable", "true")
    return li


def make_folder_item(label):
    return xbmcgui.ListItem(label=label)
```

- [ ] **Step 5: Implement `router.py`**

Create `plugin.video.prehrajto/resources/lib/router.py`:

```python
import os
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import gui, history, scraper

_ADDON = xbmcaddon.Addon()


def _(sid):
    return _ADDON.getLocalizedString(sid)


def _timeout():
    try:
        return int(float(_ADDON.getSetting("timeout")))
    except (ValueError, TypeError):
        return scraper.DEFAULT_TIMEOUT


def _history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.History(os.path.join(profile, "history.json"))


def _notify(message):
    xbmcgui.Dialog().notification(_ADDON.getAddonInfo("name"), message)


class Ctx:
    def __init__(self, base, handle):
        self.base = base
        self.handle = handle

    def url(self, **kwargs):
        return self.base + "?" + urllib.parse.urlencode(kwargs)


def show_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="search"),
        gui.make_folder_item(_(30001)), True)
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="history"),
        gui.make_folder_item(_(30002)), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def do_search(ctx):
    query = (xbmcgui.Dialog().input(_(30005)) or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    _history().add(query)
    render_results(ctx, query, 1)


def render_results(ctx, query, page):
    try:
        results, has_next = scraper.search(query, page, _timeout())
    except Exception:
        _notify(_(30007))
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    if not results and page == 1:
        _notify(_(30006))
    for r in results:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="play", path=r.path),
            gui.make_video_item(r), False)
    if has_next:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=query, page=page + 1),
            gui.make_folder_item(_(30004)), True)
    xbmcplugin.setContent(ctx.handle, "videos")
    xbmcplugin.endOfDirectory(ctx.handle)


def show_history(ctx):
    recent = _history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="history_clear"),
            gui.make_folder_item(_(30003)), False)
    for term in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=term, page=1),
            gui.make_folder_item(term), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_history(ctx):
    _history().clear()
    xbmc.executebuiltin("Container.Refresh")


def play(ctx, path):
    try:
        stream = scraper.resolve(path, _timeout())
    except Exception:
        stream = None
    if not stream or not stream.url:
        _notify(_(30008))
        xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())
        return
    play_url = stream.url + "|User-Agent=" + urllib.parse.quote(scraper.USER_AGENT)
    li = xbmcgui.ListItem(path=play_url)
    if stream.subtitles:
        li.setSubtitles(stream.subtitles)
    xbmcplugin.setResolvedUrl(ctx.handle, True, li)


def run(argv):
    base, handle, qs = argv[0], int(argv[1]), argv[2]
    params = dict(urllib.parse.parse_qsl(qs.lstrip("?")))
    ctx = Ctx(base, handle)
    action = params.get("action", "menu")
    if action == "search":
        do_search(ctx)
    elif action == "results":
        render_results(ctx, params.get("query", ""),
                       int(params.get("page", "1")))
    elif action == "history":
        show_history(ctx)
    elif action == "history_clear":
        clear_history(ctx)
    elif action == "play":
        play(ctx, params.get("path", ""))
    else:
        show_menu(ctx)
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest tests/test_router.py -v`
Expected: PASS (5 passed).

- [ ] **Step 7: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && python3 -m pytest -v`
Expected: PASS (all tests: manifest 2 + scraper 11 + history 5 + router 5 = 23 passed).

- [ ] **Step 8: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/gui.py plugin.video.prehrajto/resources/lib/router.py conftest.py tests/test_router.py
git commit -m "feat: add Kodi GUI helpers and plugin router"
```

---

### Task 7: Packaging and manual verification

**Files:**
- Create: `package.sh`
- Create: `README.md`

**Interfaces:**
- Consumes: the complete addon from Tasks 1–6.
- Produces: `plugin.video.prehrajto.zip` installable in Kodi.

- [ ] **Step 1: Create the packaging script**

Create `package.sh`:

```bash
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f plugin.video.prehrajto.zip
zip -r plugin.video.prehrajto.zip plugin.video.prehrajto \
    -x '*/__pycache__/*' '*.pyc'
echo "Created plugin.video.prehrajto.zip"
```

Make it executable: `chmod +x package.sh`

- [ ] **Step 2: Create README**

Create `README.md`:

```markdown
# plugin.video.prehrajto

Unofficial Kodi video addon that searches [prehraj.to](https://prehraj.to)
and plays results anonymously (no login).

## Features
- Search by term, with pagination
- Recent-search history
- Result metadata (thumbnail, duration, file size)
- Automatic highest-quality stream selection and subtitle attachment

## Build
Run `./package.sh` to produce `plugin.video.prehrajto.zip`.

## Install
In Kodi: Settings → Add-ons → Install from zip file → select
`plugin.video.prehrajto.zip`. (Enable "Unknown sources" first.)

## Develop / test
`python3 -m pytest` — runs unit tests with fake Kodi modules (no Kodi needed).

Target: Kodi 19 (Matrix) and newer.
```

- [ ] **Step 3: Build the zip**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && ./package.sh && unzip -l plugin.video.prehrajto.zip`
Expected: zip created; listing shows `plugin.video.prehrajto/addon.xml`, `.../addon.py`, and `resources/lib/*.py` — and NO `tests/`, `docs/`, or `__pycache__/`.

- [ ] **Step 4: Manual verification in Kodi**

This step requires a running Kodi 19+ and cannot be automated. Perform and confirm each:

1. Install the zip via *Install from zip file*; the addon appears with no errors in `kodi.log`.
2. Open the addon → root menu shows **Hledat** / **Poslední hledání** (Czech UI) or **Search** / **Recent searches** (English UI).
3. **Search** → type `matrix` → a results list appears with thumbnails, and each item shows duration/size in its info.
4. Scroll to **Další stránka / Next page** → page 2 loads.
5. Play a result → video starts; if it has subtitles they are selectable.
6. Back to root → **Recent searches** lists `matrix`; selecting it reruns the search.
7. **Clear history** empties the list.

Record the outcome (pass/fail per item) in the task's review notes.

- [ ] **Step 5: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add package.sh README.md
git commit -m "chore: add packaging script and README"
```

---

## Self-Review

**Spec coverage:**
- Anonymous search → Task 4 `search()` (no auth anywhere). ✓
- Results with metadata (title/thumb/duration/size) → Task 2 `parse_results` + Task 6 `make_video_item`. ✓
- Pagination → Task 2 `parse_has_next` + Task 6 `render_results` Next-page item. ✓
- Search history → Task 5 `History` + Task 6 `show_history`/`clear_history`. ✓
- Playback with highest quality + subtitles → Task 3 `pick_best`/`parse_stream` + Task 6 `play`. ✓
- Czech default / English optional, string IDs → Task 1 `strings.po` files. ✓
- Kodi 19+, no external deps → Task 1 `addon.xml` (`xbmc.python` 3.0.0), scraper uses stdlib only. ✓
- Error handling (notifications, no crash) → Task 6 `render_results`/`play` try/except + `_notify`. ✓
- Signed URLs resolved at play time → Task 6 `play` calls `scraper.resolve` on demand. ✓
- Fixture-based tests for pure parsers → Tasks 2–4. ✓
- Timeout setting → Task 1 `settings.xml` + Task 6 `_timeout()`. ✓

**Placeholder scan:** No TBD/TODO; every code step contains complete code. LICENSE references "standard MIT License text" — acceptable (well-known boilerplate).

**Type consistency:** `Result(path,title,thumb,duration,size)` and `Stream(url,subtitles)` used consistently across Tasks 2/3/6. `search(query,page,timeout)` and `resolve(path,timeout)` signatures match router calls and test monkeypatches. String IDs 30001–30008, 30050–30051 defined in Task 1 and referenced in Task 6.
