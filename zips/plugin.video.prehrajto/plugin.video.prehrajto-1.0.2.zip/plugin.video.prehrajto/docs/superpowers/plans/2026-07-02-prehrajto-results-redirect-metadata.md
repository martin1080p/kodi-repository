# Results redirect (no dialog on exit) + author metadata — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Stop the search/episode dialog from re-appearing when you exit a video, and credit the author in the addon metadata.

**Architecture:** Route every result view through the existing idempotent `?action=results` directory; the dialog actions pop their dialog once then `Container.Update(...,replace)` to it. Add author metadata to `addon.xml`.

**Tech Stack:** Python 3 (Kodi 19+), `xbmc*` APIs, `pytest`.

## Global Constraints

- Target Kodi 19 (Matrix)+; no external runtime dependencies (stdlib + `xbmc*`).
- Test runner is the repo venv: `.venv/bin/python -m pytest` (system `python3` has no pytest).
- Work on branch `feature/prehrajto-addon`; do NOT switch branches. `git add` only the files each task lists (never `.venv/`, `.superpowers/`, `docs/`, `__pycache__/`, `.test_profile/`, `*.zip`).
- Result views must render under the dialog-free `?action=results&query=…` URL; dialog actions redirect via `Container.Update(<url>,replace)` and never `succeeded=False`.
- Author credit string: `Made by Shalty (martin1080p) with love.` (en) / `Vytvořeno s láskou od Shalty (martin1080p).` (cs); `provider-name="Shalty (martin1080p)"`.

---

## File Structure

```
plugin.video.prehrajto/resources/lib/router.py   MODIFY (Task 1: _go_to_results redirect)
plugin.video.prehrajto/addon.xml                  MODIFY (Task 2: provider-name + credit)
conftest.py                                        MODIFY (Task 1: record xbmc.executebuiltin)
tests/test_router.py                               MODIFY (Task 1)
tests/test_manifest.py                             MODIFY (Task 2)
```

---

### Task 1: Route result views through `?action=results` (no dialog on return)

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `conftest.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: existing `router` (`Ctx.url`, `render_results`, `_history`, `_tv_history`, `_episode_query`, `pick_and_play_episode`), `xbmc.executebuiltin`.
- Produces: `router._go_to_results(ctx, query)` — ends the current directory successfully and `Container.Update(...,replace)` to `?action=results&query=<query>`. `do_search` and `pick_and_play_episode` redirect through it instead of calling `render_results` directly.

- [ ] **Step 1: Make the fake `xbmc.executebuiltin` record calls**

In `conftest.py`, replace the `xbmc.executebuiltin` line with a recorder:
```python
    xbmc.builtins = []
    xbmc.executebuiltin = lambda s, *a, **k: xbmc.builtins.append(s)
```
(Leave `xbmc.log`, `LOGINFO`, `LOGERROR` as they are.)

- [ ] **Step 2: Reset the recorder + import xbmc in the router tests**

In `tests/test_router.py`, add `import xbmc` to the imports at the top (next to `import xbmcgui` / `import xbmcplugin`), and add to `setup_function`:
```python
    xbmc.builtins.clear()
```

- [ ] **Step 3: Rewrite the failing query tests to assert the redirect**

In `tests/test_router.py`, add this helper above the tests (after the imports):
```python
def _results_query(builtin):
    # builtin looks like: Container.Update(<url>,replace)
    assert builtin.startswith("Container.Update(") and builtin.endswith(",replace)")
    url = builtin[len("Container.Update("):-len(",replace)")]
    params = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
    assert params["action"] == "results"
    return params["query"]
```

Replace `test_tv_search_builds_episode_query` with:
```python
def test_tv_search_redirects_to_results(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda *a, **k: ([], False))
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert _results_query(xbmc.builtins[-1]) == "Simpsonovi S01E02"
    assert xbmcplugin.items == []   # dialog action renders nothing itself
```

Replace `test_tv_episode_action_builds_query` with:
```python
def test_tv_episode_redirects_to_results(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda *a, **k: ([], False))
    xbmcgui.Dialog._numeric_returns = ["3", "7"]
    router.run(["plugin://x/", "7", "?action=tv_episode&show=Friends"])
    assert _results_query(xbmc.builtins[-1]) == "Friends S03E07"
```

Add a movie-search redirect test:
```python
def test_do_search_redirects_to_results():
    router._history().clear()
    xbmcgui.Dialog._next_input = "matrix"
    router.run(["plugin://x/", "7", "?action=search"])
    assert _results_query(xbmc.builtins[-1]) == "matrix"
    assert "matrix" in router._history().recent()
    assert xbmcplugin.items == []   # no items rendered by the search action itself
```

Add "cancel issues no redirect" assertions to the existing cancel tests
(`test_search_cancel_ends_successfully`, `test_tv_search_cancel_on_empty_season`,
`test_tv_search_cancel_on_empty_episode`): append to each, after its existing
asserts:
```python
    assert not any(b.startswith("Container.Update(") for b in xbmc.builtins)
```

- [ ] **Step 4: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k "redirect or cancel or do_search" -v`
Expected: FAIL — no `Container.Update` recorded (router still calls `render_results` directly).

- [ ] **Step 5: Implement the redirect in router.py**

In `plugin.video.prehrajto/resources/lib/router.py`, add the helper (near `render_results`):
```python
def _go_to_results(ctx, query):
    # End the transient dialog directory, then navigate to the idempotent
    # results directory (replacing the dialog step in history). This keeps the
    # results container dialog-free so returning from playback never re-prompts.
    xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
    xbmc.executebuiltin(
        "Container.Update(%s,replace)" % ctx.url(action="results", query=query))
```

Change `do_search` to redirect instead of rendering in place:
```python
def do_search(ctx):
    query = (xbmcgui.Dialog().input(_(30005)) or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    _history().add(query)
    _go_to_results(ctx, query)
```

Change the tail of `pick_and_play_episode` (the success path only) from
`render_results(ctx, _episode_query(show, season, episode), 1)` to:
```python
    _tv_history().add(show, season, episode)
    _go_to_results(ctx, _episode_query(show, season, episode))
```
(Leave the `if not show` / empty-season / empty-episode guards as they are —
they already `endOfDirectory(succeeded=True)`.)

`render_results` and the `run()` dispatch are unchanged (`?action=results` still
maps to `render_results`).

- [ ] **Step 6: Run to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v`
Expected: PASS. (`test_tv_search_records_episode` and `test_tv_episode_does_not_prefill` still pass — the episode is still recorded before the redirect; they no longer rely on `scraper.search` being called.)

- [ ] **Step 7: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 8: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/router.py conftest.py tests/test_router.py
git commit -m "fix: render results under idempotent action so exit doesn't re-prompt"
```

---

### Task 2: Author metadata

**Files:**
- Modify: `plugin.video.prehrajto/addon.xml`
- Test: `tests/test_manifest.py`

**Interfaces:**
- Consumes: nothing.
- Produces: `provider-name="Shalty (martin1080p)"` and the author credit in both `<description>` values.

- [ ] **Step 1: Write the failing test**

Add to `tests/test_manifest.py`:
```python
def test_author_metadata():
    tree = ET.parse(ADDON_XML)
    root = tree.getroot()
    assert "Shalty" in (root.get("provider-name") or "")
    descriptions = " ".join(e.text or "" for e in root.iter("description"))
    assert "Shalty (martin1080p)" in descriptions
```

- [ ] **Step 2: Run to verify it fails**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_manifest.py::test_author_metadata -v`
Expected: FAIL — `provider-name` is `martin`; no credit in the descriptions.

- [ ] **Step 3: Update addon.xml**

In `plugin.video.prehrajto/addon.xml`:
- Change the `provider-name` attribute from `provider-name="martin"` to
  `provider-name="Shalty (martin1080p)"`.
- Append the credit to each description:
  - cs_cz description → end with: ` Vytvořeno s láskou od Shalty (martin1080p).`
  - en_gb description → end with: ` Made by Shalty (martin1080p) with love.`

Resulting description lines:
```xml
        <description lang="cs_cz">Neoficiální doplněk pro vyhledávání a přehrávání videí ze serveru prehraj.to. Bez přihlášení. Vytvořeno s láskou od Shalty (martin1080p).</description>
        <description lang="en_gb">Unofficial addon to search and play videos from prehraj.to. Anonymous, no login. Made by Shalty (martin1080p) with love.</description>
```

- [ ] **Step 4: Run to verify it passes**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_manifest.py -v`
Expected: PASS (well-formed XML, id/version, icon, and author metadata tests).

- [ ] **Step 5: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/addon.xml tests/test_manifest.py
git commit -m "chore: credit author (Shalty / martin1080p) in addon metadata"
```

---

## Self-Review

**Spec coverage:**
- Results under idempotent `?action=results`; dialog actions redirect via `Container.Update(...,replace)` → Task 1 (`_go_to_results`, `do_search`, `pick_and_play_episode`). ✓
- No dialog on return from playback (results container is dialog-free) → Task 1 (render_results reached only via `?action=results`). ✓
- Cancel paths end successfully, no redirect → Task 1 (guards unchanged + tests). ✓
- Author metadata (provider-name + credit both languages) → Task 2. ✓
- No new runtime deps / no service → satisfied. ✓
- On-device verification of Container.Update timing → noted in spec; tests assert the redirect is issued.

**Placeholder scan:** No TBD/TODO; every code step has complete code.

**Type consistency:** `_go_to_results(ctx, query)` defined in Task 1 and called by `do_search`/`pick_and_play_episode`; it targets `ctx.url(action="results", query=query)`, which `run()` already dispatches to `render_results`. Test helper `_results_query(builtin)` parses the recorded `Container.Update(<url>,replace)` string; fake `xbmc.executebuiltin` records into `xbmc.builtins`, cleared in `setup_function`. Metadata strings match the Global Constraints verbatim.
