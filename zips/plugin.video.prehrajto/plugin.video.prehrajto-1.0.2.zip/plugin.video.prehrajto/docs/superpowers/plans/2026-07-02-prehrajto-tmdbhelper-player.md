# TMDb Helper player integration — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let TMDb Helper play movies/episodes through prehraj.to via a bundled player JSON and a one-click installer.

**Architecture:** `?action=results` composes its search query from `season`/`episode`/`year` params (TMDb Helper can't zero-pad); a bundled `resources/players/prehrajto.json` maps TMDb Helper's play/search to that URL with a picker; a root menu item copies the JSON into TMDb Helper's players folder.

**Tech Stack:** Python 3 (Kodi 19+), `xbmc*` APIs, `pytest`.

## Global Constraints

- Target Kodi 19 (Matrix)+; no external runtime dependencies (stdlib + `xbmc*`).
- Test runner is the repo venv: `.venv/bin/python -m pytest` (system `python3` has no pytest).
- Current branch is `main` (the old `feature/prehrajto-addon` was renamed to `main`; all history is on `main`). Do NOT switch or create branches — commit on the current branch.
- `git add` only the files each task lists (never `.venv/`, `.superpowers/`, `docs/`, `__pycache__/`, `.test_profile/`, `*.zip`).
- Episode search string format is exactly `"<showname> S%02dE%02d"`; movie query is `"<title> <year>"`.
- Player JSON: `plugin.video.prehrajto`, `is_resolvable:"true"`, four play/search paths → `?action=results`, `{"dialog":"auto"}` picker.
- Both `.po` files keep an identical id set (30001–30019, 30050, 30051).
- Installer target: `special://profile/addon_data/plugin.video.themoviedb.helper/players/prehrajto.json`.

---

## File Structure

```
plugin.video.prehrajto/resources/lib/router.py     MODIFY (Task 1: _compose_query; Task 2: installer + menu item)
plugin.video.prehrajto/resources/players/prehrajto.json   CREATE (Task 2)
plugin.video.prehrajto/resources/language/…/en_gb/strings.po   MODIFY (Task 2: 30017-30019)
plugin.video.prehrajto/resources/language/…/cs_cz/strings.po   MODIFY (Task 2)
tests/test_router.py                               MODIFY (Task 1 & 2)
tests/test_manifest.py                             MODIFY (Task 2: bundled JSON validity)
```

---

### Task 1: Compose the results query from season/episode/year

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: existing `router._episode_query(show, season, episode)`, `render_results`, `run`.
- Produces: `router._compose_query(params: dict) -> str`; `run()`'s `results` branch uses it.

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_router.py`:
```python
def test_compose_query_episode():
    assert router._compose_query(
        {"query": "Simpsonovi", "season": "1", "episode": "2"}) == "Simpsonovi S01E02"
    assert router._compose_query(
        {"query": "X", "season": "12", "episode": "34"}) == "X S12E34"


def test_compose_query_movie_year():
    assert router._compose_query({"query": "Matrix", "year": "1999"}) == "Matrix 1999"


def test_compose_query_plain():
    assert router._compose_query({"query": "matrix"}) == "matrix"
    assert router._compose_query({}) == ""


def test_compose_query_bad_season_falls_back():
    assert router._compose_query(
        {"query": "X", "season": "a", "episode": "b", "year": "1999"}) == "X 1999"
    assert router._compose_query({"query": "X", "season": "a", "episode": "b"}) == "X"


def test_results_action_episode(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["q"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=Simpsonovi&season=1&episode=2"])
    assert captured["q"] == "Simpsonovi S01E02"


def test_results_action_movie_year(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["q"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=Matrix&year=1999"])
    assert captured["q"] == "Matrix 1999"
```

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k "compose or results_action" -v`
Expected: FAIL — `_compose_query` doesn't exist; results action ignores season/episode/year.

- [ ] **Step 3: Implement `_compose_query` and wire it into `run()`**

In `plugin.video.prehrajto/resources/lib/router.py`, add `_compose_query` next to `_episode_query`:
```python
def _compose_query(params):
    query = params.get("query", "")
    season = params.get("season")
    episode = params.get("episode")
    if season and episode:
        try:
            return _episode_query(query, season, episode)
        except (TypeError, ValueError):
            pass
    year = params.get("year")
    if year:
        return "%s %s" % (query, year)
    return query
```

In `run()`, change the `results` branch from:
```python
    elif action == "results":
        render_results(ctx, params.get("query", ""),
                       int(params.get("page", "1")))
```
to:
```python
    elif action == "results":
        render_results(ctx, _compose_query(params),
                       int(params.get("page", "1")))
```

- [ ] **Step 4: Run to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v`
Expected: PASS (new tests + existing; pagination/history/redirect still pass — they pass only `query`/`page`, so `_compose_query` returns the query unchanged).

- [ ] **Step 5: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/router.py tests/test_router.py
git commit -m "feat: compose results query from season/episode/year params"
```

---

### Task 2: Bundled player JSON + one-click installer + menu item

**Files:**
- Create: `plugin.video.prehrajto/resources/players/prehrajto.json`
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`
- Test: `tests/test_router.py`, `tests/test_manifest.py`

**Interfaces:**
- Consumes: existing `router` (`Ctx`, `gui`, `_notify`, `show_menu`, `run`), `xbmcvfs`.
- Produces:
  - Bundled `resources/players/prehrajto.json`.
  - `router._install_player_file(src_path, dst_dir) -> str` (writes `<dst_dir>/prehrajto.json`).
  - `router.install_tmdb_player(ctx)`; root menu third item → `?action=install_tmdb_player`.
  - Strings `30017` (menu item), `30018` (success), `30019` (failure).

- [ ] **Step 1: Create the player JSON**

Create `plugin.video.prehrajto/resources/players/prehrajto.json`:
```json
{
    "name": "Prehraj.to",
    "plugin": "plugin.video.prehrajto",
    "is_resolvable": "true",
    "assert": {
        "play_movie": ["title"],
        "play_episode": ["showname", "season", "episode"],
        "search_movie": ["title"],
        "search_episode": ["showname", "season", "episode"]
    },
    "play_movie": [
        "plugin://plugin.video.prehrajto/?action=results&query={title_url}&year={year}",
        {"dialog": "auto"}
    ],
    "search_movie": [
        "plugin://plugin.video.prehrajto/?action=results&query={title_url}&year={year}",
        {"dialog": "auto"}
    ],
    "play_episode": [
        "plugin://plugin.video.prehrajto/?action=results&query={showname_url}&season={season}&episode={episode}",
        {"dialog": "auto"}
    ],
    "search_episode": [
        "plugin://plugin.video.prehrajto/?action=results&query={showname_url}&season={season}&episode={episode}",
        {"dialog": "auto"}
    ]
}
```

- [ ] **Step 2: Write the failing tests**

Add to `tests/test_manifest.py`:
```python
def test_tmdb_player_json_valid():
    import json
    path = os.path.join(ROOT, "plugin.video.prehrajto",
                        "resources", "players", "prehrajto.json")
    assert os.path.exists(path)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    assert data["plugin"] == "plugin.video.prehrajto"
    assert data["is_resolvable"] == "true"
    for key in ("play_movie", "search_movie", "play_episode", "search_episode"):
        assert data[key][0].startswith(
            "plugin://plugin.video.prehrajto/?action=results")
    assert "{title_url}" in data["play_movie"][0]
    assert "{season}" in data["play_episode"][0]
    assert "{episode}" in data["play_episode"][0]
```

In `tests/test_router.py`, replace `test_menu_lists_two_folders` with:
```python
def test_menu_lists_entries():
    router.run(["plugin://plugin.video.prehrajto/", "7", ""])
    assert len(xbmcplugin.items) == 3
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["movies_menu", "tv_menu", "install_tmdb_player"]
    assert xbmcplugin.items[0][3] is True   # Movies folder
    assert xbmcplugin.items[1][3] is True   # TV shows folder
    assert xbmcplugin.items[2][3] is False  # install command, not a folder


def test_install_player_file(tmp_path):
    import json
    src = tmp_path / "src.json"
    src.write_text('{"name": "Prehraj.to"}', encoding="utf-8")
    dst_dir = tmp_path / "players"
    out = router._install_player_file(str(src), str(dst_dir))
    assert os.path.basename(out) == "prehrajto.json"
    with open(out, encoding="utf-8") as f:
        assert json.load(f) == {"name": "Prehraj.to"}
```
Add `import os` and `import json` at the top of `tests/test_router.py` if not already present (there is no module-level `os`/`json` import today — add them).

- [ ] **Step 3: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py::test_menu_lists_entries tests/test_router.py::test_install_player_file tests/test_manifest.py::test_tmdb_player_json_valid -v`
Expected: `test_tmdb_player_json_valid` PASSES (file created in Step 1); the two router tests FAIL (menu has 2 items; `_install_player_file` missing).

- [ ] **Step 4: Implement the installer + menu item in router.py**

In `plugin.video.prehrajto/resources/lib/router.py`, add the helper and handler (near `show_menu`):
```python
def _install_player_file(src_path, dst_dir):
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, "prehrajto.json")
    with open(src_path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(data)
    return dst


def install_tmdb_player(ctx):
    src = os.path.join(_ADDON.getAddonInfo("path"),
                       "resources", "players", "prehrajto.json")
    dst_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/plugin.video.themoviedb.helper/players/")
    try:
        _install_player_file(src, dst_dir)
        _notify(_(30018))
    except OSError:
        _notify(_(30019))
    xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
```

Add the third root-menu item at the end of `show_menu` (before its `endOfDirectory`):
```python
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="install_tmdb_player"),
        gui.make_folder_item(_(30017)), False)       # Install TMDb Helper player
```

In `run()`, add a dispatch branch (before the final `else`):
```python
    elif action == "install_tmdb_player":
        install_tmdb_player(ctx)
```

- [ ] **Step 5: Add localization**

Append to `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`:
```po

msgctxt "#30017"
msgid "Install TMDb Helper player"
msgstr ""

msgctxt "#30018"
msgid "TMDb Helper player installed"
msgstr ""

msgctxt "#30019"
msgid "Install failed — is TMDb Helper installed?"
msgstr ""
```

Append to `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`:
```po

msgctxt "#30017"
msgid "Install TMDb Helper player"
msgstr "Nainstalovat přehrávač do TMDb Helper"

msgctxt "#30018"
msgid "TMDb Helper player installed"
msgstr "Přehrávač TMDb Helper nainstalován"

msgctxt "#30019"
msgid "Install failed — is TMDb Helper installed?"
msgstr "Instalace selhala — je TMDb Helper nainstalován?"
```

- [ ] **Step 6: Run the tests, then the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py tests/test_manifest.py -v && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 7: Verify the JSON ships in the zip**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && ./package.sh && unzip -l plugin.video.prehrajto.zip | grep players/prehrajto.json`
Expected: the listing shows `plugin.video.prehrajto/resources/players/prehrajto.json`. (Do not commit the zip.)

- [ ] **Step 8: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/players/prehrajto.json plugin.video.prehrajto/resources/lib/router.py plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po tests/test_router.py tests/test_manifest.py
git commit -m "feat: TMDb Helper player JSON + one-click installer"
```

---

## Self-Review

**Spec coverage:**
- Results query composed from season/episode (padded) and year → Task 1 (`_compose_query`, tested). ✓
- Bundled player JSON with the four play/search paths + picker → Task 2 (file + validity test). ✓
- One-click installer copying JSON into TMDb Helper's players dir → Task 2 (`_install_player_file`, `install_tmdb_player`, menu item, dispatch). ✓
- Localization 30017–30019 both languages → Task 2. ✓
- JSON ships in the zip → Task 2 Step 7 (package.sh zips the addon folder). ✓
- No new runtime deps; no hard TMDb Helper dependency → satisfied. ✓
- On-device play-via-TMDb-Helper verification → noted in spec (not unit-testable).

**Placeholder scan:** No TBD/TODO; every code step has complete code.

**Type consistency:** `_compose_query(params)` used by `run()` results branch; `_episode_query(show, season, episode)` reused. `_install_player_file(src_path, dst_dir) -> str` defined in Task 2 and called by `install_tmdb_player` and the unit test. Menu action `install_tmdb_player` dispatched in `run()`. String ids 30017–30019 added in both `.po` and referenced in `show_menu`/`install_tmdb_player`. Player JSON `plugin`/paths match the `?action=results` contract from Task 1.
