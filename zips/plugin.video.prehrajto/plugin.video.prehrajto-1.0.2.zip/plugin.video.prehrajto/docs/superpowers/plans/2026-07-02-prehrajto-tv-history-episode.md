# Remember watched episode per TV show — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Show the last-watched season/episode next to each recent TV show, record it when the episode is picked, and pre-fill the picker with those values on re-open.

**Architecture:** Add an `EpisodeHistory` store (records `{show, season, episode}`, deduped by show) alongside the existing string-based `History`. Rewire the router's TV flow to record at pick-time, label recent entries `Show • S01E02`, and pre-fill the numeric dialogs from the stored record.

**Tech Stack:** Python 3 (Kodi 19+), `xbmc*` APIs, `pytest`.

## Global Constraints

- Target Kodi 19 (Matrix)+; no external Python runtime dependencies (stdlib + `xbmc*` only).
- Test runner is the repo venv: `.venv/bin/python -m pytest` (system `python3` has no pytest).
- Work on branch `feature/prehrajto-addon`; do NOT switch branches. `git add` only the files each task lists (never `.venv/`, `.superpowers/`, `docs/`, `__pycache__/`, `.test_profile/`, `*.zip`).
- Record at pick-time (when Season+Episode are confirmed), not on playback start.
- Pre-fill the picker with the last-watched values (editable); a new show starts blank; the picker is always shown.
- Recent TV entry label format: `Show  •  S%02dE%02d` (zero-padded).
- No new localized strings (the `S01E02` token is a code format).
- Backward compatible: a legacy string-list `tv_history.json` is tolerated (dropped, repopulates).

---

## File Structure

```
plugin.video.prehrajto/resources/lib/
├── history.py     MODIFY (Task 1: add EpisodeHistory alongside History)
└── router.py      MODIFY (Task 2: EpisodeHistory, record-at-pick, pre-fill, label;
                            Task 3: group root menu into Movies / TV shows folders)
plugin.video.prehrajto/resources/language/…/en_gb/strings.po  MODIFY (Task 3: 30015/30016)
plugin.video.prehrajto/resources/language/…/cs_cz/strings.po  MODIFY (Task 3: 30015/30016)
conftest.py         MODIFY (Task 2: fake Dialog.numeric records its default arg)
tests/
├── test_history.py MODIFY (Task 1: EpisodeHistory tests)
└── test_router.py  MODIFY (Task 2: TV history/record/prefill tests; Task 3: menu tests)
```

---

### Task 1: `EpisodeHistory` store

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/history.py`
- Test: `tests/test_history.py`

**Interfaces:**
- Consumes: nothing (adds to `history.py`, which already has `History`).
- Produces: `history.EpisodeHistory(path, limit=20)` with:
  - `add(show, season, episode)` — normalizes, dedupes by show (case-insensitive), most-recent-first, capped.
  - `recent() -> list[dict]` — well-formed `{show:str, season:int, episode:int}` records only (skips legacy/invalid).
  - `get(show) -> dict | None` — latest record matching show case-insensitively.
  - `clear()`.

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_history.py` (and update the top import line):

Change the first line to:
```python
from resources.lib.history import History, EpisodeHistory
```

Append:
```python
def test_episode_add_and_recent(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Simpsonovi", "1", "2")   # numeric() returns strings
    assert h.recent() == [{"show": "Simpsonovi", "season": 1, "episode": 2}]


def test_episode_dedupe_by_show_case_insensitive(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Show", 1, 2)
    h.add("Other", 3, 4)
    h.add("show", 5, 6)   # same show → replace + move to front
    rec = h.recent()
    assert rec[0] == {"show": "show", "season": 5, "episode": 6}
    assert [r["show"] for r in rec] == ["show", "Other"]


def test_episode_get(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Show", 1, 2)
    assert h.get("SHOW") == {"show": "Show", "season": 1, "episode": 2}
    assert h.get("missing") is None


def test_episode_limit(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"), limit=2)
    h.add("a", 1, 1)
    h.add("b", 1, 1)
    h.add("c", 1, 1)
    assert [r["show"] for r in h.recent()] == ["c", "b"]


def test_episode_ignores_blank_show(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("   ", 1, 2)
    assert h.recent() == []


def test_episode_skips_legacy_string_entries(tmp_path):
    p = tmp_path / "tv.json"
    p.write_text('["Old", "Names"]', encoding="utf-8")
    h = EpisodeHistory(str(p))
    assert h.recent() == []
    assert h.get("Old") is None


def test_episode_clear(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("x", 1, 1)
    h.clear()
    assert h.recent() == []
```

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_history.py -k episode -v`
Expected: FAIL — `ImportError: cannot import name 'EpisodeHistory'`.

- [ ] **Step 3: Implement `EpisodeHistory`**

Append to `plugin.video.prehrajto/resources/lib/history.py`:
```python
class EpisodeHistory:
    """Per-show record of the last-watched season/episode.

    Stored as a JSON list of {"show": str, "season": int, "episode": int},
    deduped by show (case-insensitive), most-recent-first, capped at `limit`.
    Tolerates a legacy string-list file by dropping non-record entries.
    """

    def __init__(self, path, limit=20):
        self._path = path
        self._limit = limit

    def _load(self):
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        records = []
        for item in data:
            if not isinstance(item, dict):
                continue
            show = item.get("show")
            if not isinstance(show, str) or not show:
                continue
            try:
                season = int(item.get("season"))
                episode = int(item.get("episode"))
            except (TypeError, ValueError):
                continue
            records.append({"show": show, "season": season, "episode": episode})
        return records

    def recent(self):
        return self._load()

    def add(self, show, season, episode):
        show = (show or "").strip()
        if not show:
            return
        try:
            season = int(season)
            episode = int(episode)
        except (TypeError, ValueError):
            return
        items = [r for r in self._load() if r["show"].lower() != show.lower()]
        items.insert(0, {"show": show, "season": season, "episode": episode})
        items = items[:self._limit]
        dirname = os.path.dirname(self._path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)

    def get(self, show):
        key = (show or "").strip().lower()
        for r in self._load():
            if r["show"].lower() == key:
                return r
        return None

    def clear(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
```

- [ ] **Step 4: Run to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_history.py -v`
Expected: PASS (existing `History` tests + the new `EpisodeHistory` tests).

- [ ] **Step 5: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/history.py tests/test_history.py
git commit -m "feat: add EpisodeHistory store for per-show last-watched episode"
```

---

### Task 2: Wire TV flow to record, label, and pre-fill

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `conftest.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: `history.EpisodeHistory` (Task 1), existing `router` helpers (`Ctx`, `render_results`, `_episode_query`, `gui`), `scraper.search`.
- Produces:
  - `router._tv_history()` returns `EpisodeHistory`.
  - `router._episode_label(entry) -> str` → `"Show  •  S01E02"`.
  - `pick_and_play_episode` records at pick-time and pre-fills numeric dialogs from `get(show)`.
  - Fake `xbmcgui.Dialog.numeric(ntype, heading, default="")` records `(ntype, heading, default)`.

- [ ] **Step 1: Make the fake Dialog.numeric record its default**

In `conftest.py`, replace the `numeric` method (currently records `(ntype, heading)`) with:
```python
        def numeric(self, ntype, heading, default="", *a, **k):
            Dialog.numerics.append((ntype, heading, default))
            if Dialog._numeric_returns:
                return Dialog._numeric_returns.pop(0)
            return Dialog._next_numeric
```

- [ ] **Step 2: Update/write the failing router tests**

In `tests/test_router.py`:

Replace `test_tv_history_lists_shows` with:
```python
def test_tv_history_lists_shows():
    h = router._tv_history()
    h.clear()
    h.add("Alpha", 1, 2)
    h.add("Beta", 3, 4)
    router.run(["plugin://x/", "7", "?action=tv_history"])
    labels = [li.label for _h, _u, li, _f in xbmcplugin.items]
    assert "Beta  •  S03E04" in labels
    assert "Alpha  •  S01E02" in labels
    urls = [u for _h, u, _li, _f in xbmcplugin.items]
    assert any("action=tv_episode" in u and "show=Beta" in u for u in urls)
```

Add:
```python
def test_tv_search_records_episode(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda q, p, t=None: ([], False))
    router._tv_history().clear()
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert router._tv_history().get("Simpsonovi") == {
        "show": "Simpsonovi", "season": 1, "episode": 2}


def test_tv_episode_prefills_last_watched(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda q, p, t=None: ([], False))
    h = router._tv_history()
    h.clear()
    h.add("Friends", 3, 7)
    xbmcgui.Dialog._numeric_returns = ["3", "7"]
    router.run(["plugin://x/", "7", "?action=tv_episode&show=Friends"])
    defaults = [d for _t, _hd, d in xbmcgui.Dialog.numerics]
    assert defaults == ["3", "7"]   # both dialogs pre-filled with last watched


def test_tv_search_cancel_records_nothing(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    router._tv_history().clear()
    xbmcgui.Dialog._next_input = "Nope"
    xbmcgui.Dialog._numeric_returns = ["1", ""]   # cancel on episode
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert router._tv_history().get("Nope") is None
```

(The existing `test_tv_search_builds_episode_query` and `test_tv_episode_action_builds_query` still pass — recording is a harmless side effect and they don't read `numerics`.)

- [ ] **Step 3: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k "tv_" -v`
Expected: FAIL — labels are bare titles / `_tv_history().add` takes one arg / defaults not `["3","7"]`.

- [ ] **Step 4: Rewire the router TV flow**

In `plugin.video.prehrajto/resources/lib/router.py`:

Replace `_tv_history` with:
```python
def _tv_history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.EpisodeHistory(os.path.join(profile, "tv_history.json"))
```

Add an episode-label helper next to `_episode_query`:
```python
def _episode_label(entry):
    return "%s  •  S%02dE%02d" % (entry["show"], entry["season"], entry["episode"])
```

Replace `do_tv_search` with (drop the pre-picker history write):
```python
def do_tv_search(ctx):
    show = (xbmcgui.Dialog().input(_(30010)) or "").strip()
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    pick_and_play_episode(ctx, show)
```

Replace `pick_and_play_episode` with:
```python
def pick_and_play_episode(ctx, show):
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    prior = _tv_history().get(show)
    season = xbmcgui.Dialog().numeric(
        0, _(30012), str(prior["season"]) if prior else "")   # Season
    if not season:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    episode = xbmcgui.Dialog().numeric(
        0, _(30013), str(prior["episode"]) if prior else "")  # Episode
    if not episode:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    _tv_history().add(show, season, episode)
    render_results(ctx, _episode_query(show, season, episode), 1)
```

Replace the loop in `show_tv_history` so each entry uses the label + its show:
```python
def show_tv_history(ctx):
    recent = _tv_history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_history_clear"),
            gui.make_folder_item(_(30003)), True)
    for record in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_episode", show=record["show"]),
            gui.make_folder_item(_episode_label(record)), True)
    xbmcplugin.endOfDirectory(ctx.handle)
```

(`clear_tv_history` and the `run()` dispatch are unchanged — `_tv_history().clear()` works the same on `EpisodeHistory`.)

- [ ] **Step 5: Run router tests, then the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v && .venv/bin/python -m pytest -q`
Expected: PASS (all). Confirm `git status` does not stage `.test_profile/`.

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/router.py conftest.py tests/test_router.py
git commit -m "feat: show and pre-fill last-watched episode for recent TV shows"
```

---

### Task 3: Group the root menu into Movies / TV shows folders

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: existing `router` (`Ctx`, `gui`), string ids 30001/30002/30010/30011.
- Produces:
  - `router.show_movies_menu(ctx)`, `router.show_tv_menu(ctx)`.
  - Root `show_menu` lists two folders; `run()` dispatches `movies_menu`, `tv_menu`.
  - String ids `30015` "Movies", `30016` "TV shows" in both `.po` files.

- [ ] **Step 1: Update the failing menu tests**

In `tests/test_router.py`, replace `test_menu_lists_four_entries` with:
```python
def test_menu_lists_two_folders():
    router.run(["plugin://plugin.video.prehrajto/", "7", ""])
    assert len(xbmcplugin.items) == 2
    assert all(item[3] is True for item in xbmcplugin.items)  # both folders
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["movies_menu", "tv_menu"]


def test_movies_menu_lists_search_and_history():
    router.run(["plugin://x/", "7", "?action=movies_menu"])
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["search", "history"]


def test_tv_menu_lists_search_and_history():
    router.run(["plugin://x/", "7", "?action=tv_menu"])
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["tv_search", "tv_history"]
```
(`urllib.parse` is already imported at the top of `tests/test_router.py`.)

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k "menu" -v`
Expected: FAIL — root menu still has 4 items; `movies_menu`/`tv_menu` actions fall through to the default root menu.

- [ ] **Step 3: Regroup the menu in router.py**

In `plugin.video.prehrajto/resources/lib/router.py`, replace `show_menu` with:
```python
def show_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="movies_menu"),
        gui.make_folder_item(_(30015)), True)       # Movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_menu"),
        gui.make_folder_item(_(30016)), True)        # TV shows
    xbmcplugin.endOfDirectory(ctx.handle)


def show_movies_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="search"),
        gui.make_folder_item(_(30001)), True)        # Search movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="history"),
        gui.make_folder_item(_(30002)), True)        # Recent movie searches
    xbmcplugin.endOfDirectory(ctx.handle)


def show_tv_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_search"),
        gui.make_folder_item(_(30010)), True)        # Search TV show
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_history"),
        gui.make_folder_item(_(30011)), True)        # Recent TV shows
    xbmcplugin.endOfDirectory(ctx.handle)
```

In `run()`, add these two branches (before the final `else`):
```python
    elif action == "movies_menu":
        show_movies_menu(ctx)
    elif action == "tv_menu":
        show_tv_menu(ctx)
```

- [ ] **Step 4: Add the two localized strings**

Append to `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`:
```po

msgctxt "#30015"
msgid "Movies"
msgstr ""

msgctxt "#30016"
msgid "TV shows"
msgstr ""
```

Append to `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`:
```po

msgctxt "#30015"
msgid "Movies"
msgstr "Filmy"

msgctxt "#30016"
msgid "TV shows"
msgstr "Seriály"
```
(Both files must end with the identical id set: 30001–30016, 30050, 30051.)

- [ ] **Step 5: Run menu tests, then the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/router.py plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po tests/test_router.py
git commit -m "feat: group root menu into Movies and TV shows folders"
```

---

## Self-Review

**Spec coverage:**
- `EpisodeHistory` (add/recent/get/clear, dedupe-by-show, cap, legacy skip) → Task 1. ✓
- `_tv_history()` → `EpisodeHistory`; record at pick-time (in `pick_and_play_episode`, after both prompts) → Task 2. ✓
- Recent list shows `Show • S01E02`, routes with `show=` → Task 2 (`_episode_label`, `show_tv_history`). ✓
- Pre-fill numeric dialogs from `get(show)`; blank for new shows; picker always shown → Task 2 (`pick_and_play_episode`). ✓
- Cancel records nothing → Task 2 (`add` only after both non-empty), tested. ✓
- Legacy `tv_history.json` tolerated → Task 1 `_load` skip, tested. ✓
- No new localized strings; dependency-free → satisfied (only stdlib + existing `Dialog.numeric` default arg). ✓
- Test fake records numeric default → Task 2 conftest. ✓
- Root menu grouped into Movies / TV shows folders; submenus route to the existing
  actions; ids 30015/30016 in both `.po` → Task 3. ✓

**Placeholder scan:** No TBD/TODO; every code step has complete code.

**Type consistency:** `EpisodeHistory.add(show, season, episode)` / `get(show)->dict|None` / `recent()->list[dict]` used consistently in Task 2. Records are `{"show","season","episode"}` everywhere (`_episode_label`, `show_tv_history`, tests). `Dialog.numeric(ntype, heading, default="")` matches the real Kodi signature and the `pick_and_play_episode` calls; the fake records the 3-tuple `(ntype, heading, default)` and `setup_function` already clears `numerics`.
