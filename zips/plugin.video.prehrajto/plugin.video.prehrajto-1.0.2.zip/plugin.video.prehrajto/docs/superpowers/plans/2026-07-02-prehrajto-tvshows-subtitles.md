# prehraj.to TV shows, named subtitles, fanart, icon & likes — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add named subtitles, a movies/TV-shows split with a numeric episode picker, fanart previews, a logo-based icon, and fix the broken likes glyph.

**Architecture:** Extend the existing addon. `scraper` parses subtitle `(label, url)` pairs and gains download/sanitize helpers; `router` downloads+names subtitles at play time and adds TV-show flows with a second history; `gui` moves likes to the plot and adds fanart; the icon is rebuilt from the site logo.

**Tech Stack:** Python 3 (Kodi 19+), `xbmc*` APIs, `pytest`. ImageMagick is build-time only (icon).

## Global Constraints

- Target Kodi 19 (Matrix)+; no external Python **runtime** dependencies (stdlib + `xbmc*` only).
- Anonymous access only; never store/send credentials.
- All user-facing text via `getLocalizedString` string IDs; Czech (`cs_cz`) default, English (`en_gb`) fallback; both `.po` files define the same ID set.
- Test runner is the repo venv: `.venv/bin/python -m pytest` (system `python3` has no pytest).
- Work on branch `feature/prehrajto-addon`; do NOT switch branches. `git add` only the files each task lists (never `.venv/`, `.superpowers/`, `docs/`, `__pycache__/`, `*.zip`).
- TV episode search string format is exactly `"<title> S%02dE%02d"` (e.g. `"Simpsonovi S01E02"`).
- Signed URLs (streams, subtitles) are resolved/downloaded at play time, never cached.
- Subtitles are downloaded to the addon profile `subs/` dir, cleared before each play; failures degrade gracefully.

---

## File Structure

```
plugin.video.prehrajto/
├── resources/
│   ├── icon.png                        REGEN (Task 4: from site logo)
│   ├── language/…/cs_cz/strings.po      MODIFY (Task 3: relabel + new ids)
│   ├── language/…/en_gb/strings.po      MODIFY (Task 3)
│   └── lib/
│       ├── scraper.py                   MODIFY (Task 1: (label,url) subs, sanitize, download)
│       ├── gui.py                       MODIFY (Task 2: likes→plot, fanart)
│       └── router.py                    MODIFY (Task 1: subtitle download; Task 3: TV flows)
conftest.py                              MODIFY (Task 3: fake Dialog.numeric)
.gitignore                               MODIFY (Task 1: ignore .test_profile/)
tests/
├── test_scraper.py                      MODIFY (Task 1)
├── test_gui.py                          MODIFY (Task 2)
└── test_router.py                       MODIFY (Task 1 & 3)
```

---

### Task 1: Named subtitles (parse `(label, url)`, download & name at play time)

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/scraper.py`
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `tests/test_scraper.py`, `tests/test_router.py`
- Modify: `.gitignore`

**Interfaces:**
- Consumes: existing `scraper` (`_js_array_bodies`, `parse_stream`, `Stream`, `USER_AGENT`, `DEFAULT_TIMEOUT`), `router.play`.
- Produces:
  - `scraper.parse_subtitles(html) -> list[(label, url)]`
  - `scraper.sanitize_filename(label) -> str`
  - `scraper.download(url, timeout=DEFAULT_TIMEOUT) -> bytes`
  - `Stream.subtitles` is now a list of `(label, url)` tuples.
  - `router._prepare_subtitles(tracks) -> list[str]` (local `.vtt` paths named by label).

- [ ] **Step 1: Update the failing scraper tests**

In `tests/test_scraper.py`:

Replace `test_parse_subtitles` (around line 93) with:
```python
def test_parse_subtitles():
    subs = scraper.parse_subtitles(load("detail.html"))
    assert len(subs) == 4
    assert all(isinstance(s, tuple) and len(s) == 2 for s in subs)
    labels = [label for label, _url in subs]
    assert any("CZE" in label for label in labels)
    assert all(".vtt" in url for _label, url in subs)
```

Replace `test_parse_subtitles_order_independent_of_block_order` (around line 164) with:
```python
def test_parse_subtitles_order_independent_of_block_order():
    subs = scraper.parse_subtitles(_REVERSED_ORDER_HTML)
    assert subs == [
        ("CZE", "https://cdn.example/jw-cze.vtt"),
        ("ENG", "https://cdn.example/jw-eng.vtt"),
    ]
    # VideoJS's tracks array uses src: not file:, so it contributes nothing.
    assert all("videojs" not in url for _label, url in subs)
```

Add these tests:
```python
def test_sanitize_filename():
    assert scraper.sanitize_filename("CZE - 8138711 - cze") == "CZE - 8138711 - cze"
    assert scraper.sanitize_filename('a/b\\c:d*e?f"g<h>i|j') == "a_b_c_d_e_f_g_h_i_j"
    assert scraper.sanitize_filename("  x\ty  ") == "x y"
    assert scraper.sanitize_filename("") == "subtitle"
    assert len(scraper.sanitize_filename("z" * 300)) <= 100
```

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py -k "subtitle or sanitize" -v`
Expected: FAIL — subs are strings not tuples / `sanitize_filename` missing.

- [ ] **Step 3: Implement scraper changes**

In `plugin.video.prehrajto/resources/lib/scraper.py`:

Replace the `_TRACK_FILE_RE` line (line 34) with:
```python
_TRACK_ENTRY_RE = re.compile(
    r'file:\s*"([^"]+)"[^}]*?label:\s*[\'"]([^\'"]+)[\'"]', re.S)
```

Replace `parse_subtitles` (lines ~103-108) with:
```python
def parse_subtitles(html):
    seen = set()
    result = []
    for body in _js_array_bodies(html, "tracks"):
        for url, label in _TRACK_ENTRY_RE.findall(body):
            if url not in seen:
                seen.add(url)
                result.append((label, url))
    return result
```

Add a filename sanitizer near the other helpers (e.g. after `duration_to_seconds`):
```python
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def sanitize_filename(label):
    name = _UNSAFE_FILENAME_RE.sub("_", label or "")
    name = re.sub(r"\s+", " ", name).strip()
    return name[:100] or "subtitle"
```

Add a bytes downloader and route `_get` through it (replace the existing `_get`):
```python
def download(url, timeout=DEFAULT_TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _get(url, timeout=DEFAULT_TIMEOUT):
    return download(url, timeout).decode("utf-8", "replace")
```

(`parse_stream` already does `subtitles=parse_subtitles(html)`, so it now returns `(label, url)` pairs unchanged.)

- [ ] **Step 4: Run scraper tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_scraper.py -v`
Expected: PASS (the `len(stream.subtitles) == 4` assertions still hold for tuples).

- [ ] **Step 5: Update the failing router play tests**

In `tests/test_router.py`, replace `test_play_single_source_no_dialog` (around line 43) with these two tests:
```python
def test_play_single_source_downloads_named_subtitles(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")],
            [("CZE - 8138711 - cze", "http://x/cze.vtt"),
             ("ENG", "http://x/eng.vtt")]))
    monkeypatch.setattr(scraper, "download", lambda url, timeout=None: b"WEBVTT\n")
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcgui.Dialog.selects) == 0
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert li.path.startswith("http://x/v.mp4|User-Agent=")
    import os
    assert [os.path.basename(p) for p in li.subs] == [
        "CZE - 8138711 - cze.vtt", "ENG.vtt"]


def test_play_subtitle_download_failure_is_skipped(monkeypatch):
    def flaky(url, timeout=None):
        if "cze" in url:
            raise OSError("boom")
        return b"WEBVTT\n"
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")],
            [("CZE", "http://x/cze.vtt"), ("ENG", "http://x/eng.vtt")]))
    monkeypatch.setattr(scraper, "download", flaky)
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    import os
    assert [os.path.basename(p) for p in li.subs] == ["ENG.vtt"]
```

In the existing multi-source tests (`test_play_multi_source_shows_dialog_and_uses_choice` and `test_play_multi_source_cancel`), the `Stream(...)` calls pass `[]` for subtitles — leave those as `[]` (empty is valid for the new shape).

- [ ] **Step 6: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k play -v`
Expected: FAIL — `play` calls `li.setSubtitles(stream.subtitles)` with tuples (paths would be tuples, not named `.vtt` files).

- [ ] **Step 7: Implement router subtitle download**

In `plugin.video.prehrajto/resources/lib/router.py`, add a helper (after `_notify`):
```python
def _prepare_subtitles(tracks):
    """Download subtitle tracks to the profile subs/ dir, named by label.
    Returns local file paths; skips any that fail to download/write."""
    if not tracks:
        return []
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subs")
    try:
        if os.path.isdir(subs_dir):
            for fname in os.listdir(subs_dir):
                try:
                    os.remove(os.path.join(subs_dir, fname))
                except OSError:
                    pass
        os.makedirs(subs_dir, exist_ok=True)
    except OSError:
        return []
    paths = []
    for label, url in tracks:
        try:
            data = scraper.download(url, _timeout())
        except Exception:
            continue
        path = os.path.join(subs_dir, scraper.sanitize_filename(label) + ".vtt")
        try:
            with open(path, "wb") as f:
                f.write(data)
        except OSError:
            continue
        paths.append(path)
    return paths
```

In `play`, replace the subtitle block (the current `if stream.subtitles: li.setSubtitles(stream.subtitles)`) with:
```python
    subs = _prepare_subtitles(stream.subtitles)
    if subs:
        li.setSubtitles(subs)
```

- [ ] **Step 8: Ignore the test profile dir**

Append to `.gitignore`:
```gitignore
.test_profile/
```

- [ ] **Step 9: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS (all tests). Confirm `git status` does not show a `.test_profile/` dir staged.

- [ ] **Step 10: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/scraper.py plugin.video.prehrajto/resources/lib/router.py tests/test_scraper.py tests/test_router.py .gitignore
git commit -m "feat: show subtitles under their track labels"
```

---

### Task 2: Likes → info/plot only, and fanart from a preview frame

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/gui.py`
- Modify: `tests/test_gui.py`

**Interfaces:**
- Consumes: `scraper.Result`, `scraper.duration_to_seconds`; localized string id `30014` ("Likes").
- Produces:
  - `gui._result_label(result)` — title + size only (no likes, no `♥`).
  - `gui._fanart_from_thumb(thumb) -> str`.
  - `make_video_item` sets `fanart` art and puts likes in the plot as plain text.

> Note: string id `30014` ("Likes"/"Líbí") is added to the `.po` files in Task 3. Under pytest the fake `Addon.getLocalizedString` returns `"S30014"`, so tests assert on the number, not the word.

- [ ] **Step 1: Update/extend the gui tests**

Replace the contents of `tests/test_gui.py` with:
```python
from resources.lib import gui, scraper


def _result(**over):
    base = dict(path="/x/" + "0" * 16, title="T", thumb="http://th/1.jpg",
                duration="01:02:03", size="1.5 GB", likes="7")
    base.update(over)
    return scraper.Result(**base)


def test_make_video_item_full():
    li = gui.make_video_item(_result())
    assert li.getProperty("IsPlayable") == "true"
    assert li.info.get("mediatype") == "video"
    assert li.info.get("duration") == 3723
    assert li.info.get("title") == "T"
    assert li.art.get("thumb") == "http://th/1.jpg"


def test_make_video_item_no_thumb_no_duration():
    li = gui.make_video_item(_result(thumb="", duration=""))
    assert li.art == {}
    assert "duration" not in li.info


def test_result_label_has_size_not_likes():
    label = gui._result_label(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert label == "Matrix  •  6.05 GB"
    assert "18" not in label
    assert "♥" not in label


def test_result_label_title_only():
    assert gui._result_label(_result(title="Matrix", size="", likes="")) == "Matrix"


def test_likes_go_into_plot():
    li = gui.make_video_item(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert "18" in li.info.get("plot", "")
    assert "6.05 GB" in li.info.get("plot", "")
    assert "18" not in li.label
    assert "♥" not in li.info.get("plot", "")


def test_no_likes_no_likes_in_plot():
    li = gui.make_video_item(_result(title="Matrix", size="6.05 GB", likes=""))
    assert li.info.get("plot") == "6.05 GB"


def test_fanart_from_thumb():
    assert gui._fanart_from_thumb(
        "https://thumb.prehrajto.cz//8/9/d/hash/1.jpg"
    ) == "https://thumb.prehrajto.cz//8/9/d/hash/8.jpg"
    # non-matching URL passes through unchanged
    assert gui._fanart_from_thumb("http://x/pic.png") == "http://x/pic.png"
    assert gui._fanart_from_thumb("") == ""


def test_make_video_item_sets_fanart():
    li = gui.make_video_item(_result(thumb="https://thumb.prehrajto.cz//a/b/c/h/1.jpg"))
    assert li.art.get("fanart") == "https://thumb.prehrajto.cz//a/b/c/h/8.jpg"
```

- [ ] **Step 2: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_gui.py -v`
Expected: FAIL — likes still in label / `_fanart_from_thumb` missing.

- [ ] **Step 3: Rewrite gui.py**

Replace `plugin.video.prehrajto/resources/lib/gui.py` with:
```python
import re

import xbmcaddon
import xbmcgui

from resources.lib import scraper

_ADDON = xbmcaddon.Addon()
_FRAME_RE = re.compile(r"/\d+\.jpg$")


def _(sid):
    return _ADDON.getLocalizedString(sid)


def _result_label(result):
    if result.size:
        return result.title + "  •  " + result.size
    return result.title


def _fanart_from_thumb(thumb):
    if not thumb:
        return thumb
    return _FRAME_RE.sub("/8.jpg", thumb)


def make_video_item(result):
    li = xbmcgui.ListItem(label=_result_label(result))
    if result.thumb:
        li.setArt({"thumb": result.thumb,
                   "icon": result.thumb,
                   "poster": result.thumb,
                   "fanart": _fanart_from_thumb(result.thumb)})
    info = {"title": result.title, "mediatype": "video"}
    secs = scraper.duration_to_seconds(result.duration)
    if secs:
        info["duration"] = secs
    plot = []
    if result.size:
        plot.append(result.size)
    if result.likes:
        plot.append("%s: %s" % (_(30014), result.likes))
    if plot:
        info["plot"] = "  •  ".join(plot)
    li.setInfo("video", info)
    li.setProperty("IsPlayable", "true")
    return li


def make_folder_item(label):
    return xbmcgui.ListItem(label=label)
```

- [ ] **Step 4: Run gui tests to verify they pass**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_gui.py -v`
Expected: PASS.

- [ ] **Step 5: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/gui.py tests/test_gui.py
git commit -m "feat: move likes to info plot and add fanart previews"
```

---

### Task 3: Movies vs TV shows (numeric episode picker + TV history)

**Files:**
- Modify: `plugin.video.prehrajto/resources/lib/router.py`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`
- Modify: `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`
- Modify: `conftest.py`
- Modify: `tests/test_router.py`

**Interfaces:**
- Consumes: existing `router` (`Ctx`, `render_results`, `_history`, `gui`, `history.History`), `scraper.search`.
- Produces:
  - `router._episode_query(show, season, episode) -> str` → `"<show> S%02dE%02d"`.
  - `router._tv_history()`, `do_tv_search`, `pick_and_play_episode`, `show_tv_history`, `clear_tv_history`.
  - Root menu with 4 items; new actions `tv_search`, `tv_episode`, `tv_history`, `tv_history_clear`.
  - String ids: `30001` "Search movies", `30002` "Recent movie searches", `30010` "Search TV show", `30011` "Recent TV shows", `30012` "Season", `30013` "Episode", `30014` "Likes".
  - Fake `xbmcgui.Dialog.numeric` in `conftest.py`.

- [ ] **Step 1: Add the fake Dialog.numeric and reset hooks**

In `conftest.py`, replace the `Dialog` class with:
```python
    class Dialog:
        _next_input = "test query"
        _next_select = 0
        _next_numeric = "1"
        _numeric_returns = []
        notifications = []
        selects = []
        numerics = []

        def input(self, *a, **k):
            return Dialog._next_input

        def notification(self, heading, message, icon=None, time=5000, sound=True):
            Dialog.notifications.append((heading, message))

        def select(self, heading, options, *a, **k):
            Dialog.selects.append((heading, list(options)))
            return Dialog._next_select

        def numeric(self, ntype, heading, *a, **k):
            Dialog.numerics.append((ntype, heading))
            if Dialog._numeric_returns:
                return Dialog._numeric_returns.pop(0)
            return Dialog._next_numeric
```

- [ ] **Step 2: Write the failing router tests**

In `tests/test_router.py`, update `setup_function` to also reset numeric state:
```python
def setup_function(_):
    xbmcplugin.items.clear()
    xbmcplugin.resolved.clear()
    xbmcgui.Dialog.notifications.clear()
    xbmcgui.Dialog.selects.clear()
    xbmcgui.Dialog.numerics.clear()
    xbmcgui.Dialog._numeric_returns = []
    xbmcgui.Dialog._next_select = 0
    xbmcgui.Dialog._next_numeric = "1"
```

Replace the existing `test_menu_lists_two_entries` with:
```python
def test_menu_lists_four_entries():
    router.run(["plugin://plugin.video.prehrajto/", "7", ""])
    assert len(xbmcplugin.items) == 4
    assert all(item[3] is True for item in xbmcplugin.items)  # all folders
```

Add these tests:
```python
def test_episode_query():
    assert router._episode_query("Show", 1, 2) == "Show S01E02"
    assert router._episode_query("Show", 12, 34) == "Show S12E34"


def test_tv_search_builds_episode_query(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["query"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert captured["query"] == "Simpsonovi S01E02"


def test_tv_episode_action_builds_query(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["query"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    xbmcgui.Dialog._numeric_returns = ["3", "7"]
    router.run(["plugin://x/", "7", "?action=tv_episode&show=Friends"])
    assert captured["query"] == "Friends S03E07"


def test_tv_search_cancel_on_empty_season(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = [""]   # cancelled season
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert xbmcplugin.resolved == [] and xbmcplugin.items == []


def test_tv_history_lists_shows():
    h = router._tv_history()
    h.clear()
    h.add("Alpha")
    h.add("Beta")
    router.run(["plugin://x/", "7", "?action=tv_history"])
    labels = [li.label for _h, _u, li, _f in xbmcplugin.items]
    assert "Beta" in labels and "Alpha" in labels
```

- [ ] **Step 3: Run to verify they fail**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -k "menu or episode or tv_" -v`
Expected: FAIL — menu has 2 items; `_episode_query`/`_tv_history`/tv actions missing.

- [ ] **Step 4: Implement the TV flows in router.py**

In `plugin.video.prehrajto/resources/lib/router.py`, add helpers after `_history`:
```python
def _tv_history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.History(os.path.join(profile, "tv_history.json"))


def _episode_query(show, season, episode):
    return "%s S%02dE%02d" % (show, int(season), int(episode))
```

Replace `show_menu` with:
```python
def show_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="search"),
        gui.make_folder_item(_(30001)), True)       # Search movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_search"),
        gui.make_folder_item(_(30010)), True)       # Search TV show
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="history"),
        gui.make_folder_item(_(30002)), True)       # Recent movie searches
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_history"),
        gui.make_folder_item(_(30011)), True)       # Recent TV shows
    xbmcplugin.endOfDirectory(ctx.handle)
```

Add the TV handlers (after `clear_history`):
```python
def do_tv_search(ctx):
    show = (xbmcgui.Dialog().input(_(30010)) or "").strip()
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    _tv_history().add(show)
    pick_and_play_episode(ctx, show)


def pick_and_play_episode(ctx, show):
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    season = xbmcgui.Dialog().numeric(0, _(30012))    # Season
    if not season:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    episode = xbmcgui.Dialog().numeric(0, _(30013))   # Episode
    if not episode:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    render_results(ctx, _episode_query(show, season, episode), 1)


def show_tv_history(ctx):
    recent = _tv_history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_history_clear"),
            gui.make_folder_item(_(30003)), True)
    for show in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_episode", show=show),
            gui.make_folder_item(show), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_tv_history(ctx):
    _tv_history().clear()
    xbmc.executebuiltin("Container.Refresh")
```

In `run`, add these branches (before the final `else`):
```python
    elif action == "tv_search":
        do_tv_search(ctx)
    elif action == "tv_episode":
        pick_and_play_episode(ctx, params.get("show", ""))
    elif action == "tv_history":
        show_tv_history(ctx)
    elif action == "tv_history_clear":
        clear_tv_history(ctx)
```

- [ ] **Step 5: Update localization**

In `plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po`, change the msgid of `#30001` to `Search movies` and `#30002` to `Recent movie searches`, and append:
```po

msgctxt "#30010"
msgid "Search TV show"
msgstr ""

msgctxt "#30011"
msgid "Recent TV shows"
msgstr ""

msgctxt "#30012"
msgid "Season"
msgstr ""

msgctxt "#30013"
msgid "Episode"
msgstr ""

msgctxt "#30014"
msgid "Likes"
msgstr ""
```

In `plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po`, set `#30001` msgstr to `Hledat filmy`, `#30002` msgstr to `Poslední filmy` (keep their English msgids matching en_gb: `Search movies` / `Recent movie searches`), and append:
```po

msgctxt "#30010"
msgid "Search TV show"
msgstr "Hledat seriál"

msgctxt "#30011"
msgid "Recent TV shows"
msgstr "Poslední seriály"

msgctxt "#30012"
msgid "Season"
msgstr "Sezóna"

msgctxt "#30013"
msgid "Episode"
msgstr "Epizoda"

msgctxt "#30014"
msgid "Likes"
msgstr "Líbí"
```

(Both files must end up with the identical set of ids: 30001–30014 minus 30015-… none, plus 30050/30051.)

- [ ] **Step 6: Run router tests, then the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_router.py -v && .venv/bin/python -m pytest -q`
Expected: PASS (all).

- [ ] **Step 7: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/lib/router.py conftest.py tests/test_router.py plugin.video.prehrajto/resources/language/resource.language.en_gb/strings.po plugin.video.prehrajto/resources/language/resource.language.cs_cz/strings.po
git commit -m "feat: separate movies and TV shows with numeric episode picker"
```

---

### Task 4: Rebuild the icon from the site logo (dark theme)

**Files:**
- Regenerate: `plugin.video.prehrajto/resources/icon.png`

**Interfaces:**
- Consumes: nothing. `addon.xml` already declares `<assets><icon>resources/icon.png</icon></assets>`; `tests/test_manifest.py` already asserts the icon is a valid PNG > 1000 bytes.

- [ ] **Step 1: Generate the icon from the recolored logo**

The site logo wordmark is dark; recolor it white so it reads on a dark tile, keeping the red play button:
```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
curl -sL -A "Mozilla/5.0" \
  "https://prehraj.to/public/build/images/prehrajto_logo.563585de.svg" \
  -o /tmp/prehrajto-logo.svg
# Make paths without an explicit fill inherit white; the red play keeps its own fill.
sed -i '0,/<svg /{s/<svg /<svg fill="#ffffff" /}' /tmp/prehrajto-logo.svg
convert -background "#141619" /tmp/prehrajto-logo.svg -resize 430x \
  -gravity center -extent 512x512 plugin.video.prehrajto/resources/icon.png
file plugin.video.prehrajto/resources/icon.png
```
Expected: `... PNG image data, 512 x 512 ...`.

If the logo URL 404s (hash may change), find the current one:
```bash
curl -sL "https://prehraj.to/public/build/main.1fb495ab.css" | grep -oE 'images/prehrajto_logo[^)]*\.svg' | head
```
and use that path under `https://prehraj.to/public/build/`.

- [ ] **Step 2: Verify the icon and manifest test**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest tests/test_manifest.py -v`
Expected: PASS (`test_icon_declared_and_present`).

- [ ] **Step 3: Verify it packages**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && ./package.sh && unzip -l plugin.video.prehrajto.zip | grep icon.png`
Expected: the listing shows `plugin.video.prehrajto/resources/icon.png`; `package.sh` reports success (atomic build + integrity check).

- [ ] **Step 4: Run the full suite**

Run: `cd /media/hdd/martin/Codes/own/python/prehrajto-kodi && .venv/bin/python -m pytest -q`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /media/hdd/martin/Codes/own/python/prehrajto-kodi
git add plugin.video.prehrajto/resources/icon.png
git commit -m "feat: build addon icon from the prehraj.to logo"
```

---

## Self-Review

**Spec coverage:**
- Named subtitles (labels) → Task 1 (`parse_subtitles` `(label,url)`, `_prepare_subtitles` download+name). ✓
- Movies vs TV shows + numeric picker + TV history re-selection → Task 3 (`show_menu`, `do_tv_search`, `pick_and_play_episode`, `show_tv_history`, `_episode_query`, `tv_history.json`). ✓
- TV query `S%02dE%02d` → Task 3 `_episode_query`, tested. ✓
- Likes → info/plot only, no heart → Task 2 (`_result_label` size-only, plot likes text). ✓
- Fanart from a frame → Task 2 (`_fanart_from_thumb`, art `fanart`). ✓
- Icon from dark logo → Task 4. ✓
- Localization parity (30001/30002 relabeled; 30010–30014 added both files) → Task 3. ✓
- Dependency-free runtime (ImageMagick build-time only); subtitles transient & cleared → Tasks 1/4. ✓

**Placeholder scan:** No TBD/TODO; every code step has complete code. The icon fallback command is a concrete alternative, not a placeholder.

**Type consistency:** `Stream.subtitles` is `[(label,url)]` in Task 1 and consumed by `_prepare_subtitles` and the router tests. `scraper.download`/`sanitize_filename` names match across tasks. `_episode_query(show, season, episode)` signature matches its call sites and tests. String ids 30010–30014 are added in Task 3 and referenced in Task 2 (`30014`) and Task 3 (`30010`–`30013`). Fake `Dialog.numeric(ntype, heading)` matches the real Kodi signature and `pick_and_play_episode` calls.
