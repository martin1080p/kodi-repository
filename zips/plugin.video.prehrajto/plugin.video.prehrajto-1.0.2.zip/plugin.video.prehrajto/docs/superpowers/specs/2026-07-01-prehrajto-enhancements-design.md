# prehraj.to Addon Enhancements — Design

**Date:** 2026-07-01
**Addon:** `plugin.video.prehrajto` (builds on the initial addon)
**Target:** Kodi 19 (Matrix)+ · Python 3 · no external runtime dependencies

## Purpose

Four enhancements to the existing prehraj.to Kodi addon:

1. Show the **number of likes** for each search result.
2. Show **file size and likes inline** in the results list (currently only in the plot).
3. Let the user **choose the quality** when a video offers multiple sources.
4. Use the **prehraj.to icon** as the addon icon.

Subtitles already work — the parser returns all `tracks` and the player attaches every one — so no change is needed there.

## Confirmed site behaviour (verified 2026-07-01, from fixtures)

- **Likes** appear inside each result card:
  ```html
  <div class="video__tag--others">
    <div class="video__tag--likes">
      <div class="video__tag--like">
        <picture ...>…</picture>
        18
      </div>
    </div>
  </div>
  ```
  The count is the integer after `</picture>` within `video__tag--like`. Not all cards have it: 6 of 25 cards in the search fixture carry a count; the rest omit the `--others` block entirely. The known test card `89d453af0b2a71d2` has `1` like.
- **Multiple sources**: the detail page's JWPlayer `sources = [ {file,label}, … ]` array lists one entry per quality (e.g. `720p`, `1080p`). The existing parser already extracts all of them.
- **Icon assets**: `https://prehraj.to/apple-touch-icon.png` (180×180 PNG), `https://prehraj.to/favicon.svg` (vector), `https://prehraj.to/favicon-96x96.png`.

## Changes

### 1. `Result.likes` (scraper.py)

- Extend `Result = namedtuple("Result", "path title thumb duration size likes")` (new trailing field `likes`).
- Add `_LIKE_RE = re.compile(r'video__tag--like"[^>]*>[\s\S]*?</picture>\s*([0-9]+)', re.S)`.
- In `parse_results`, extract the like count from each card's inner HTML; default to `""` when absent.
- All existing `Result(...)` constructions add the `likes` argument.

### 2. Inline size + likes in the list (gui.py)

- `make_video_item(result)` builds a display label that appends the non-empty
  metadata parts to the title, separated by `"  •  "`:
  - size part: the size string as-is (e.g. `6.05 GB`)
  - likes part: `"♥ " + result.likes` (e.g. `♥ 18`)
  - Example: `Matrix 1 (1999) …  •  6.05 GB  •  ♥ 1`. A card with no size/likes shows just the title.
- The `ListItem` label uses this combined string; `setInfo("video", …)` still sets
  `title` to the clean title and `plot` to size (+ likes) so info panels stay useful.
- A small helper (e.g. `_result_label(result)`) keeps the formatting testable and
  isolated from Kodi objects.

### 3. Quality selection (scraper.py + router.py)

- Change the stream model to carry all qualities:
  - `Stream = namedtuple("Stream", "sources subtitles")` where `sources` is a list of
    `(label, url)` tuples **sorted highest-quality-first** (using the existing
    `_quality_score`).
  - `parse_stream(html)` returns `Stream(sources, subtitles)` or `None` when there are
    no sources. `pick_best` is retained (used to sort / for the default).
  - `resolve(path, timeout)` returns this `Stream`.
- `router.play(ctx, path)`:
  - `stream is None` or `not stream.sources` → notify (`30008`) + `setResolvedUrl(handle, False, ListItem())`.
  - exactly 1 source → use it directly (no prompt).
  - 2+ sources → `xbmcgui.Dialog().select(heading, [label for label, _ in sources])`;
    on a valid index use that source; on cancel (`-1`) → `setResolvedUrl(handle, False, ListItem())` and return (no notification needed).
  - Build the play URL as `chosen_url + "|User-Agent=" + quote(USER_AGENT)`, attach
    `stream.subtitles`, `setResolvedUrl(handle, True, li)`.
  - Heading for the dialog uses a new localized string `30009` ("Select quality" /
    "Vyberte kvalitu").

### 4. Addon icon (resources/icon.png + addon.xml)

- Produce a square `plugin.video.prehrajto/resources/icon.png` at 512×512 from the
  prehraj.to icon: rasterize `favicon.svg` at 512×512 if the toolchain can; otherwise
  upscale `apple-touch-icon.png` to 512×512 (PIL, Lanczos). The image is committed as a
  binary asset.
- Add to `addon.xml` metadata extension:
  ```xml
  <assets>
      <icon>resources/icon.png</icon>
  </assets>
  ```

## Localization

- Add string id `30009` to both `strings.po` files: en_gb `msgid "Select quality"` (empty
  msgstr), cs_cz `msgstr "Vyberte kvalitu"`.

## Testing

- **scraper**:
  - `parse_results` — the `Result` has a `likes` field; card `89d453af0b2a71d2` → `likes == "1"`; a known no-likes card → `likes == ""`; existing title/size/duration/thumb assertions unchanged.
  - `parse_stream` / `resolve` — returns `Stream` whose `sources` is a 2-element list with `1080p` first (highest), each url containing `.mp4`, and `subtitles` of length 4.
  - `pick_best` unchanged.
- **gui** (`_result_label`): title + size + likes joined with `•`; omits empty parts (size-only, title-only cases).
- **router** (`play`): add a fake `xbmcgui.Dialog.select` to `conftest.py` (records the call, returns a configurable index). Tests:
  - 1 source → resolved URL is that source, no `select` call.
  - 2 sources → `select` called with the quality labels; resolved URL is the chosen source (configure the fake to return index 1).
  - cancel (`select` returns `-1`) → `setResolvedUrl(handle, False, …)`, not success.
- **manifest**: `addon.xml` declares `<icon>resources/icon.png</icon>` and the file exists and is a non-empty PNG.
- All tests run with `.venv/bin/python -m pytest`; no Kodi/network needed.

## Non-functional notes

- Still dependency-free at runtime (PIL is only a build-time tool for the icon, not
  imported by the addon).
- The `Result` and `Stream` shape changes are contained: every constructor/consumer is
  in `scraper.py`, `gui.py`, `router.py`, and their tests.
