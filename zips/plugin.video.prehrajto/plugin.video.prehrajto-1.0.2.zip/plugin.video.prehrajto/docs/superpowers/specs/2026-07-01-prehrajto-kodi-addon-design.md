# prehraj.to Kodi Video Addon — Design

**Date:** 2026-07-01
**Addon id:** `plugin.video.prehrajto`
**Target:** Kodi 19 (Matrix) and newer · Python 3 · no external dependencies

## Purpose

A Kodi video addon that searches the prehraj.to video-hosting site for a
user-typed term and plays the resulting videos. Anonymous access only (no
login/account).

## Scope

In scope (first version):

- Search by user-entered term(s).
- Results list with metadata: title, thumbnail, duration, file size.
- Pagination (load next page of results).
- Search history (recent searches, re-runnable from a menu).
- Playback: extract the direct stream and hand it to Kodi's player.

Out of scope:

- Login / premium accounts.
- Explicit quality-selection UI (highest available quality is auto-selected).
- Any write/social features of the site (likes, uploads, etc.).

## Confirmed site behaviour (verified 2026-07-01, anonymous, browser User-Agent)

- **Search URL:** `https://prehraj.to/hledej/<url-encoded query>`
- **Pagination:** append `?videoListing-visualPaginator-page=<N>` (N starts at 1;
  page 1 is the bare URL). Presence of a higher page link indicates more pages.
- **Result card markup** (repeated per result):
  - Detail link: `<a class="video ..." href="/<slug>/<16-hex-hash>" title="<full title>">`
  - Title: `<h3 class="video__title ...">TITLE</h3>` (falls back to anchor `title=`)
  - Duration: `<div class="video__tag video__tag--time">HH:MM:SS</div>`
  - Size: `<div class="video__tag video__tag--size"> 6.05 GB </div>`
  - Thumbnail: first `<img ... class="thumb thumb1" src="https://thumb.prehrajto.cz/.../1.jpg">`
- **Detail page** (`https://prehraj.to/<slug>/<hash>`) embeds a JWPlayer config:
  - `sources = [ { file: "https://….mp4?token=…&expires=…&signature=…", label: '720p' }, { file: "…", label: '1080p' } ];`
    — one entry per available quality; `file` is a directly-playable signed MP4 URL.
  - `tracks = [ { file: "https://….vtt?…", label: "CZE …", kind: "captions" }, … ];`
    — subtitle tracks (optional, may be absent).
- Signed URLs carry `token`/`expires`/`signature`; they are time-limited, so they
  must be resolved at play time, not cached.

## Architecture

Standard Kodi video-plugin layout:

```
plugin.video.prehrajto/
├── addon.xml                     # metadata, xbmc.python 3.0.0 dep, settings hook
├── addon.py                      # thin entry point → router.run()
├── LICENSE
├── resources/
│   ├── settings.xml              # results-per-page note, HTTP timeout
│   ├── language/
│   │   ├── resource.language.cs_cz/strings.po   # Czech (default)
│   │   └── resource.language.en_gb/strings.po   # English (optional)
│   └── lib/
│       ├── __init__.py
│       ├── router.py             # parse plugin:// query, dispatch to handlers
│       ├── scraper.py            # HTTP + HTML parsing (pure parse fns)
│       ├── history.py            # recent-search persistence
│       └── gui.py                # ListItem construction helpers
└── tests/
    ├── fixtures/                 # saved search.html, detail.html samples
    └── test_scraper.py           # unit tests for parse functions
```

### Modules and interfaces

**`scraper.py`** — network + parsing. Pure parse functions take an HTML string and
return plain data (testable without Kodi or network).

- `search(query: str, page: int) -> tuple[list[Result], bool]`
  Fetches the search page, returns `(results, has_next_page)`.
- `parse_results(html: str) -> list[Result]` — pure; extracts result cards.
- `parse_has_next(html: str, page: int) -> bool` — pure; detects further pages.
- `resolve(detail_path: str) -> Stream` — fetches detail page, returns highest-quality
  stream URL + subtitle list.
- `parse_stream(html: str) -> Stream` — pure; parses `sources`/`tracks`, picks the
  highest quality by label (numeric resolution ordering, falls back to file order).
- `Result` = dataclass/namedtuple: `path, title, thumb, duration, size`.
- `Stream` = `url` (str) + `subtitles` (list of str URLs).
- HTTP via `urllib.request` with a desktop browser `User-Agent`; timeout from settings.

**`history.py`** — recent searches.

- `add(query: str)` / `recent() -> list[str]` / `clear()`.
- Stored as JSON in the addon profile dir (`special://profile/addon_data/...`).
- Deduped (most-recent first), capped at 20 entries.

**`gui.py`** — builds `xbmcgui.ListItem`s from `Result`/menu entries; sets art,
`InfoTagVideo` (title, duration in seconds, plot with size), and playback headers.

**`router.py`** — maps `plugin://plugin.video.prehrajto/?action=…` to handlers:
`menu` (root), `search`, `results`, `history`, `history_clear`, `play`.

**`addon.py`** — sets `sys.argv` handle/base-url and calls `router.run()`.

### Screen flow

1. **Root menu:** `Search`, `Recent searches ▸` (folder), optionally `Clear history`.
2. **Search:** keyboard dialog → on submit, record in history → results view.
3. **Recent searches:** list of stored terms → selecting one runs its results view.
4. **Results view:** one playable item per result (thumb + title; duration & size in
   info). If `has_next_page`, append a `Next page ▸` folder item that reloads the
   view for `page+1`.
5. **Play:** `resolve()` the detail page, build a playable `ListItem` with the MP4
   URL (with `|User-Agent=…` appended so the CDN accepts the request), attach any
   subtitles, and `xbmcplugin.setResolvedUrl`.

### Error handling

- Network errors / timeouts and parse failures are caught: show an `xbmcgui`
  notification and return an empty result set (no crash / no stack trace to user).
- Empty search results: "Nothing found" notification, empty list.
- `resolve()` finding no playable source: notification + failed `setResolvedUrl`.

## Testing

- Parsing is isolated in pure functions (`parse_results`, `parse_has_next`,
  `parse_stream`). Real fetched pages are saved as fixtures under `tests/fixtures/`.
- `tests/test_scraper.py` asserts:
  - `parse_results` returns the expected count and fields (title, path, thumb,
    duration, size) from `search.html`.
  - `parse_has_next` correctly reports further pages.
  - `parse_stream` picks 1080p over 720p and extracts subtitle URLs from
    `detail.html`.
- Tests run with plain `python3 -m pytest` (or unittest); no Kodi runtime needed.
- Manual verification in Kodi is a final step (search → list → play).

## Non-functional notes

- Dependency-free: only Kodi's bundled Python 3 stdlib + `xbmc*` modules.
- Localization: UI strings come from `strings.po`. Czech (`cs_cz`) is the default
  language; English (`en_gb`) is provided as an optional translation and also serves
  as Kodi's fallback. All user-facing text is referenced by string ID (no hardcoded
  literals in code), so Kodi shows Czech or English per the GUI language setting.
- Signed stream URLs are resolved at play time (never persisted) because they expire.
- Robust-but-tolerant parsing: individual malformed cards are skipped rather than
  failing the whole page.
