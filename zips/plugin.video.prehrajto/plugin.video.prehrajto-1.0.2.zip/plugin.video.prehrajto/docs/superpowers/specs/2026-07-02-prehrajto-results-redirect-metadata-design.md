# prehraj.to Addon — stop the dialog re-popping after playback + addon metadata

**Date:** 2026-07-02
**Addon:** `plugin.video.prehrajto`
**Target:** Kodi 19 (Matrix)+ · Python 3 · no external runtime dependencies

## Purpose

1. **Fix:** exiting a played video re-opens the search/episode dialog. Make results
   live under an idempotent URL so returning to them never re-prompts.
2. **Metadata:** credit the author — "Made by Shalty (martin1080p) with love."

## Root cause (confirmed)

Search/episode results are rendered *under* the dialog-popping action URLs
(`?action=search`, `?action=tv_search`, `?action=tv_episode`). On return from
playback Kodi re-lists the container, re-running the handler, which re-pops the
keyboard/numeric dialog. (Kodi re-fetches plugin directories on return; confirmed
by the log where an episode play was followed by a fresh `?action=tv_search`
GetDirectory.)

Kodi cannot redirect after playback ends (the plugin isn't running during
playback and there is no post-playback hook without a background service). So the
achievable fix is to make the results container dialog-free.

## Design

### 1. Route all result views through the idempotent `?action=results`

`?action=results&query=…[&page=N]` already exists (pagination; "Recent movie
searches" items). It renders results with no dialog. Route every result view
through it:

- Add `router._go_to_results(ctx, query)`:
  - `xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)` (end the transient
    dialog directory cleanly)
  - `xbmc.executebuiltin("Container.Update(%s,replace)" % ctx.url(action="results", query=query))`
    — navigate to the results directory, `replace` dropping the transient
    dialog step from history so Back lands on the section folder.
- `do_search`: keyboard → if empty, `endOfDirectory(succeeded=True)` and return;
  else `_history().add(query)` then `_go_to_results(ctx, query)` (was:
  `render_results(ctx, query, 1)`).
- `pick_and_play_episode`: after both numeric prompts succeed, `_tv_history().add(...)`
  then `_go_to_results(ctx, _episode_query(show, season, episode))` (was
  `render_results(...)`). Cancel paths unchanged (`endOfDirectory(succeeded=True)`).
- `do_tv_search` unchanged (delegates to `pick_and_play_episode`).
- `render_results` unchanged; still the `?action=results` handler (renders list +
  "Next page" → `?action=results&…&page+1`, all dialog-free). `run()` dispatch
  unchanged.

The `ctx.url` query value is URL-encoded (`urllib.parse.urlencode`), so the
`Container.Update(path,replace)` argument contains no literal commas.

**Resulting behavior:** play a result → stop → Kodi returns to the `?action=results`
container and re-lists it → results shown, **no dialog**. Back once → the Movies
or TV shows folder (the dialog step was replaced out of history).

### 2. Author metadata (addon.xml)

- `provider-name="Shalty (martin1080p)"` (was `martin`).
- Append the credit to both `<description>` values:
  - en_gb: `… Made by Shalty (martin1080p) with love.`
  - cs_cz: `… Vytvořeno s láskou od Shalty (martin1080p).`

## Testing

`.venv/bin/python -m pytest` (no Kodi/network):

- Fake `xbmc.executebuiltin` records calls (a list) so tests can assert redirects;
  `conftest` reset clears it.
- `do_search` with a query: records the query in movie history AND issues
  `Container.Update(...action=results&query=matrix...,replace)`; does NOT render
  items itself.
- `do_search` cancel (empty keyboard): `endOfDirectory(succeeded=True)`, no
  `Container.Update`.
- `tv_search` / `tv_episode`: after picking season/episode, issues
  `Container.Update(...action=results&query=<Show S01E02 url-encoded>...,replace)`
  and records the episode; cancel paths issue no redirect and end successfully.
  (Replaces the old assertions that `scraper.search` was called directly.)
- `render_results` (`?action=results`) unchanged: renders items + Next page, calls
  `scraper.search`.
- Manifest: `provider-name` contains `Shalty`; a `<description>` contains
  `Shalty (martin1080p)`.

## Non-functional notes

- No new runtime deps; no background service.
- On-device caveat (unverifiable in tests): `Container.Update(...,replace)` timing
  during a directory listing — verify on the device that Back from results lands on
  the section folder and that exiting a video shows results without a dialog.
