# prehraj.to Addon — TMDb Helper player integration

**Date:** 2026-07-02
**Addon:** `plugin.video.prehrajto`
**Target:** Kodi 19 (Matrix)+ · Python 3 · no external runtime dependencies

## Purpose

Let TMDb Helper (`plugin.video.themoviedb.helper`, used by Arctic Fuse 2) play a
movie or TV episode through the prehraj.to addon: TMDb Helper hands the title (or
show + season/episode) to prehraj.to, which searches, lets the user pick a release,
and plays it.

## Confirmed facts (from the local TMDb Helper install)

- Player definitions are JSON files in
  `special://profile/addon_data/plugin.video.themoviedb.helper/players/`.
- Format (from bundled examples `jellycon.json`, `showmax.json`): each of
  `play_movie`/`play_episode`/`search_movie`/`search_episode` is a list whose first
  element is a plugin path and whose remaining elements are dialog/navigation steps;
  `{"dialog":"auto"}` opens the directory for the user to pick. `is_resolvable:"true"`
  means the selected item resolves to a playable (via `setResolvedUrl`).
- Substitution tokens include `{title}`, `{title_url}`, `{showname}`,
  `{showname_url}`, `{season}`, `{episode}`, `{year}` (suffix `_url` = `quote(...)`).
  **There is no zero-padding token** — `{season}`/`{episode}` are raw, so TMDb Helper
  can only produce `S1E2`, not `S01E02`.

## Confirmed decisions

- Install method: **one-click** from the addon (a menu item copies the JSON into
  TMDb Helper's players folder); the JSON is also shipped in the repo.
- Movie query: **title + year**.

## Design

### 1. Query composition in the results action (router.py)

`?action=results` gains optional `season`, `episode`, `year` params. In `run()`, the
`results` branch composes the effective query before calling `render_results`:

- `router._compose_query(params) -> str`:
  - if `season` and `episode` are both present and integer-parseable →
    `_episode_query(params["query"], season, episode)` → `"<query> S%02dE%02d"`.
  - elif `year` is present and non-empty → `"%s %s" % (query, year)`.
  - else → `params.get("query", "")`.
  - Non-integer season/episode fall back to the year/plain branches (guarded).
- `run()` `results` branch: `render_results(ctx, _compose_query(params), int(params.get("page", "1")))`.

`render_results` is otherwise unchanged. Existing callers (Recent searches items,
"Next page", the results redirect from `_go_to_results`) pass only `query`/`page`, so
`_compose_query` returns the query unchanged — behavior preserved. The "Next page"
item continues to carry the already-composed query.

### 2. Bundled TMDb Helper player JSON

`plugin.video.prehrajto/resources/players/prehrajto.json`:

```json
{
    "name": "Prehraj.to",
    "plugin": "plugin.video.prehrajto",
    "is_resolvable": "true",
    "assert": {
        "play_movie": ["title"],
        "play_episode": ["showname", "season", "episode"],
        "search_movie": ["title"],
        "search_episode": ["showname", "season", "episode"]
    },
    "play_movie": [
        "plugin://plugin.video.prehrajto/?action=results&query={title_url}&year={year}",
        {"dialog": "auto"}
    ],
    "search_movie": [
        "plugin://plugin.video.prehrajto/?action=results&query={title_url}&year={year}",
        {"dialog": "auto"}
    ],
    "play_episode": [
        "plugin://plugin.video.prehrajto/?action=results&query={showname_url}&season={season}&episode={episode}",
        {"dialog": "auto"}
    ],
    "search_episode": [
        "plugin://plugin.video.prehrajto/?action=results&query={showname_url}&season={season}&episode={episode}",
        {"dialog": "auto"}
    ]
}
```

The file is included in the zip (package.sh zips the whole addon folder).

### 3. One-click installer (router.py + root menu)

- Root menu (`show_menu`) gains a third, non-folder item **"Install TMDb Helper
  player"** → `?action=install_tmdb_player`.
- `router._install_player_file(src_path, dst_dir) -> str`: `os.makedirs(dst_dir,
  exist_ok=True)`, copy `src_path` to `<dst_dir>/prehrajto.json`, return the written
  path. (Pure/testable with tmp paths.)
- `router.install_tmdb_player(ctx)`:
  - `src = os.path.join(_ADDON.getAddonInfo("path"), "resources", "players", "prehrajto.json")`
  - `dst_dir = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.themoviedb.helper/players/")`
  - try `_install_player_file(src, dst_dir)` → notify success (`30018`); on `OSError`
    → notify failure (`30019`).
  - `xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)`.
- `run()` dispatches `install_tmdb_player`.

### 4. Localization (both strings.po)

- `30017` "Install TMDb Helper player" / cs "Nainstalovat přehrávač do TMDb Helper"
- `30018` "TMDb Helper player installed" / cs "Přehrávač TMDb Helper nainstalován"
- `30019` "Install failed — is TMDb Helper installed?" / cs "Instalace selhala — je TMDb Helper nainstalován?"

Both files keep an identical id set (30001–30019, 30050, 30051).

## Testing

`.venv/bin/python -m pytest` (no Kodi/network):

- `router._compose_query`:
  - `{"query":"Simpsonovi","season":"1","episode":"2"}` → `"Simpsonovi S01E02"`;
    `("...","12","34")` → `"... S12E34"`.
  - `{"query":"Matrix","year":"1999"}` → `"Matrix 1999"`.
  - `{"query":"matrix"}` → `"matrix"`; empty → `""`.
  - non-integer season/episode → falls back (no crash).
- `?action=results` integration (monkeypatch `scraper.search`): with
  `season`/`episode` → search called with `"Show S01E02"`; with `year` → `"Title 1999"`.
- Root menu now lists three items; the third routes to `install_tmdb_player`.
- `router._install_player_file(src, dst_dir)` (tmp paths): copies to
  `<dst_dir>/prehrajto.json`; result parses as JSON.
- The shipped `resources/players/prehrajto.json` is valid JSON with
  `plugin == "plugin.video.prehrajto"`, `is_resolvable == "true"`, and the four
  play/search paths pointing at `?action=results`.
- Both `.po` files define the identical id set including 30017–30019.

## Non-functional notes

- No new runtime deps; installer uses stdlib + `xbmcvfs`.
- No hard dependency on TMDb Helper: the installer just writes a file under
  `addon_data`; harmless if TMDb Helper is not installed (the user is told to install
  it).
- After installing, selecting the player for a title is done in TMDb Helper's own UI
  (context menu → Play using… / set default) — no addon code.
- On-device verification (not unit-testable): from a TMDb Helper movie/episode,
  Play using Prehraj.to opens the results picker and plays the chosen release.
