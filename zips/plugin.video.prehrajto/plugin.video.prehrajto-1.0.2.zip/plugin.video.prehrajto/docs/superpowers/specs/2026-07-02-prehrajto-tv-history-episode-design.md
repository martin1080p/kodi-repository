# prehraj.to Addon — remember watched episode per TV show

**Date:** 2026-07-02
**Addon:** `plugin.video.prehrajto` (builds on the existing addon)
**Target:** Kodi 19 (Matrix)+ · Python 3 · no external runtime dependencies

## Purpose

Two related menu/TV changes:

1. In the **Recent TV shows** list, show the last-watched season/episode for each show,
   and keep the click behavior of re-opening the episode picker — but pre-fill it with
   those last-watched values.
2. Group the root menu into two folders — **Movies** and **TV shows** — instead of four
   flat items.

## Confirmed decisions

- **Record at pick-time:** the episode is recorded the moment the user confirms the
  season+episode numeric picker (i.e. when they go to watch it), not on actual
  playback start.
- **Pre-fill last watched:** when re-opening the picker for a known show, the Season
  and Episode dialogs default to the last-watched values (editable); a brand-new show
  starts blank. The picker is still shown every time.
- **Label format:** recent TV entries read `Show  •  S01E02` (zero-padded).
- **Root menu:** two folders, **Movies** and **TV shows**, each containing its Search +
  Recent items.

## Current behavior (to change)

- `router._tv_history()` returns a `history.History` over `tv_history.json` — a list of
  plain show-title strings.
- `do_tv_search` records the bare title *before* the episode picker.
- `pick_and_play_episode` prompts Season then Episode (blank), then searches
  `"<show> S%02dE%02d"`; it records nothing.
- `show_tv_history` lists titles; each routes to `action=tv_episode&show=<title>`.

## Changes

### 1. `history.EpisodeHistory` (history.py)

New class alongside `History`, persisting a JSON list of records
`{"show": str, "season": int, "episode": int}`:

- `EpisodeHistory(path, limit=20)`.
- `add(show, season, episode)`: normalize (`show.strip()`, `int(season)`, `int(episode)`);
  ignore blank show; dedupe by show case-insensitively (remove any existing entry for
  that show), insert the new record at the front, cap at `limit`; create the parent dir
  and write JSON (`ensure_ascii=False`).
- `recent() -> list[dict]`: load; return only well-formed records (dict with a string
  `show` and int-coercible `season`/`episode`); skip anything else — this tolerates the
  legacy `tv_history.json` (list of strings), which is simply dropped.
- `get(show) -> dict | None`: the most-recent record whose `show` matches
  case-insensitively, else `None`.
- `clear()`: remove the file (ignore if absent).

### 2. Router (router.py)

- `_tv_history()` returns `history.EpisodeHistory(os.path.join(profile, "tv_history.json"))`.
- `do_tv_search`: prompt the show title; if empty, end. **Remove** the pre-picker
  `_tv_history().add(...)`; just call `pick_and_play_episode(ctx, show)`.
- `pick_and_play_episode(ctx, show)`:
  - if not `show`, end.
  - `prior = _tv_history().get(show)`.
  - `season = Dialog().numeric(0, _(30012), str(prior["season"]) if prior else "")`;
    if empty, end (record nothing).
  - `episode = Dialog().numeric(0, _(30013), str(prior["episode"]) if prior else "")`;
    if empty, end (record nothing).
  - `_tv_history().add(show, season, episode)` (record now).
  - `render_results(ctx, _episode_query(show, season, episode), 1)`.
- `_episode_label(entry) -> str`: `"%s  •  S%02dE%02d" % (entry["show"], entry["season"], entry["episode"])`.
- `show_tv_history`: for each record in `recent()`, add a folder item labelled
  `_episode_label(record)` routing to `action=tv_episode&show=<record["show"]>`; keep the
  leading Clear-history item. `clear_tv_history` unchanged (calls `_tv_history().clear()`).

### 3. Root menu grouped into two folders (router.py + strings.po)

Replace the current 4-item flat root menu with 2 folders, each opening a submenu of the
existing actions:

- `show_menu`: two folder items — **Movies** (`action=movies_menu`, id 30015) and
  **TV shows** (`action=tv_menu`, id 30016).
- `show_movies_menu(ctx)`: Search movies (`action=search`, id 30001) + Recent movie
  searches (`action=history`, id 30002).
- `show_tv_menu(ctx)`: Search TV show (`action=tv_search`, id 30010) + Recent TV shows
  (`action=tv_history`, id 30011).
- `run()` dispatches the two new actions `movies_menu`, `tv_menu`.
- New localized strings: `30015` "Movies" (cs "Filmy"), `30016` "TV shows" (cs "Seriály").
  Both `.po` files gain the same ids. Existing item labels/actions are unchanged, only
  relocated under their folder.

### 4. Test fake (conftest.py)

`Dialog.numeric` records the `default` argument so pre-fill can be asserted:
`def numeric(self, ntype, heading, default="", *a, **k): Dialog.numerics.append((ntype, heading, default)); return <queued or _next_numeric>`.
`setup_function` already clears `numerics`.

## Testing

`.venv/bin/python -m pytest` (no Kodi/network):

- **EpisodeHistory** (`tests/test_history.py`): add→recent returns the record; dedupe by
  show (case-insensitive) keeps one entry, most-recent-first; `get` returns the latest
  matching record and `None` when absent; cap at `limit`; `recent()` skips legacy string
  entries (write `["Old", "Names"]` to the file → `recent() == []`); `clear` empties it.
- **Router** (`tests/test_router.py`):
  - `show_tv_history`: seed two records; the list items are labelled `Show  •  S01E02`
    and route to `action=tv_episode&show=<show>`.
  - picking records: run `tv_search` with a title and season/episode → `_tv_history().get(show)`
    equals `{season, episode}`; the produced search query is `"<show> S%02dE%02d"`.
  - pre-fill: seed a record for a show, run `action=tv_episode&show=<show>` → the two
    `Dialog.numeric` calls were passed the last-watched values as their `default`
    (assert via the recorded `numerics`).
  - cancel: empty season (or episode) → no record added, no search.
  - Update the existing `test_tv_history_lists_shows` to seed via
    `EpisodeHistory.add(show, s, e)` and assert the label contains the show.
  - Root menu: exactly two folder items routing to `movies_menu` and `tv_menu`.
  - `movies_menu` submenu lists two items routing to `search` and `history`;
    `tv_menu` submenu lists two items routing to `tv_search` and `tv_history`.

## Non-functional notes

- Runtime stays dependency-free; `Dialog().numeric` already accepts a default value.
- Backward compatible: a legacy string-list `tv_history.json` is tolerated (dropped and
  repopulated); no migration step required.
- The episode-history feature adds no new localized strings (the `S01E02` token is a code
  format); the menu-grouping change adds two: `30015` "Movies", `30016` "TV shows".
