# prehraj.to Addon — TV shows, named subtitles, fanart, icon & likes fixes

**Date:** 2026-07-02
**Addon:** `plugin.video.prehrajto` (builds on the existing addon)
**Target:** Kodi 19 (Matrix)+ · Python 3 · no external runtime dependencies

## Purpose

Five enhancements:

1. **Named subtitles** — show each subtitle in Kodi under its `tracks[].label`.
2. **Movies vs TV shows** — separate flows; TV shows add a numeric season/episode
   picker and easy re-selection of episodes from a previously searched show.
3. **Likes fix** — the `♥` glyph renders wrong in the user's skin; move likes out
   of the list label into the item info/plot as plain text.
4. **Fanart previews** — expose a preview frame as item fanart (Kodi can't cycle
   hover frames; this is the achievable subset).
5. **Icon** — build the addon icon from the real site logo (dark-theme wordmark
   recolored for legibility), not the favicon.

## Confirmed decisions

- Season/episode selection: **numeric entry** (two prompts).
- TV episode search string: **`"<title> S01E02"`** (zero-padded, no space).
- Likes: **info/plot only**, plain localized text — not in the list label.
- Thumbnails: **fanart from a preview frame** fallback (no hover cycling).
- Subtitles are **downloaded at play time** (required to control display names).

## Confirmed site facts (verified 2026-07-02)

- Detail page `tracks` entries look like:
  `{ file: "https://…/<hash>.vtt?token=…", "default": true, label: "CZE - 8138711 - cze", kind: "captions" }`
  — each has a human `label` and a signed `.vtt` `file` URL.
- Result thumbnails are `https://thumb.prehrajto.cz//<h>/<a>/<s>/<hash>/1.jpg`, with
  hover frames `1.jpg … 15.jpg` (count varies per video; higher frames may 404).
- Logo SVGs (from `main.css`):
  - light theme: `/public/build/images/prehrajto_logo.563585de.svg` (red play `#e23239` + black wordmark)
  - dark theme: `/public/build/images/prehrajto_logo-dark.afea642d.svg` (gray play + black wordmark)
  Both wordmarks are dark; for a dark-background icon the wordmark is recolored white.

## Interface change

`Stream` subtitles change from a list of URL strings to a list of `(label, url)`
tuples:

- Before: `Stream = namedtuple("Stream", "sources subtitles")` with `subtitles: [url]`
- After: `subtitles: [(label, url)]`

Affected: `scraper.parse_subtitles`/`parse_stream`/`resolve`, `router.play`, the
fake `xbmcgui` in `conftest.py`, and their tests. Enumerated in the plan.

## Changes

### 1. Named subtitles (scraper.py + router.py)

- `scraper.parse_subtitles(html) -> list[(label, url)]` — parse each `tracks` entry's
  `label` and `file`. Regex parses within all `tracks = [...]` arrays (reuse
  `_js_array_bodies`); dedupe by url, preserve order.
- `parse_stream` returns `Stream(sources, subtitles)` where `subtitles` is the
  `(label, url)` list.
- `scraper.sanitize_filename(label) -> str` — pure helper: keep the label text,
  strip/replace characters unsafe for filenames (`/ \ : * ? " < > |` and control
  chars → `_`), collapse whitespace, trim, cap length (~100). Ensures a usable,
  readable filename that Kodi shows as the subtitle name.
- `scraper.download(url, timeout) -> bytes` — fetch raw bytes (same UA as `_get`).
- `router.play`:
  - Resolve stream (unchanged quality-selection flow).
  - Prepare a clean subtitles dir under the addon profile
    (`special://profile/addon_data/plugin.video.prehrajto/subs/`): remove any
    existing files, recreate.
  - For each `(label, url)` in `stream.subtitles`: download bytes, write to
    `subs/<sanitize_filename(label)>.vtt`; collect the local path. Skip on error.
  - `listitem.setSubtitles([local paths])` (only if any succeeded).
  - Build/resolve the play URL as today (`|User-Agent=`), `setResolvedUrl`.
- Filesystem writes use `xbmcvfs` (translatePath + open) so it works on all
  platforms; downloading uses `scraper.download`.

### 2. Movies vs TV shows (router.py + history.py + strings.po)

Root menu (`show_menu`) items:
1. Search movies → `action=search` (existing movie flow).
2. Search TV show → `action=tv_search`.
3. Recent movie searches → `action=history` (existing).
4. Recent TV shows → `action=tv_history`.

Histories: reuse `History`; two files under the profile dir — `history.json`
(movies, existing) and `tv_history.json` (show titles). Add `_tv_history()` helper
mirroring `_history()`.

New handlers:
- `do_tv_search(ctx)`: prompt show title (`Dialog().input`); if empty, end. Add
  title to TV history. Then run the episode picker for that title.
- `pick_and_play_episode(ctx, show)` (used by both new-search and recent-show):
  prompt Season and Episode via `Dialog().numeric(0, heading)`; if cancelled
  (empty), end directory. Build query `"<show> S%02dE%02d" % (season, episode)`
  and call `render_results(ctx, query, 1)`.
- `show_tv_history(ctx)`: like `show_history` but from `tv_history.json`; each item
  routes to `action=tv_episode&show=<title>`; include a "Clear history" item →
  `action=tv_history_clear`.
- `clear_tv_history(ctx)`: clear `tv_history.json`, refresh.

Router `run` dispatch adds: `tv_search`, `tv_episode` (calls
`pick_and_play_episode` with `params['show']`), `tv_history`, `tv_history_clear`.

TV results reuse `render_results`/`action=results`, so pagination and the play
path are shared with movies. `scraper.search` is unchanged (query is just a string).

Localized strings (new ids): Search movies, Search TV show, Recent movie searches,
Recent TV shows, Season, Episode (headings), and the likes label (below). Existing
strings may be relabeled (e.g. 30001 "Search" → "Search movies"). English msgid +
Czech msgstr for each.

### 3. Likes → info/plot only (gui.py)

- `_result_label(result)`: append only non-empty `size` (drop likes and the heart).
  → `"Title  •  6.05 GB"` (or just the title if no size).
- `make_video_item`: plot lists non-empty parts as plain text — size and, if
  present, `"<LikesWord>: <n>"` (localized, e.g. "Likes: 18" / "Líbí: 18"). No
  `♥`/special glyph anywhere.

### 4. Fanart from a preview frame (gui.py)

- `_fanart_from_thumb(thumb) -> str`: if the thumb matches `.../<hash>/<n>.jpg`,
  return the same URL with the frame replaced by a mid frame (e.g. `8.jpg`);
  otherwise return the thumb unchanged. Pure helper.
- `make_video_item`: if `result.thumb`, also `setArt({..., "fanart": _fanart_from_thumb(thumb)})`.
  Missing frames degrade gracefully in Kodi (no fanart shown).

### 5. Icon from the dark logo (resources/icon.png)

- Regenerate `plugin.video.prehrajto/resources/icon.png` (512×512) from the site
  logo SVG recolored to a **white wordmark + red play button** on a near-black
  (`#141619`) square, centered. Build step: fetch the logo SVG, set the root
  `<svg fill="#ffffff">` (paths without an explicit fill become white; the red
  play keeps its own `#e23239`), rasterize with ImageMagick to 512×512.
- `addon.xml` already declares `<assets><icon>resources/icon.png</icon></assets>`;
  no manifest change beyond the new image bytes.

## Testing

Pure/fixture unit tests (`.venv/bin/python -m pytest`, no Kodi/network):

- `scraper.parse_subtitles` on `detail.html` → 4 `(label, url)` pairs; labels match
  the fixture (e.g. contains `"CZE"`), urls contain `.vtt`.
- `scraper.parse_stream` → `Stream.subtitles` is the `(label,url)` list; sources
  still sorted 1080p-first.
- `scraper.sanitize_filename` → strips unsafe chars, keeps readable text, caps length.
- `gui._result_label` → contains size, does NOT contain likes or `♥`.
- `gui.make_video_item` → plot contains the likes text when likes present; fanart
  art key set; label has size only.
- `gui._fanart_from_thumb` → swaps frame number; passes through non-matching urls.
- TV query builder (the `S%02dE%02d` composition) → `"Show S01E02"` for (1,2),
  `"Show S12E34"` for (12,34).
- Router (fake `xbmc`): extend `conftest` fake `Dialog` with `numeric` (records
  calls, returns configurable value) and `setSubtitles`/download hooks.
  - `tv_search` / `tv_episode`: with fake numeric returning season/episode, the
    rendered results query equals `"<show> S01E02"` (assert via monkeypatched
    `scraper.search`).
  - `tv_history` lists recent shows; selecting routes to `tv_episode`.
  - `play`: monkeypatch `scraper.resolve` (with `(label,url)` subs) and
    `scraper.download`; assert `setSubtitles` receives local paths whose basenames
    equal the sanitized labels.
- Manifest test already asserts the icon is a valid PNG; keep it (icon regenerated).

## Non-functional notes

- Runtime stays dependency-free (ImageMagick is a build-time tool for the icon only).
- Subtitles are transient (downloaded per play into the profile `subs/` dir, cleared
  each play); signed URLs are fetched at play time, never cached.
- Individual failures (a subtitle download, a missing fanart frame, an empty
  numeric prompt) degrade gracefully without breaking playback or navigation.
