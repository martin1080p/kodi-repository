from resources.lib import gui, scraper


def _result(**over):
    base = dict(path="/x/" + "0" * 16, title="T", thumb="http://th/1.jpg",
                duration="01:02:03", size="1.5 GB", likes="7")
    base.update(over)
    return scraper.Result(**base)


def test_make_video_item_full():
    li = gui.make_video_item(_result())
    assert li.getProperty("IsPlayable") == "true"
    assert li.info.get("mediatype") == "video"
    assert li.info.get("duration") == 3723
    assert li.info.get("title") == "T"
    assert li.art.get("thumb") == "http://th/1.jpg"


def test_make_video_item_no_thumb_no_duration():
    li = gui.make_video_item(_result(thumb="", duration=""))
    assert li.art == {}
    assert "duration" not in li.info


def test_result_label_has_size_not_likes():
    label = gui._result_label(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert label == "Matrix  •  6.05 GB"
    assert "18" not in label
    assert "♥" not in label


def test_result_label_title_only():
    assert gui._result_label(_result(title="Matrix", size="", likes="")) == "Matrix"


def test_likes_go_into_plot():
    li = gui.make_video_item(_result(title="Matrix", size="6.05 GB", likes="18"))
    assert "18" in li.info.get("plot", "")
    assert "6.05 GB" in li.info.get("plot", "")
    assert "18" not in li.label
    assert "♥" not in li.info.get("plot", "")


def test_no_likes_no_likes_in_plot():
    li = gui.make_video_item(_result(title="Matrix", size="6.05 GB", likes=""))
    assert li.info.get("plot") == "6.05 GB"


def test_fanart_from_thumb():
    assert gui._fanart_from_thumb(
        "https://thumb.prehrajto.cz//8/9/d/hash/1.jpg"
    ) == "https://thumb.prehrajto.cz//8/9/d/hash/8.jpg"
    # non-matching URL passes through unchanged
    assert gui._fanart_from_thumb("http://x/pic.png") == "http://x/pic.png"
    assert gui._fanart_from_thumb("") == ""


def test_make_video_item_sets_fanart():
    li = gui.make_video_item(_result(thumb="https://thumb.prehrajto.cz//a/b/c/h/1.jpg"))
    assert li.art.get("fanart") == "https://thumb.prehrajto.cz//a/b/c/h/8.jpg"
