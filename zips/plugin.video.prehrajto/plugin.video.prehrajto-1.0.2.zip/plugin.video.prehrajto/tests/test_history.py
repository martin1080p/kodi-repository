from resources.lib.history import History, EpisodeHistory


def test_add_and_recent(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("matrix")
    h.add("avatar")
    h.add("matrix")  # moves to front, no duplicate
    assert h.recent() == ["matrix", "avatar"]


def test_add_ignores_blank(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("   ")
    assert h.recent() == []


def test_limit(tmp_path):
    h = History(str(tmp_path / "h.json"), limit=3)
    for q in ["a", "b", "c", "d"]:
        h.add(q)
    assert h.recent() == ["d", "c", "b"]


def test_clear(tmp_path):
    h = History(str(tmp_path / "h.json"))
    h.add("x")
    h.clear()
    assert h.recent() == []


def test_recent_missing_file(tmp_path):
    h = History(str(tmp_path / "does_not_exist.json"))
    assert h.recent() == []


def test_bare_filename_no_directory(tmp_path, monkeypatch):
    """Regression test: History with bare filename (no directory component) should not crash."""
    monkeypatch.chdir(tmp_path)
    h = History("bare_name.json")
    h.add("x")
    assert h.recent() == ["x"]


def test_episode_add_and_recent(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Simpsonovi", "1", "2")   # numeric() returns strings
    assert h.recent() == [{"show": "Simpsonovi", "season": 1, "episode": 2}]


def test_episode_dedupe_by_show_case_insensitive(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Show", 1, 2)
    h.add("Other", 3, 4)
    h.add("show", 5, 6)   # same show → replace + move to front
    rec = h.recent()
    assert rec[0] == {"show": "show", "season": 5, "episode": 6}
    assert [r["show"] for r in rec] == ["show", "Other"]


def test_episode_get(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("Show", 1, 2)
    assert h.get("SHOW") == {"show": "Show", "season": 1, "episode": 2}
    assert h.get("missing") is None


def test_episode_limit(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"), limit=2)
    h.add("a", 1, 1)
    h.add("b", 1, 1)
    h.add("c", 1, 1)
    assert [r["show"] for r in h.recent()] == ["c", "b"]


def test_episode_ignores_blank_show(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("   ", 1, 2)
    assert h.recent() == []


def test_episode_skips_legacy_string_entries(tmp_path):
    p = tmp_path / "tv.json"
    p.write_text('["Old", "Names"]', encoding="utf-8")
    h = EpisodeHistory(str(p))
    assert h.recent() == []
    assert h.get("Old") is None


def test_episode_clear(tmp_path):
    h = EpisodeHistory(str(tmp_path / "tv.json"))
    h.add("x", 1, 1)
    h.clear()
    assert h.recent() == []
