import os
import re
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ADDON_XML = os.path.join(ROOT, "addon.xml")


def test_addon_xml_wellformed_and_ids():
    tree = ET.parse(ADDON_XML)
    root = tree.getroot()
    assert root.get("id") == "plugin.video.prehrajto"
    # version is present and looks like a dotted release number, but the exact
    # value is not pinned here so releases don't require a test edit.
    version = root.get("version")
    assert version and re.match(r"^\d+\.\d+\.\d+", version)
    imports = [e.get("addon") for e in root.iter("import")]
    assert "xbmc.python" in imports
    src = [e for e in root.iter("extension")
           if e.get("point") == "xbmc.python.pluginsource"]
    assert src and src[0].get("library") == "addon.py"


def test_language_files_present():
    base = os.path.join(ROOT, "resources", "language")
    for lang in ("resource.language.cs_cz", "resource.language.en_gb"):
        assert os.path.exists(os.path.join(base, lang, "strings.po"))


def test_icon_declared_and_present():
    tree = ET.parse(ADDON_XML)
    icons = [e.text for e in tree.getroot().iter("icon")]
    assert "resources/icon.png" in icons
    icon_path = os.path.join(ROOT, "resources", "icon.png")
    assert os.path.exists(icon_path)
    with open(icon_path, "rb") as f:
        header = f.read(8)
    # PNG magic number
    assert header == b"\x89PNG\r\n\x1a\n"
    assert os.path.getsize(icon_path) > 1000


def test_author_metadata():
    tree = ET.parse(ADDON_XML)
    root = tree.getroot()
    assert "Shalty" in (root.get("provider-name") or "")
    descriptions = " ".join(e.text or "" for e in root.iter("description"))
    assert "Shalty (martin1080p)" in descriptions
