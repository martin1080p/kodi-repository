import os
import re

from resources.lib import scraper

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def load(name):
    with open(os.path.join(FIXTURES, name), encoding="utf-8") as f:
        return f.read()


def test_parse_results_specific_card():
    results = scraper.parse_results(load("search.html"))
    assert len(results) >= 5
    by_path = {r.path: r for r in results}
    key = "/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/89d453af0b2a71d2"
    assert key in by_path
    r = by_path[key]
    assert "Matrix 1" in r.title
    assert r.duration == "02:16:18"
    assert r.size == "6.05 GB"
    assert r.thumb.startswith("https://thumb.prehrajto.cz")


def test_parse_results_specific_card_modifier_class_size():
    # This card's size tag uses the modifier-class variant
    # class="video__tag video__tag--size video__tag--size-alone", which the
    # old _SIZE_RE (requiring `video__tag--size"` immediately) failed to match.
    results = scraper.parse_results(load("search.html"))
    by_path = {r.path: r for r in results}
    key = "/matrix-4k-cz/895d830c58fa0caf"
    assert key in by_path
    r = by_path[key]
    assert "Matrix 4K" in r.title
    assert r.duration == "02:16:18"
    assert r.size == "47.35 GB"


def test_parse_results_all_valid():
    results = scraper.parse_results(load("search.html"))
    for r in results:
        assert r.title
        assert re.match(r"^/.+/[0-9a-f]{16}$", r.path)
    # Every card in the fixture has a size tag; regression guard for the
    # modifier-class bug that previously left ~76% of cards with size=="".
    assert all(r.size for r in results)


def test_parse_results_likes():
    results = scraper.parse_results(load("search.html"))
    by_path = {r.path: r for r in results}
    # Known card with a like count in the fixture:
    assert by_path["/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/"
                   "89d453af0b2a71d2"].likes == "1"
    # Known card with no likes tag → empty string:
    assert by_path["/matrix-4k-cz/895d830c58fa0caf"].likes == ""
    # Every result exposes a likes field (str):
    assert all(isinstance(r.likes, str) for r in results)


def test_parse_has_next():
    html = load("search.html")
    assert scraper.parse_has_next(html, 1) is True
    assert scraper.parse_has_next(html, 999) is False


def test_duration_to_seconds():
    assert scraper.duration_to_seconds("02:16:18") == 8178
    assert scraper.duration_to_seconds("01:00") == 60
    assert scraper.duration_to_seconds("") == 0
    assert scraper.duration_to_seconds("N/A") == 0


def test_parse_sources_labels_and_urls():
    src = scraper.parse_sources(load("detail.html"))
    labels = {label for label, _ in src}
    assert "1080p" in labels
    assert "720p" in labels
    for _, url in src:
        assert ".mp4" in url


def test_sort_sources():
    assert scraper.sort_sources([("720p", "a"), ("1080p", "b")]) == [
        ("1080p", "b"), ("720p", "a")]
    assert scraper.sort_sources(
        [("480p", "x"), ("4k", "y"), ("1080p", "z")])[0] == ("4k", "y")
    assert scraper.sort_sources([]) == []


def test_parse_subtitles():
    subs = scraper.parse_subtitles(load("detail.html"))
    assert len(subs) == 4
    assert all(isinstance(s, tuple) and len(s) == 2 for s in subs)
    labels = [label for label, _url in subs]
    assert any("CZE" in label for label in labels)
    assert all(".vtt" in url for _label, url in subs)


def test_parse_stream_sources_and_subs():
    html = load("detail.html")
    stream = scraper.parse_stream(html)
    labels = [label for label, _url in stream.sources]
    assert labels == ["1080p", "720p"]          # highest quality first
    assert all(".mp4" in url for _label, url in stream.sources)
    assert len(stream.subtitles) == 4


# Synthetic HTML with the VideoJS fallback block FIRST and the JWPlayer
# sources/tracks arrays SECOND. This is the reverse of the fixture's actual
# order and proves parse_sources/parse_subtitles no longer depend on which
# block appears first (they must scan ALL matching arrays, not just the
# first re.search() match).
_REVERSED_ORDER_HTML = """
<script>
    var player = "videojs";
    if (player === "jwplayer") {
        // unreachable branch kept for realism; not used by this test
    } else {
        var videos = [];
        videos.push({ src: "https://cdn.example/videojs-1080.mp4", type: 'video/mp4', res: '1080', label: '1080p', default: true });
        videos.push({ src: "https://cdn.example/videojs-720.mp4", type: 'video/mp4', res: '720', label: '720p' });

        var tracks = [
            { src: "https://cdn.example/videojs-cze.vtt", srclang: "cze", label: "CZE", kind: "captions" }
        ];

        var sources = {
            'videos': videos,
            'tracks': tracks
        };
    }

    var sources = [
        { file: "https://cdn.example/jw-720.mp4", label: '720p' }
        ,
        { file: "https://cdn.example/jw-1080.mp4", label: '1080p' }
    ];
    var tracks = [
        { file: "https://cdn.example/jw-cze.vtt",  "default": true ,  label: "CZE", kind: "captions" },
        { file: "https://cdn.example/jw-eng.vtt",  label: "ENG", kind: "captions" }
    ];
</script>
"""


def test_parse_sources_order_independent_of_block_order():
    src = scraper.parse_sources(_REVERSED_ORDER_HTML)
    urls = {url for _, url in src}
    # Real JWPlayer pairs are found even though the VideoJS block came first.
    assert ("720p", "https://cdn.example/jw-720.mp4") in src
    assert ("1080p", "https://cdn.example/jw-1080.mp4") in src
    # VideoJS's object-form `sources` (with `src:` not `file:`) contributes
    # nothing.
    assert "https://cdn.example/videojs-1080.mp4" not in urls
    assert "https://cdn.example/videojs-720.mp4" not in urls


def test_sort_sources_order_independent_of_block_order():
    src = scraper.parse_sources(_REVERSED_ORDER_HTML)
    assert scraper.sort_sources(src)[0][1] == "https://cdn.example/jw-1080.mp4"


def test_parse_subtitles_order_independent_of_block_order():
    subs = scraper.parse_subtitles(_REVERSED_ORDER_HTML)
    assert subs == [
        ("CZE", "https://cdn.example/jw-cze.vtt"),
        ("ENG", "https://cdn.example/jw-eng.vtt"),
    ]
    # VideoJS's tracks array uses src: not file:, so it contributes nothing.
    assert all("videojs" not in url for _label, url in subs)


def test_sanitize_filename():
    assert scraper.sanitize_filename("CZE - 8138711 - cze") == "CZE - 8138711 - cze"
    assert scraper.sanitize_filename('a/b\\c:d*e?f"g<h>i|j') == "a_b_c_d_e_f_g_h_i_j"
    assert scraper.sanitize_filename("  x\ty  ") == "x y"
    assert scraper.sanitize_filename("") == "subtitle"
    assert len(scraper.sanitize_filename("z" * 300)) <= 100


def test_fixture_results_unchanged_after_fix():
    # Regression guard: the real fixture (which happens to have the JWPlayer
    # block first) must still yield exactly the same results as before.
    html = load("detail.html")
    src = scraper.parse_sources(html)
    labels = {label for label, _ in src}
    assert labels == {"720p", "1080p"}
    subs = scraper.parse_subtitles(html)
    assert len(subs) == 4
    best_url = dict(src)["1080p"]
    assert scraper.sort_sources(src)[0][1] == best_url


def test_search_uses_parser(monkeypatch):
    captured = {}

    def fake_get(url, timeout=None):
        captured["url"] = url
        return load("search.html")

    monkeypatch.setattr(scraper, "_get", fake_get)
    results, has_next = scraper.search("matrix", 1)
    assert captured["url"] == "https://prehraj.to/hledej/matrix"
    assert len(results) >= 5
    assert has_next is True


def test_search_page_two_url(monkeypatch):
    captured = {}

    def fake_get(url, timeout=None):
        captured["url"] = url
        return load("search.html")

    monkeypatch.setattr(scraper, "_get", fake_get)
    scraper.search("star wars", 2)
    assert captured["url"] == (
        "https://prehraj.to/hledej/star%20wars"
        "?videoListing-visualPaginator-page=2")


def test_resolve_returns_stream(monkeypatch):
    monkeypatch.setattr(scraper, "_get", lambda url, timeout=None: load("detail.html"))
    stream = scraper.resolve("/matrix-1-1999-cz-dabing-ultra-hd-2160p-4k/89d453af0b2a71d2")
    assert stream is not None
    assert stream.sources and ".mp4" in stream.sources[0][1]
    assert len(stream.subtitles) == 4
