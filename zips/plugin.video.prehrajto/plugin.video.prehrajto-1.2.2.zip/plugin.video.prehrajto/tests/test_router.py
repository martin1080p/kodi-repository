import json
import os
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import router, scraper


def setup_function(_):
    xbmcplugin.items.clear()
    xbmcplugin.resolved.clear()
    xbmcplugin.ended.clear()
    xbmcgui.Dialog.notifications.clear()
    xbmcgui.Window.props.clear()
    xbmcgui.Dialog.selects.clear()
    xbmcgui.Dialog.numerics.clear()
    xbmcgui.Dialog._numeric_returns = []
    xbmcgui.Dialog._next_select = 0
    xbmcgui.Dialog._next_numeric = "1"
    xbmc.builtins.clear()


def _results_query(builtin):
    # builtin looks like: Container.Update(<url>,replace)
    assert builtin.startswith("Container.Update(") and builtin.endswith(",replace)")
    url = builtin[len("Container.Update("):-len(",replace)")]
    params = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
    assert params["action"] == "results"
    return params["query"]


def test_ctx_url_roundtrip():
    ctx = router.Ctx("plugin://plugin.video.prehrajto/", 7)
    url = ctx.url(action="play", path="/a/b")
    assert url.startswith("plugin://plugin.video.prehrajto/?")
    q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
    assert q["action"] == "play"
    assert q["path"] == "/a/b"


def test_menu_lists_entries():
    router.run(["plugin://plugin.video.prehrajto/", "7", ""])
    assert len(xbmcplugin.items) == 2
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["movies_menu", "tv_menu"]
    assert xbmcplugin.items[0][3] is True   # Movies folder
    assert xbmcplugin.items[1][3] is True   # TV shows folder


def test_movies_menu_lists_search_and_history():
    router.run(["plugin://x/", "7", "?action=movies_menu"])
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["search", "history"]


def test_tv_menu_lists_search_and_history():
    router.run(["plugin://x/", "7", "?action=tv_menu"])
    actions = []
    for _h, url, _li, _f in xbmcplugin.items:
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        actions.append(q["action"])
    assert actions == ["tv_search", "tv_history"]


def test_results_renders_videos_plus_next(monkeypatch):
    def fake_search(query, page, timeout=None):
        hash16 = "0" * 16
        return ([scraper.Result("/a/" + hash16, "A", "t", "01:00", "1 GB"),
                 scraper.Result("/b/" + hash16, "B", "t", "02:00", "2 GB")], True)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=matrix&page=1"])
    assert len(xbmcplugin.items) == 3          # 2 videos + Next page
    assert xbmcplugin.items[-1][3] is True     # last is a folder
    assert xbmcplugin.items[0][3] is False     # videos are not folders


def test_play_single_source_downloads_named_subtitles(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")],
            [("CZE - 8138711 - cze", "http://x/cze.vtt"),
             ("ENG", "http://x/eng.vtt")]))
    monkeypatch.setattr(scraper, "download", lambda url, timeout=None: b"WEBVTT\n")
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcgui.Dialog.selects) == 0
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert li.path.startswith("http://x/v.mp4|User-Agent=")
    import os
    assert [os.path.basename(p) for p in li.subs] == [
        "CZE - 8138711 - cze.vtt", "ENG.vtt"]


def test_play_subtitle_download_failure_is_skipped(monkeypatch):
    def flaky(url, timeout=None):
        if "cze" in url:
            raise OSError("boom")
        return b"WEBVTT\n"
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")],
            [("CZE", "http://x/cze.vtt"), ("ENG", "http://x/eng.vtt")]))
    monkeypatch.setattr(scraper, "download", flaky)
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    import os
    assert [os.path.basename(p) for p in li.subs] == ["ENG.vtt"]


def test_play_subtitle_duplicate_path_is_deduped(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "http://x/v.mp4")],
            [("CZE", "http://x/a.vtt"), ("CZE", "http://x/b.vtt")]))
    monkeypatch.setattr(scraper, "download", lambda url, timeout=None: b"WEBVTT\n")
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    import os
    assert [os.path.basename(p) for p in li.subs] == ["CZE.vtt"]


def test_play_multi_source_shows_dialog_and_uses_choice(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "u1080"), ("720p", "u720")], []))
    xbmcgui.Dialog._next_select = 1                   # user picks 720p
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert len(xbmcgui.Dialog.selects) == 1
    _heading, options = xbmcgui.Dialog.selects[0]
    assert options == ["1080p", "720p"]
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True
    assert li.path.startswith("u720|User-Agent=")


def test_play_multi_source_cancel(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "u1080"), ("720p", "u720")], []))
    xbmcgui.Dialog._next_select = -1                  # user cancels
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, _li = xbmcplugin.resolved[0]
    assert ok is False
    assert xbmcgui.Window.props["TMDbHelper.PlayerFailed"] == "true"


def test_play_missing_stream_fails_gracefully(monkeypatch):
    monkeypatch.setattr(scraper, "resolve", lambda path, timeout=None: None)
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _, ok, _li = xbmcplugin.resolved[0]
    assert ok is False


def test_no_results_notifies(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda query, page, timeout=None: ([], False))
    router.run(["plugin://x/", "7", "?action=results&query=matrix&page=1"])
    assert len(xbmcgui.Dialog.notifications) == 1
    heading, message = xbmcgui.Dialog.notifications[0]
    assert heading == "prehraj.to"
    assert message == "S30006"


def test_episode_query():
    assert router._episode_query("Show", 1, 2) == "Show S01E02"
    assert router._episode_query("Show", 12, 34) == "Show S12E34"


def test_tv_search_redirects_to_results(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda *a, **k: ([], False))
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert _results_query(xbmc.builtins[-1]) == "Simpsonovi S01E02"
    assert xbmcplugin.items == []   # dialog action renders nothing itself


def test_tv_episode_redirects_to_results(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda *a, **k: ([], False))
    xbmcgui.Dialog._numeric_returns = ["3", "7"]
    router.run(["plugin://x/", "7", "?action=tv_episode&show=Friends"])
    assert _results_query(xbmc.builtins[-1]) == "Friends S03E07"


def test_do_search_redirects_to_results():
    router._history().clear()
    xbmcgui.Dialog._next_input = "matrix"
    router.run(["plugin://x/", "7", "?action=search"])
    assert _results_query(xbmc.builtins[-1]) == "matrix"
    assert "matrix" in router._history().recent()
    assert xbmcplugin.items == []   # no items rendered by the search action itself


def test_tv_search_cancel_on_empty_season(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = [""]   # cancelled season
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert xbmcplugin.resolved == [] and xbmcplugin.items == []
    # Cancel must end the directory SUCCESSFULLY — a failed GetDirectory makes
    # Kodi fall back to the empty root and exit the addon.
    assert xbmcplugin.ended == [True]
    assert not any(b.startswith("Container.Update(") for b in xbmc.builtins)


def test_tv_search_cancel_on_empty_episode(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    xbmcgui.Dialog._next_input = "Show"
    xbmcgui.Dialog._numeric_returns = ["1", ""]   # valid season, cancelled episode
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert xbmcplugin.resolved == [] and xbmcplugin.items == []
    assert xbmcplugin.ended == [True]
    assert not any(b.startswith("Container.Update(") for b in xbmc.builtins)


def test_search_cancel_ends_successfully(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    xbmcgui.Dialog._next_input = ""   # cancelled keyboard
    router.run(["plugin://x/", "7", "?action=search"])
    assert xbmcplugin.ended == [True]
    assert not any(b.startswith("Container.Update(") for b in xbmc.builtins)


def test_tv_history_lists_shows():
    h = router._tv_history()
    h.clear()
    h.add("Alpha", 1, 2)
    h.add("Beta", 3, 4)
    router.run(["plugin://x/", "7", "?action=tv_history"])
    labels = [li.label for _h, _u, li, _f in xbmcplugin.items]
    assert "Beta  •  S03E04" in labels
    assert "Alpha  •  S01E02" in labels
    urls = [u for _h, u, _li, _f in xbmcplugin.items]
    assert any("action=tv_episode" in u and "show=Beta" in u for u in urls)


def test_tv_search_records_episode(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda q, p, t=None: ([], False))
    router._tv_history().clear()
    xbmcgui.Dialog._next_input = "Simpsonovi"
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert router._tv_history().get("Simpsonovi") == {
        "show": "Simpsonovi", "season": 1, "episode": 2}


def test_tv_episode_does_not_prefill(monkeypatch):
    monkeypatch.setattr(scraper, "search", lambda q, p, t=None: ([], False))
    h = router._tv_history()
    h.clear()
    h.add("Friends", 3, 7)   # a prior record exists
    xbmcgui.Dialog._numeric_returns = ["1", "2"]
    router.run(["plugin://x/", "7", "?action=tv_episode&show=Friends"])
    # The Season/Episode prompts start blank even though a prior record exists.
    defaults = [d for _t, _hd, d in xbmcgui.Dialog.numerics]
    assert defaults == ["", ""]
    # It still records what was picked this time.
    assert router._tv_history().get("Friends") == {
        "show": "Friends", "season": 1, "episode": 2}


def test_tv_search_cancel_records_nothing(monkeypatch):
    monkeypatch.setattr(scraper, "search",
                        lambda *a, **k: (_ for _ in ()).throw(
                            AssertionError("search must not run")))
    router._tv_history().clear()
    xbmcgui.Dialog._next_input = "Nope"
    xbmcgui.Dialog._numeric_returns = ["1", ""]   # cancel on episode
    router.run(["plugin://x/", "7", "?action=tv_search"])
    assert router._tv_history().get("Nope") is None


def test_compose_query_episode():
    assert router._compose_query(
        {"query": "Simpsonovi", "season": "1", "episode": "2"}) == "Simpsonovi S01E02"
    assert router._compose_query(
        {"query": "X", "season": "12", "episode": "34"}) == "X S12E34"


def test_compose_query_movie_year():
    assert router._compose_query({"query": "Matrix", "year": "1999"}) == "Matrix 1999"


def test_compose_query_plain():
    assert router._compose_query({"query": "matrix"}) == "matrix"
    assert router._compose_query({}) == ""


def test_compose_query_bad_season_falls_back():
    assert router._compose_query(
        {"query": "X", "season": "a", "episode": "b", "year": "1999"}) == "X 1999"
    assert router._compose_query({"query": "X", "season": "a", "episode": "b"}) == "X"


def test_results_action_episode(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["q"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=Simpsonovi&season=1&episode=2"])
    assert captured["q"] == "Simpsonovi S01E02"


def test_results_action_movie_year(monkeypatch):
    captured = {}

    def fake_search(query, page, timeout=None):
        captured["q"] = query
        return ([], False)

    monkeypatch.setattr(scraper, "search", fake_search)
    router.run(["plugin://x/", "7", "?action=results&query=Matrix&year=1999"])
    assert captured["q"] == "Matrix 1999"


_CAPPED = ("1080p", "u1080?limitsize=100960772")


def test_play_hides_limited_sources(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream([_CAPPED, ("720p", "u720")], []))
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert xbmcgui.Dialog.selects == []               # only one left: no dialog
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True and li.path.startswith("u720|")


def test_play_all_limited_notifies_and_fails(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream([_CAPPED], []))
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert xbmcgui.Dialog.notifications[0][1] == "S30017"
    _handle, ok, _li = xbmcplugin.resolved[0]
    assert ok is False
    assert xbmcgui.Window.props["TMDbHelper.PlayerFailed"] == "true"


def test_play_limited_filter_can_be_disabled(monkeypatch):
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream([_CAPPED], []))
    monkeypatch.setattr(router._ADDON, "getSetting",
                        lambda key: "false" if key == "hide_limited" else "")
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    _handle, ok, li = xbmcplugin.resolved[0]
    assert ok is True and li.path.startswith("u1080?limitsize=")


def _settings(monkeypatch, **values):
    monkeypatch.setattr(router._ADDON, "getSetting", lambda key: values.get(key, ""))


_A = scraper.Result("/a/" + "0" * 16, "A", "t", "01:00", "1 GB")
_B = scraper.Result("/b/" + "0" * 16, "B", "t", "02:00", "2 GB")


def _search_and_resolve(monkeypatch):
    # A has only capped sources, B has a free one.
    monkeypatch.setattr(scraper, "search", lambda q, p, timeout=None: ([_A, _B], True))
    streams = {_A.path: [_CAPPED], _B.path: [("720p", "u720")]}
    monkeypatch.setattr(scraper, "resolve",
                        lambda path, timeout=None: scraper.Stream(streams[path], []))


def _item_paths():
    return [dict(urllib.parse.parse_qsl(url.split("?", 1)[1])).get("path")
            for _h, url, _li, _f in xbmcplugin.items]


def test_play_auto_quality_skips_dialog(monkeypatch):
    _settings(monkeypatch, auto_quality="true")
    monkeypatch.setattr(
        scraper, "resolve",
        lambda path, timeout=None: scraper.Stream(
            [("1080p", "u1080"), ("720p", "u720")], []))
    router.run(["plugin://x/", "7", "?action=play&path=/a/" + "0" * 16])
    assert xbmcgui.Dialog.selects == []
    assert xbmcplugin.resolved[0][2].path.startswith("u1080|")


def test_results_autoplay_lists_first_unlimited_only(monkeypatch):
    _settings(monkeypatch, auto_play="true")
    _search_and_resolve(monkeypatch)
    router.run(["plugin://x/", "7", "?action=results&query=m&autoplay=1"])
    assert _item_paths() == [_B.path]


def test_results_autoplay_after_failed_play_lists_all(monkeypatch):
    _settings(monkeypatch, auto_play="true")
    _search_and_resolve(monkeypatch)
    xbmcgui.Window.props[router._AUTOPLAY_FAILED] = "true"
    router.run(["plugin://x/", "7", "?action=results&query=m&autoplay=1"])
    assert _item_paths() == [_A.path, _B.path, None]   # + Next page
    assert router._AUTOPLAY_FAILED not in xbmcgui.Window.props


def test_results_autoplay_needs_setting(monkeypatch):
    _search_and_resolve(monkeypatch)
    router.run(["plugin://x/", "7", "?action=results&query=m&autoplay=1"])
    assert _item_paths() == [_A.path, _B.path, None]


def test_search_auto_play_plays_first_unlimited(monkeypatch):
    _settings(monkeypatch, auto_play="true")
    _search_and_resolve(monkeypatch)
    xbmcgui.Dialog._next_input = "matrix"
    router.run(["plugin://x/", "7", "?action=search"])
    assert _results_query(xbmc.builtins[0]) == "matrix"
    assert xbmc.builtins[1].startswith("PlayMedia(plugin://x/?action=play&path=%2Fb%2F")


def test_search_auto_play_without_filter_plays_first(monkeypatch):
    _settings(monkeypatch, auto_play="true", hide_limited="false")
    _search_and_resolve(monkeypatch)
    xbmcgui.Dialog._next_input = "matrix"
    router.run(["plugin://x/", "7", "?action=search"])
    assert xbmc.builtins[1].startswith("PlayMedia(plugin://x/?action=play&path=%2Fa%2F")


def test_compose_query_title_setting(monkeypatch):
    movie = {"query": "Pelíšky", "original": "Cosy Dens", "year": "1999"}
    episode = {"query": "Přátelé", "original": "Friends", "season": "1", "episode": "2"}
    assert router._compose_query(movie) == "Pelíšky 1999"          # default: localized
    _settings(monkeypatch, movie_original="true")
    assert router._compose_query(movie) == "Cosy Dens 1999"
    assert router._compose_query(episode) == "Přátelé S01E02"      # tv_original untouched
    _settings(monkeypatch, tv_original="true")
    assert router._compose_query(episode) == "Friends S01E02"
    assert router._compose_query(dict(episode, original="_")) == "Přátelé S01E02"
