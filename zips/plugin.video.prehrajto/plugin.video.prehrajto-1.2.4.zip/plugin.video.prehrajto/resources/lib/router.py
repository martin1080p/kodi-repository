import json
import os
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import gui, history, scraper

_ADDON = xbmcaddon.Addon()


def _(sid):
    return _ADDON.getLocalizedString(sid)


def _timeout():
    try:
        return int(float(_ADDON.getSetting("timeout")))
    except (ValueError, TypeError):
        return scraper.DEFAULT_TIMEOUT


def _enabled(key):
    return _ADDON.getSetting(key) == "true"


def _hide_limited():
    return _ADDON.getSetting("hide_limited") != "false"  # default on


def _history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.History(os.path.join(profile, "history.json"))


def _tv_history():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.EpisodeHistory(os.path.join(profile, "tv_history.json"))


def _title_choices():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return history.TitleChoices(os.path.join(profile, "title_choices.json"))


def _episode_query(show, season, episode):
    return "%s S%02dE%02d" % (show, int(season), int(episode))


def _choose_title(params):
    """TMDb Helper passes the localized and the original title ("_" when it
    has none). When they differ, ask which one to search for, unless an
    "always for this title" pick is remembered. None = user cancelled."""
    query = params.get("query", "")
    original = params.get("original", "")
    if original in ("", "_") or original == query:
        return query
    key = "%s|%s|%s" % ("tv" if params.get("season") else "movie", query, original)
    store = _title_choices()
    saved = store.get(key)
    if saved in (query, original):
        return saved
    always = " " + _(30066)
    labels = [query, original, query + always, original + always]
    index = xbmcgui.Dialog().select(_(30067), labels)
    if index < 0:
        return None
    title = (query, original)[index % 2]
    if index >= 2:
        store.set(key, title)
    return title


def _compose_query(params):
    query = _choose_title(params)
    if query is None:
        return None
    season = params.get("season")
    episode = params.get("episode")
    if season and episode:
        try:
            return _episode_query(query, season, episode)
        except (TypeError, ValueError):
            pass
    year = params.get("year")
    if year:
        return "%s %s" % (query, year)
    return query


def _episode_label(entry):
    return "%s  •  S%02dE%02d" % (entry["show"], entry["season"], entry["episode"])


def _notify(message):
    xbmcgui.Dialog().notification(_ADDON.getAddonInfo("name"), message)


def _prepare_subtitles(tracks):
    """Download subtitle tracks to the profile subs/ dir, named by label.
    Returns local file paths; skips any that fail to download/write."""
    if not tracks:
        return []
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    subs_dir = os.path.join(profile, "subs")
    try:
        if os.path.isdir(subs_dir):
            for fname in os.listdir(subs_dir):
                try:
                    os.remove(os.path.join(subs_dir, fname))
                except OSError:
                    pass
        os.makedirs(subs_dir, exist_ok=True)
    except OSError:
        return []
    paths = []
    seen = set()
    for label, url in tracks:
        path = os.path.join(subs_dir, scraper.sanitize_filename(label) + ".vtt")
        if path in seen:
            continue
        try:
            data = scraper.download(url, _timeout())
        except Exception:
            continue
        try:
            with open(path, "wb") as f:
                f.write(data)
        except OSError:
            continue
        paths.append(path)
        seen.add(path)
    return paths


class Ctx:
    def __init__(self, base, handle):
        self.base = base
        self.handle = handle

    def url(self, **kwargs):
        return self.base + "?" + urllib.parse.urlencode(kwargs)


def show_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="movies_menu"),
        gui.make_folder_item(_(30015)), True)       # Movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_menu"),
        gui.make_folder_item(_(30016)), True)        # TV shows
    xbmcplugin.endOfDirectory(ctx.handle)


def show_movies_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="search"),
        gui.make_folder_item(_(30001)), True)        # Search movies
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="history"),
        gui.make_folder_item(_(30002)), True)        # Recent movie searches
    xbmcplugin.endOfDirectory(ctx.handle)


def show_tv_menu(ctx):
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_search"),
        gui.make_folder_item(_(30010)), True)        # Search TV show
    xbmcplugin.addDirectoryItem(
        ctx.handle, ctx.url(action="tv_history"),
        gui.make_folder_item(_(30011)), True)        # Recent TV shows
    xbmcplugin.endOfDirectory(ctx.handle)


def do_search(ctx):
    query = (xbmcgui.Dialog().input(_(30005)) or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    _history().add(query)
    _go_to_results(ctx, query)


def _go_to_results(ctx, query):
    # End the transient dialog directory, then navigate to the idempotent
    # results directory (replacing the dialog step in history). This keeps the
    # results container dialog-free so returning from playback never re-prompts.
    xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
    xbmc.executebuiltin(
        "Container.Update(%s,replace)" % ctx.url(action="results", query=query))
    if _enabled("auto_play"):
        try:
            results, _has_next = scraper.search(query, 1, _timeout())
        except Exception:
            return
        first = _first_playable(results)
        if first:
            xbmc.executebuiltin(
                "PlayMedia(%s)" % ctx.url(action="play", path=first.path))


def _first_playable(results):
    """First result; with hide_limited the first one that has a source
    without limitsize (needs one detail-page fetch per result tried)."""
    # ponytail: sequential fetch over page 1 only, fine for ~20 results
    for r in results:
        if not _hide_limited():
            return r
        try:
            stream = scraper.resolve(r.path, _timeout())
        except Exception:
            continue
        if stream and scraper.drop_limited(stream.sources):
            return r
    return None


def render_results(ctx, query, page, autoplay=False):
    try:
        results, has_next = scraper.search(query, page, _timeout())
    except Exception:
        _notify(_(30007))
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    if not results and page == 1:
        _notify(_(30006))
    # TMDb Helper asks with autoplay=1: list only the first playable result
    # so it plays without a dialog. After a failed play (it re-lists via
    # reselect_on_fail) show everything, otherwise we would loop on one item.
    retry = xbmcgui.Window(10000).getProperty(_AUTOPLAY_FAILED)
    xbmcgui.Window(10000).clearProperty(_AUTOPLAY_FAILED)
    if autoplay:
        # TMDb Helper does not re-open its list when playback fails, so play()
        # offers the remaining results itself (see _pick_other).
        xbmcgui.Window(10000).setProperty(_PICK_LIST, json.dumps(
            [[r.path, gui.result_label(r)] for r in results]))
    if autoplay and _enabled("auto_play") and not retry:
        first = _first_playable(results)
        if first:
            results, has_next = [first], False
    for r in results:
        url = (ctx.url(action="play", path=r.path, pick=1) if autoplay
               else ctx.url(action="play", path=r.path))
        xbmcplugin.addDirectoryItem(ctx.handle, url, gui.make_video_item(r), False)
    if has_next:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=query, page=page + 1),
            gui.make_folder_item(_(30004)), True)
    xbmcplugin.setContent(ctx.handle, "videos")
    xbmcplugin.endOfDirectory(ctx.handle)


def show_history(ctx):
    recent = _history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="history_clear"),
            gui.make_folder_item(_(30003)), True)
    for term in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="results", query=term, page=1),
            gui.make_folder_item(term), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_history(ctx):
    _history().clear()
    xbmc.executebuiltin("Container.Refresh")


def do_tv_search(ctx):
    show = (xbmcgui.Dialog().input(_(30010)) or "").strip()
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    pick_and_play_episode(ctx, show)


def pick_and_play_episode(ctx, show):
    if not show:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    season = xbmcgui.Dialog().numeric(0, _(30012))   # Season (blank, not pre-filled)
    if not season:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    episode = xbmcgui.Dialog().numeric(0, _(30013))  # Episode (blank, not pre-filled)
    if not episode:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        return
    _tv_history().add(show, season, episode)
    _go_to_results(ctx, _episode_query(show, season, episode))


def show_tv_history(ctx):
    recent = _tv_history().recent()
    if recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_history_clear"),
            gui.make_folder_item(_(30003)), True)
    for record in recent:
        xbmcplugin.addDirectoryItem(
            ctx.handle, ctx.url(action="tv_episode", show=record["show"]),
            gui.make_folder_item(_episode_label(record)), True)
    xbmcplugin.endOfDirectory(ctx.handle)


def clear_tv_history(ctx):
    _tv_history().clear()
    xbmc.executebuiltin("Container.Refresh")


_AUTOPLAY_FAILED = "prehrajto.AutoplayFailed"
_PICK_LIST = "prehrajto.PickList"


def _play_failed(ctx):
    # TMDb Helper (player with "reselect_on_fail") watches this property and
    # reopens its results dialog instead of ending playback.
    xbmcgui.Window(10000).setProperty("TMDbHelper.PlayerFailed", "true")
    xbmcgui.Window(10000).setProperty(_AUTOPLAY_FAILED, "true")
    xbmcplugin.setResolvedUrl(ctx.handle, False, xbmcgui.ListItem())


def _pick_other(failed_path):
    """Let the user pick another result from the stored TMDb Helper list,
    dropping the one that just failed. Returns its path, or None."""
    window = xbmcgui.Window(10000)
    try:
        items = json.loads(window.getProperty(_PICK_LIST) or "[]")
    except ValueError:
        items = []
    items = [i for i in items if i[0] != failed_path]
    window.setProperty(_PICK_LIST, json.dumps(items))
    if not items:
        return None
    index = xbmcgui.Dialog().select(_(30018), [label for _path, label in items])
    return items[index][0] if index >= 0 else None


def _resolve_item(path):
    """Playable ListItem for a result page, or None (user already notified)."""
    try:
        stream = scraper.resolve(path, _timeout())
    except Exception:
        stream = None
    if not stream or not stream.sources:
        _notify(_(30008))
        return None
    sources = stream.sources
    if _hide_limited():
        sources = scraper.drop_limited(sources)
        if not sources:
            _notify(_(30017))
            return None
    if len(sources) == 1 or _enabled("auto_quality"):
        chosen = sources[0]                # sorted best-quality-first
    else:
        labels = [label for label, _url in sources]
        index = xbmcgui.Dialog().select(_(30009), labels)
        if index < 0:                      # user cancelled
            return None
        chosen = sources[index]
    play_url = chosen[1] + "|User-Agent=" + urllib.parse.quote(scraper.USER_AGENT)
    li = xbmcgui.ListItem(path=play_url)
    subs = _prepare_subtitles(stream.subtitles)
    if subs:
        li.setSubtitles(subs)
    return li


def play(ctx, path, pick=False):
    # pick: started from TMDb Helper's list, so on failure offer the others
    # here instead of ending playback (TMDb Helper would not re-list).
    while path:
        li = _resolve_item(path)
        if li:
            return xbmcplugin.setResolvedUrl(ctx.handle, True, li)
        path = _pick_other(path) if pick else None
    return _play_failed(ctx)


def run(argv):
    base, handle, qs = argv[0], int(argv[1]), argv[2]
    params = dict(urllib.parse.parse_qsl(qs.lstrip("?")))
    ctx = Ctx(base, handle)
    action = params.get("action", "menu")
    if action == "search":
        do_search(ctx)
    elif action == "results":
        query = _compose_query(params)
        if query is None:
            xbmcplugin.endOfDirectory(ctx.handle, succeeded=True)
        else:
            render_results(ctx, query, int(params.get("page", "1")),
                           autoplay=params.get("autoplay") == "1")
    elif action == "title_choices_clear":
        _title_choices().clear()
        _notify(_(30070))
    elif action == "history":
        show_history(ctx)
    elif action == "history_clear":
        clear_history(ctx)
    elif action == "tv_search":
        do_tv_search(ctx)
    elif action == "tv_episode":
        pick_and_play_episode(ctx, params.get("show", ""))
    elif action == "tv_history":
        show_tv_history(ctx)
    elif action == "tv_history_clear":
        clear_tv_history(ctx)
    elif action == "play":
        play(ctx, params.get("path", ""), pick=params.get("pick") == "1")
    elif action == "movies_menu":
        show_movies_menu(ctx)
    elif action == "tv_menu":
        show_tv_menu(ctx)
    else:
        show_menu(ctx)
