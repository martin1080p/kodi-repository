"""sktorrent.eu (Sk-CzTorrent) HTTP client and HTML parsing."""
from urllib.parse import urljoin, urlencode

from bs4 import BeautifulSoup

BASE = "https://sktorrent.eu/"
LOGIN_URL = urljoin(BASE, "login.php")
LIST_URL = urljoin(BASE, "torrents_v2.php")
TIMEOUT = 30

# (menu label, category query value). Refine values against the live site.
CATEGORIES = [
    ("Filmy", "1"),
    ("Seriály", "2"),
    ("Hudba", "3"),
    ("Hry", "4"),
    ("Aplikácie", "5"),
]


def _soup(html):
    return BeautifulSoup(html, "html.parser")


def _int(text):
    digits = "".join(ch for ch in (text or "") if ch.isdigit())
    return int(digits) if digits else 0


def is_logged_in(html):
    lowered = html.lower()
    if "logout" in lowered or "odhlás" in lowered:
        return True
    # A visible login form means we are NOT authenticated.
    if 'name="meno"' in lowered and 'name="heslo"' in lowered:
        return False
    return False


def parse_listing(html):
    soup = _soup(html)
    rows = []
    for anchor in soup.select('a[href^="details.php"]'):
        title = anchor.get_text(strip=True)
        if not title:
            continue
        detail_url = urljoin(BASE, anchor.get("href"))
        row = anchor.find_parent("tr")
        size = seeders = leechers = ""
        category = ""
        if row is not None:
            size = _cell_text(row, "size")
            seeders = _cell_text(row, "seed")
            leechers = _cell_text(row, "leech")
            category = _cell_text(row, "category")
        rows.append(
            {
                "title": title,
                "detail_url": detail_url,
                "size": size,
                "seeders": _int(seeders),
                "leechers": _int(leechers),
                "category": category,
            }
        )
    return rows


def _cell_text(row, class_name):
    cell = row.find("td", class_=class_name)
    return cell.get_text(strip=True) if cell else ""


def find_download_link(html):
    soup = _soup(html)
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"]
        if "download.php" in href or href.endswith(".torrent"):
            return urljoin(BASE, href)
    return None


class SkTorrent:
    def __init__(self, username, password, session=None):
        self.username = username
        self.password = password
        if session is None:
            import requests

            session = requests.Session()
            session.headers.update({"User-Agent": "Kodi plugin.video.sktorrent"})
        self.session = session
        self._logged_in = False

    def login(self):
        resp = self.session.post(
            LOGIN_URL,
            data={"Meno": self.username, "Heslo": self.password},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        self._logged_in = is_logged_in(resp.text)
        return self._logged_in

    def load_cookies(self, cookie_dict):
        """Seed the session with persisted cookies and assume logged-in.

        If the cookies are stale, _fetch_list/resolve_download_url detect the
        logged-out response and transparently re-login.
        """
        if cookie_dict:
            self.session.cookies.update(cookie_dict)
            self._logged_in = True

    def dump_cookies(self):
        """Return the session cookies as a plain dict (empty on failure)."""
        try:
            return dict(self.session.cookies)
        except Exception:
            return {}

    def _ensure_login(self):
        if not self._logged_in:
            if not self.login():
                raise SkTorrentError("login failed")

    def _fetch_list(self, params):
        self._ensure_login()
        url = LIST_URL + "?" + urlencode(params)
        resp = self.session.get(url, timeout=TIMEOUT)
        resp.raise_for_status()
        if not is_logged_in(resp.text):
            # Session may have expired; try once more.
            if not self.login():
                raise SkTorrentError("session expired and re-login failed")
            resp = self.session.get(url, timeout=TIMEOUT)
            resp.raise_for_status()
        return parse_listing(resp.text)

    def search(self, query, page=0):
        return self._fetch_list({"search": query, "page": page})

    def browse(self, category, page=0):
        return self._fetch_list({"category": category, "page": page})

    def latest(self, page=0):
        return self._fetch_list({"active": 0, "order": "data", "by": "DESC", "page": page})

    def resolve_download_url(self, detail_url):
        self._ensure_login()
        resp = self.session.get(detail_url, timeout=TIMEOUT)
        resp.raise_for_status()
        if not is_logged_in(resp.text):
            # Session may have expired; try once more.
            if not self.login():
                raise SkTorrentError("session expired and re-login failed")
            resp = self.session.get(detail_url, timeout=TIMEOUT)
            resp.raise_for_status()
        link = find_download_link(resp.text)
        if not link:
            raise SkTorrentError("no .torrent download link on detail page")
        return link


class SkTorrentError(Exception):
    pass
