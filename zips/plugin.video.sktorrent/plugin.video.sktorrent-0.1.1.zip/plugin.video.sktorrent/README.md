# plugin.video.sktorrent

Kodi addon that searches/browses sktorrent.eu and streams torrents via Elementum
(no manual download).

## Requirements
- Kodi 19 (Matrix) or newer
- [Elementum](https://elementum.surge.sh/) installed and configured
- A sktorrent.eu account

## Setup
1. Install this addon (zip the folder or copy into `addons/`).
2. Open addon settings and enter your sktorrent.eu **username** and **password**.
3. Ensure Elementum is installed.

## Usage
- **Search** — enter a query, browse results, click to stream.
- **Latest / categories** — browse recent uploads or by category, with pagination.

## Development
```bash
pip install -r requirements-dev.txt
pytest -v
```
