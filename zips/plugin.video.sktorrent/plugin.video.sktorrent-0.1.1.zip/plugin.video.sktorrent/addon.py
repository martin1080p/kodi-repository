"""Kodi entry point for plugin.video.sktorrent."""
from resources.lib import router

if __name__ == "__main__":
    router.run()
