# plugin.video.sktorrent Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Kodi video addon that logs in to sktorrent.eu, lets the user search/browse/list torrents, and streams them via Elementum by converting the authenticated `.torrent` into a magnet link.

**Architecture:** A `plugin://` routed Kodi addon. `addon.py` is a thin entry point into `resources/lib/router.py`, which dispatches on URL query params. Site scraping (`sktorrent.py`), bencode/magnet conversion (`bencode.py`, `torrent.py`), Elementum handoff (`player.py`), and settings/cookie caching (`settings.py`) are isolated modules. Pure-logic modules avoid importing `xbmc*` so they run under plain pytest; Kodi-facing modules are tested with stub `xbmc*` modules.

**Tech Stack:** Python 3, Kodi 19+ (Matrix), `requests`, `beautifulsoup4`, Elementum for playback, pytest for tests.

## Global Constraints

- Target `xbmc.python` version `3.0.0` (Kodi 19 Matrix or newer); Python 3 only.
- Addon id / folder name: `plugin.video.sktorrent`.
- `resources/` folder and `addon.xml` live directly in the repo root.
- External Python deps allowed only via Kodi modules declared in `addon.xml`: `script.module.requests`, `script.module.beautifulsoup4`. No other third-party imports.
- `plugin.video.elementum` is an OPTIONAL dependency — checked at runtime, never hard-imported at module top level.
- Pure-logic modules (`bencode.py`, `torrent.py`, `sktorrent.py`) MUST NOT import `xbmc`, `xbmcgui`, `xbmcplugin`, or `xbmcaddon`.
- Site base URL: `https://sktorrent.eu/`. Login endpoint `login.php`, fields `Meno` (username) and `Heslo` (password). Listings via `torrents_v2.php`. Detail pages via `details.php`.
- All commits use conventional-commit style messages.

---

### Task 1: Project scaffold, addon.xml, settings, and test harness

**Files:**
- Create: `addon.xml`
- Create: `addon.py`
- Create: `resources/settings.xml`
- Create: `resources/language/resource.language.en_gb/strings.po`
- Create: `resources/lib/__init__.py` (empty)
- Create: `tests/__init__.py` (empty)
- Create: `tests/conftest.py`
- Create: `tests/test_addon_manifest.py`
- Create: `requirements-dev.txt`
- Create: `.gitignore`

**Interfaces:**
- Consumes: nothing.
- Produces: repo layout, `tests/conftest.py` which (a) inserts repo root on `sys.path` and (b) installs stub `xbmc`, `xbmcgui`, `xbmcplugin`, `xbmcaddon` modules so later Kodi-facing tests can import addon modules.

- [ ] **Step 1: Initialise the repository and dev deps**

```bash
cd /media/hdd/martin/Codes/own/python/plugin.video.sktorrent
git init
```

Create `requirements-dev.txt`:

```
pytest
requests
beautifulsoup4
```

Create `.gitignore`:

```
__pycache__/
*.pyc
.pytest_cache/
.venv/
```

- [ ] **Step 2: Write the failing manifest test**

Create `tests/test_addon_manifest.py`:

```python
import os
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _tree():
    return ET.parse(os.path.join(ROOT, "addon.xml"))


def test_addon_id_and_version():
    addon = _tree().getroot()
    assert addon.tag == "addon"
    assert addon.get("id") == "plugin.video.sktorrent"
    assert addon.get("version")
    assert addon.get("provider-name")


def test_declares_required_dependencies():
    addon = _tree().getroot()
    imports = {
        i.get("addon"): i.get("optional", "false")
        for i in addon.findall("./requires/import")
    }
    assert imports.get("xbmc.python") == "false" or "xbmc.python" in imports
    assert "script.module.requests" in imports
    assert "script.module.beautifulsoup4" in imports
    # Elementum must be present AND optional
    assert imports.get("plugin.video.elementum") == "true"


def test_is_video_plugin_extension():
    addon = _tree().getroot()
    points = {e.get("point") for e in addon.findall("./extension")}
    assert "xbmc.python.pluginsource" in points
    src = addon.find("./extension[@point='xbmc.python.pluginsource']")
    assert src.get("library") == "addon.py"
```

- [ ] **Step 3: Run the test to verify it fails**

Run: `pytest tests/test_addon_manifest.py -v`
Expected: FAIL — `addon.xml` does not exist (`FileNotFoundError`).

- [ ] **Step 4: Create `addon.xml`**

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="plugin.video.sktorrent"
       name="SKTorrent"
       version="0.1.0"
       provider-name="you">
    <requires>
        <import addon="xbmc.python" version="3.0.0"/>
        <import addon="script.module.requests" version="2.22.0"/>
        <import addon="script.module.beautifulsoup4" version="4.6.2"/>
        <import addon="plugin.video.elementum" optional="true"/>
    </requires>
    <extension point="xbmc.python.pluginsource" library="addon.py">
        <provides>video</provides>
    </extension>
    <extension point="xbmc.addon.metadata">
        <summary lang="en_gb">Stream torrents from sktorrent.eu via Elementum</summary>
        <description lang="en_gb">Search and browse the sktorrent.eu tracker and stream torrents through Elementum without downloading. Requires a sktorrent.eu account (set username and password in settings) and the Elementum addon.</description>
        <platform>all</platform>
        <license>GPL-3.0-or-later</license>
        <assets>
            <icon>resources/icon.png</icon>
        </assets>
    </extension>
</addon>
```

- [ ] **Step 5: Create the entry point `addon.py`**

```python
"""Kodi entry point for plugin.video.sktorrent."""
from resources.lib import router

if __name__ == "__main__":
    router.run()
```

- [ ] **Step 6: Create `resources/settings.xml`**

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<settings>
    <category label="30001">
        <setting id="username" type="text" label="30002" default=""/>
        <setting id="password" type="text" option="hidden" label="30003" default=""/>
        <setting id="items_per_page" type="number" label="30004" default="30"/>
        <setting id="elementum_id" type="text" label="30005" default="plugin.video.elementum"/>
    </category>
</settings>
```

- [ ] **Step 7: Create `resources/language/resource.language.en_gb/strings.po`**

```po
msgid ""
msgstr ""
"Content-Type: text/plain; charset=UTF-8\n"

msgctxt "#30001"
msgid "Account"
msgstr ""

msgctxt "#30002"
msgid "Username"
msgstr ""

msgctxt "#30003"
msgid "Password"
msgstr ""

msgctxt "#30004"
msgid "Items per page"
msgstr ""

msgctxt "#30005"
msgid "Elementum addon id"
msgstr ""
```

- [ ] **Step 8: Create empty package markers and the test harness**

Create empty files `resources/lib/__init__.py` and `tests/__init__.py`.

Create `tests/conftest.py`:

```python
"""Test harness: put repo root on sys.path and stub Kodi modules.

Pure-logic modules (bencode, torrent, sktorrent) do not import xbmc*, but
router/player/settings do. Stubbing here lets those import under pytest.
"""
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def _install_kodi_stubs():
    xbmc = types.ModuleType("xbmc")
    xbmc.LOGINFO = 1
    xbmc.LOGERROR = 4
    xbmc.log = lambda msg, level=1: None

    xbmcgui = types.ModuleType("xbmcgui")

    class _ListItem:
        def __init__(self, label="", path=""):
            self.label = label
            self.path = path
            self._info = {}
            self._props = {}

        def setInfo(self, kind, values):
            self._info[kind] = values

        def setProperty(self, key, value):
            self._props[key] = value

        def setArt(self, art):
            self._props["art"] = art

    class _Dialog:
        def notification(self, *a, **k):
            return None

        def input(self, *a, **k):
            return ""

    xbmcgui.ListItem = _ListItem
    xbmcgui.Dialog = _Dialog

    xbmcplugin = types.ModuleType("xbmcplugin")
    xbmcplugin.addDirectoryItem = lambda *a, **k: None
    xbmcplugin.endOfDirectory = lambda *a, **k: None
    xbmcplugin.setResolvedUrl = lambda *a, **k: None
    xbmcplugin.setContent = lambda *a, **k: None

    xbmcaddon = types.ModuleType("xbmcaddon")

    class _Addon:
        _store = {
            "username": "",
            "password": "",
            "items_per_page": "30",
            "elementum_id": "plugin.video.elementum",
        }

        def getSetting(self, key):
            return self._store.get(key, "")

        def setSetting(self, key, value):
            self._store[key] = value

        def getAddonInfo(self, key):
            return {"id": "plugin.video.sktorrent", "profile": "special://profile"}.get(key, "")

    xbmcaddon.Addon = _Addon

    xbmcvfs = types.ModuleType("xbmcvfs")
    xbmcvfs.translatePath = lambda p: p

    for name, mod in {
        "xbmc": xbmc,
        "xbmcgui": xbmcgui,
        "xbmcplugin": xbmcplugin,
        "xbmcaddon": xbmcaddon,
        "xbmcvfs": xbmcvfs,
    }.items():
        sys.modules.setdefault(name, mod)


_install_kodi_stubs()
```

- [ ] **Step 9: Run the manifest tests to verify they pass**

Run: `pytest tests/test_addon_manifest.py -v`
Expected: PASS (3 tests).

- [ ] **Step 10: Commit**

```bash
git add addon.xml addon.py resources/ tests/ requirements-dev.txt .gitignore
git commit -m "chore: scaffold plugin.video.sktorrent addon and test harness"
```

---

### Task 2: bencode decoder and info-hash

**Files:**
- Create: `resources/lib/bencode.py`
- Test: `tests/test_bencode.py`

**Interfaces:**
- Consumes: nothing (stdlib only).
- Produces:
  - `decode(data: bytes) -> value` — decode a full bencoded document into Python `int`/`bytes`/`list`/`dict` (dict keys are `bytes`).
  - `info_hash(data: bytes) -> str` — the hex SHA-1 of the raw bytes of the top-level `info` dict.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_bencode.py`:

```python
import hashlib
from resources.lib import bencode


def test_decode_int():
    assert bencode.decode(b"i42e") == 42
    assert bencode.decode(b"i-7e") == -7


def test_decode_string():
    assert bencode.decode(b"4:spam") == b"spam"


def test_decode_list():
    assert bencode.decode(b"l4:spami42ee") == [b"spam", 42]


def test_decode_dict():
    assert bencode.decode(b"d3:cow3:moo4:spam4:eggse") == {
        b"cow": b"moo",
        b"spam": b"eggs",
    }


def test_info_hash_matches_manual_sha1():
    # A minimal torrent: d ...announce... 4:info <infodict> e
    info = b"d6:lengthi10e4:name4:file12:piece lengthi16384e6:pieces20:" + b"\x00" * 20 + b"e"
    torrent = b"d8:announce20:http://tracker.test4:info" + info + b"e"
    expected = hashlib.sha1(info).hexdigest()
    assert bencode.info_hash(torrent) == expected


def test_info_hash_missing_info_raises():
    import pytest
    with pytest.raises(ValueError):
        bencode.info_hash(b"d8:announce3:abce")
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_bencode.py -v`
Expected: FAIL — `No module named 'resources.lib.bencode'`.

- [ ] **Step 3: Implement `resources/lib/bencode.py`**

```python
"""Minimal, dependency-free bencode decoding with info-hash extraction."""
import hashlib


def decode(data):
    """Decode a bencoded document. Returns int/bytes/list/dict."""
    value, index = _decode(data, 0)
    if index != len(data):
        raise ValueError("trailing bytes after bencoded value")
    return value


def _decode(data, i):
    if i >= len(data):
        raise ValueError("unexpected end of data")
    c = data[i : i + 1]
    if c == b"i":
        end = data.index(b"e", i)
        return int(data[i + 1 : end]), end + 1
    if c == b"l":
        i += 1
        items = []
        while data[i : i + 1] != b"e":
            value, i = _decode(data, i)
            items.append(value)
        return items, i + 1
    if c == b"d":
        i += 1
        result = {}
        while data[i : i + 1] != b"e":
            key, i = _decode(data, i)
            value, i = _decode(data, i)
            result[key] = value
        return result, i + 1
    if c.isdigit():
        colon = data.index(b":", i)
        length = int(data[i:colon])
        start = colon + 1
        return data[start : start + length], start + length
    raise ValueError("invalid bencode at index %d" % i)


def info_hash(data):
    """Hex SHA-1 of the raw bytes of the top-level `info` dictionary."""
    if data[0:1] != b"d":
        raise ValueError("torrent is not a bencoded dict")
    i = 1
    while data[i : i + 1] != b"e":
        key, i = _decode(data, i)
        start = i
        _value, i = _decode(data, i)
        if key == b"info":
            return hashlib.sha1(data[start:i]).hexdigest()
    raise ValueError("no info dict in torrent")
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_bencode.py -v`
Expected: PASS (6 tests).

- [ ] **Step 5: Commit**

```bash
git add resources/lib/bencode.py tests/test_bencode.py
git commit -m "feat: add bencode decoder and info-hash extraction"
```

---

### Task 3: torrent → magnet conversion

**Files:**
- Create: `resources/lib/torrent.py`
- Test: `tests/test_torrent.py`

**Interfaces:**
- Consumes: `resources.lib.bencode` (`decode`, `info_hash`).
- Produces:
  - `build_magnet(info_hash_hex: str, name: str = "", trackers: list = None) -> str`
  - `magnet_from_torrent_bytes(data: bytes) -> str`
  - `magnet_from_torrent_url(session, url: str) -> str` — `session` is any object with a `.get(url)` returning an object with `.content` and `.raise_for_status()` (a `requests.Session`).

- [ ] **Step 1: Write the failing tests**

Create `tests/test_torrent.py`:

```python
from resources.lib import torrent


def _sample_torrent():
    info = b"d6:lengthi10e4:name8:file.mkv12:piece lengthi16384e6:pieces20:" + b"\x00" * 20 + b"e"
    return b"d8:announce20:http://tracker.test4:info" + info + b"e", info


def test_build_magnet_minimal():
    m = torrent.build_magnet("abc123")
    assert m == "magnet:?xt=urn:btih:abc123"


def test_build_magnet_with_name_and_trackers():
    m = torrent.build_magnet("abc123", "My File", ["http://a/announce", "http://b/announce"])
    assert m.startswith("magnet:?xt=urn:btih:abc123")
    assert "dn=My+File" in m
    assert "tr=http%3A%2F%2Fa%2Fannounce" in m
    assert "tr=http%3A%2F%2Fb%2Fannounce" in m


def test_magnet_from_torrent_bytes_uses_info_hash_and_name():
    data, _info = _sample_torrent()
    m = torrent.magnet_from_torrent_bytes(data)
    from resources.lib import bencode
    assert ("xt=urn:btih:" + bencode.info_hash(data)) in m
    assert "dn=file.mkv" in m
    assert "tr=http%3A%2F%2Ftracker.test" in m


def test_magnet_from_torrent_url_reads_session_content():
    data, _info = _sample_torrent()

    class FakeResp:
        content = data

        def raise_for_status(self):
            return None

    class FakeSession:
        def __init__(self):
            self.requested = None

        def get(self, url, **kwargs):
            self.requested = url
            return FakeResp()

    s = FakeSession()
    m = torrent.magnet_from_torrent_url(s, "http://x/download.php?id=1")
    assert s.requested == "http://x/download.php?id=1"
    assert m.startswith("magnet:?xt=urn:btih:")
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_torrent.py -v`
Expected: FAIL — `No module named 'resources.lib.torrent'`.

- [ ] **Step 3: Implement `resources/lib/torrent.py`**

```python
"""Convert a .torrent (bytes or authenticated URL) into a magnet link."""
from urllib.parse import quote_plus

from resources.lib import bencode


def build_magnet(info_hash_hex, name="", trackers=None):
    parts = ["xt=urn:btih:" + info_hash_hex]
    if name:
        parts.append("dn=" + quote_plus(name))
    for tracker in trackers or []:
        parts.append("tr=" + quote_plus(tracker))
    return "magnet:?" + "&".join(parts)


def _collect_trackers(meta):
    trackers = []
    announce = meta.get(b"announce")
    if announce:
        trackers.append(announce.decode("utf-8", "replace"))
    for tier in meta.get(b"announce-list", []) or []:
        for url in tier:
            decoded = url.decode("utf-8", "replace")
            if decoded not in trackers:
                trackers.append(decoded)
    return trackers


def magnet_from_torrent_bytes(data):
    meta = bencode.decode(data)
    ih = bencode.info_hash(data)
    info = meta.get(b"info", {})
    name = info.get(b"name", b"").decode("utf-8", "replace")
    return build_magnet(ih, name, _collect_trackers(meta))


def magnet_from_torrent_url(session, url):
    resp = session.get(url)
    resp.raise_for_status()
    return magnet_from_torrent_bytes(resp.content)
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_torrent.py -v`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit**

```bash
git add resources/lib/torrent.py tests/test_torrent.py
git commit -m "feat: convert torrent metadata to magnet links"
```

---

### Task 4: sktorrent site client (session, login, listing/detail parsing)

**Files:**
- Create: `resources/lib/sktorrent.py`
- Test: `tests/test_sktorrent.py`
- Create: `tests/fixtures/listing.html`
- Create: `tests/fixtures/detail.html`

**Interfaces:**
- Consumes: `requests` (via injected session), `bs4.BeautifulSoup`.
- Produces:
  - `class SkTorrent(username, password, session=None)`
  - `SkTorrent.login() -> bool`
  - `SkTorrent.search(query, page=0) -> list[dict]`
  - `SkTorrent.browse(category, page=0) -> list[dict]`
  - `SkTorrent.latest(page=0) -> list[dict]`
  - `SkTorrent.resolve_download_url(detail_url) -> str`
  - Module fns (pure, testable without network): `parse_listing(html) -> list[dict]`, `find_download_link(html) -> str | None`, `is_logged_in(html) -> bool`.
  - Each listing dict: `{"title": str, "detail_url": str, "size": str, "seeders": int, "leechers": int, "category": str}`.
  - `CATEGORIES: list[tuple[str, str]]` — `(label, category_query_value)` pairs for the browse menu.

> **Execution note:** The fixtures below are representative of the described structure (`a[href^="details.php"]` links inside table rows). During execution, capture a REAL authenticated `torrents_v2.php` page and a REAL `details.php` page, save them over these fixtures, and adjust the parser selectors until the tests pass against real markup. The parser is written defensively (anchor-driven) to survive minor structure differences.

- [ ] **Step 1: Create representative fixtures**

Create `tests/fixtures/listing.html`:

```html
<html><body>
<table class="torrents">
  <tr class="row">
    <td class="name"><a href="details.php?name=Big.Buck.Bunny&amp;id=aaaa1111">Big Buck Bunny 1080p</a></td>
    <td class="category">Filmy</td>
    <td class="size">1.4 GB</td>
    <td class="seed">25</td>
    <td class="leech">3</td>
  </tr>
  <tr class="row">
    <td class="name"><a href="details.php?name=Sintel&amp;id=bbbb2222">Sintel 720p</a></td>
    <td class="category">Filmy</td>
    <td class="size">700 MB</td>
    <td class="seed">10</td>
    <td class="leech">0</td>
  </tr>
</table>
</body></html>
```

Create `tests/fixtures/detail.html`:

```html
<html><body>
<h1>Big Buck Bunny 1080p</h1>
<a href="login.php?logout=1">Odhlásiť</a>
<a class="download" href="download.php?id=aaaa1111">Stiahnuť .torrent</a>
</body></html>
```

- [ ] **Step 2: Write the failing tests**

Create `tests/test_sktorrent.py`:

```python
import os
from resources.lib import sktorrent

FIX = os.path.join(os.path.dirname(__file__), "fixtures")


def _read(name):
    with open(os.path.join(FIX, name), "r", encoding="utf-8") as fh:
        return fh.read()


def test_parse_listing_extracts_rows():
    rows = sktorrent.parse_listing(_read("listing.html"))
    assert len(rows) == 2
    first = rows[0]
    assert first["title"] == "Big Buck Bunny 1080p"
    assert first["detail_url"].endswith("details.php?name=Big.Buck.Bunny&id=aaaa1111")
    assert first["detail_url"].startswith("https://sktorrent.eu/")
    assert first["size"] == "1.4 GB"
    assert first["seeders"] == 25
    assert first["leechers"] == 3


def test_find_download_link():
    link = sktorrent.find_download_link(_read("detail.html"))
    assert link.endswith("download.php?id=aaaa1111")
    assert link.startswith("https://sktorrent.eu/")


def test_is_logged_in_true_when_logout_present():
    assert sktorrent.is_logged_in(_read("detail.html")) is True


def test_is_logged_in_false_on_login_form():
    html = '<form action="login.php"><input name="Meno"><input name="Heslo"></form>'
    assert sktorrent.is_logged_in(html) is False


def test_login_posts_credentials_and_detects_success():
    posted = {}

    class FakeResp:
        def __init__(self, text):
            self.text = text
            self.status_code = 200

        def raise_for_status(self):
            return None

    class FakeSession:
        def post(self, url, data=None, **kwargs):
            posted["url"] = url
            posted["data"] = data
            return FakeResp('<a href="login.php?logout=1">Odhlásiť</a>')

        def get(self, url, **kwargs):
            return FakeResp("")

    client = sktorrent.SkTorrent("alice", "secret", session=FakeSession())
    assert client.login() is True
    assert posted["url"].endswith("login.php")
    assert posted["data"] == {"Meno": "alice", "Heslo": "secret"}


def test_login_returns_false_on_failure():
    class FakeResp:
        text = '<form action="login.php"><input name="Meno"></form>'
        status_code = 200

        def raise_for_status(self):
            return None

    class FakeSession:
        def post(self, *a, **k):
            return FakeResp()

        def get(self, *a, **k):
            return FakeResp()

    client = sktorrent.SkTorrent("bad", "creds", session=FakeSession())
    assert client.login() is False


def test_categories_present():
    assert isinstance(sktorrent.CATEGORIES, list)
    assert all(len(pair) == 2 for pair in sktorrent.CATEGORIES)
    assert len(sktorrent.CATEGORIES) >= 1
```

- [ ] **Step 3: Run to verify failure**

Run: `pytest tests/test_sktorrent.py -v`
Expected: FAIL — `No module named 'resources.lib.sktorrent'`.

- [ ] **Step 4: Implement `resources/lib/sktorrent.py`**

```python
"""sktorrent.eu (Sk-CzTorrent) HTTP client and HTML parsing."""
from urllib.parse import urljoin, urlencode

from bs4 import BeautifulSoup

BASE = "https://sktorrent.eu/"
LOGIN_URL = urljoin(BASE, "login.php")
LIST_URL = urljoin(BASE, "torrents_v2.php")

# (menu label, category query value). Refine values against the live site.
CATEGORIES = [
    ("Filmy", "1"),
    ("Seriály", "2"),
    ("Hudba", "3"),
    ("Hry", "4"),
    ("Aplikácie", "5"),
]


def _soup(html):
    return BeautifulSoup(html, "html.parser")


def _int(text):
    digits = "".join(ch for ch in (text or "") if ch.isdigit())
    return int(digits) if digits else 0


def is_logged_in(html):
    lowered = html.lower()
    if "logout" in lowered or "odhlás" in lowered:
        return True
    # A visible login form means we are NOT authenticated.
    if 'name="meno"' in lowered and 'name="heslo"' in lowered:
        return False
    return False


def parse_listing(html):
    soup = _soup(html)
    rows = []
    for anchor in soup.select('a[href^="details.php"]'):
        title = anchor.get_text(strip=True)
        if not title:
            continue
        detail_url = urljoin(BASE, anchor.get("href"))
        row = anchor.find_parent("tr")
        size = seeders = leechers = ""
        category = ""
        if row is not None:
            size = _cell_text(row, "size")
            seeders = _cell_text(row, "seed")
            leechers = _cell_text(row, "leech")
            category = _cell_text(row, "category")
        rows.append(
            {
                "title": title,
                "detail_url": detail_url,
                "size": size,
                "seeders": _int(seeders),
                "leechers": _int(leechers),
                "category": category,
            }
        )
    return rows


def _cell_text(row, class_name):
    cell = row.find("td", class_=class_name)
    return cell.get_text(strip=True) if cell else ""


def find_download_link(html):
    soup = _soup(html)
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"]
        if "download.php" in href or href.endswith(".torrent"):
            return urljoin(BASE, href)
    return None


class SkTorrent:
    def __init__(self, username, password, session=None):
        self.username = username
        self.password = password
        if session is None:
            import requests

            session = requests.Session()
            session.headers.update({"User-Agent": "Kodi plugin.video.sktorrent"})
        self.session = session
        self._logged_in = False

    def login(self):
        resp = self.session.post(
            LOGIN_URL, data={"Meno": self.username, "Heslo": self.password}
        )
        resp.raise_for_status()
        self._logged_in = is_logged_in(resp.text)
        return self._logged_in

    def _ensure_login(self):
        if not self._logged_in:
            if not self.login():
                raise SkTorrentError("login failed")

    def _fetch_list(self, params):
        self._ensure_login()
        url = LIST_URL + "?" + urlencode(params)
        resp = self.session.get(url)
        resp.raise_for_status()
        if not is_logged_in(resp.text):
            # Session may have expired; try once more.
            if self.login():
                resp = self.session.get(url)
                resp.raise_for_status()
        return parse_listing(resp.text)

    def search(self, query, page=0):
        return self._fetch_list({"search": query, "page": page})

    def browse(self, category, page=0):
        return self._fetch_list({"category": category, "page": page})

    def latest(self, page=0):
        return self._fetch_list({"active": 0, "order": "data", "by": "DESC", "page": page})

    def resolve_download_url(self, detail_url):
        self._ensure_login()
        resp = self.session.get(detail_url)
        resp.raise_for_status()
        link = find_download_link(resp.text)
        if not link:
            raise SkTorrentError("no .torrent download link on detail page")
        return link


class SkTorrentError(Exception):
    pass
```

- [ ] **Step 5: Run to verify pass**

Run: `pytest tests/test_sktorrent.py -v`
Expected: PASS (7 tests).

- [ ] **Step 6: Commit**

```bash
git add resources/lib/sktorrent.py tests/test_sktorrent.py tests/fixtures/
git commit -m "feat: add sktorrent client with login and listing parsing"
```

---

### Task 5: settings wrapper and cookie cache

**Files:**
- Create: `resources/lib/settings.py`
- Test: `tests/test_settings.py`

**Interfaces:**
- Consumes: `xbmcaddon`, `xbmcvfs` (stubbed in tests).
- Produces:
  - `get_credentials() -> tuple[str, str]`
  - `items_per_page() -> int`
  - `elementum_id() -> str`
  - `has_credentials() -> bool`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_settings.py`:

```python
from resources.lib import settings


def test_defaults_from_stub(monkeypatch):
    # Stub Addon defaults: empty creds, 30 items, default elementum id.
    assert settings.items_per_page() == 30
    assert settings.elementum_id() == "plugin.video.elementum"
    assert settings.has_credentials() is False


def test_has_credentials_true_when_set():
    import xbmcaddon

    addon = xbmcaddon.Addon()
    addon.setSetting("username", "alice")
    addon.setSetting("password", "secret")
    assert settings.has_credentials() is True
    assert settings.get_credentials() == ("alice", "secret")
    # reset so other tests are not affected
    addon.setSetting("username", "")
    addon.setSetting("password", "")
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_settings.py -v`
Expected: FAIL — `No module named 'resources.lib.settings'`.

- [ ] **Step 3: Implement `resources/lib/settings.py`**

```python
"""Thin wrapper over Kodi addon settings."""
import xbmcaddon


def _addon():
    return xbmcaddon.Addon()


def get_credentials():
    addon = _addon()
    return addon.getSetting("username"), addon.getSetting("password")


def has_credentials():
    username, password = get_credentials()
    return bool(username) and bool(password)


def items_per_page():
    raw = _addon().getSetting("items_per_page")
    try:
        return int(float(raw))
    except (TypeError, ValueError):
        return 30


def elementum_id():
    return _addon().getSetting("elementum_id") or "plugin.video.elementum"
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_settings.py -v`
Expected: PASS (2 tests).

- [ ] **Step 5: Commit**

```bash
git add resources/lib/settings.py tests/test_settings.py
git commit -m "feat: add settings wrapper"
```

---

### Task 6: Elementum playback handoff

**Files:**
- Create: `resources/lib/player.py`
- Test: `tests/test_player.py`

**Interfaces:**
- Consumes: `xbmc`, `xbmcgui`, `xbmcplugin` (stubbed in tests), `resources.lib.settings`.
- Produces:
  - `elementum_url(magnet: str, elementum_id: str = "plugin.video.elementum") -> str`
  - `is_elementum_installed(elementum_id: str) -> bool`
  - `play(handle: int, magnet: str, name: str = "") -> bool`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_player.py`:

```python
from resources.lib import player


def test_elementum_url_encodes_magnet():
    url = player.elementum_url("magnet:?xt=urn:btih:abc&dn=x y")
    assert url.startswith("plugin://plugin.video.elementum/play?uri=")
    assert "magnet%3A%3Fxt%3Durn%3Abtih%3Aabc" in url


def test_elementum_url_respects_custom_id():
    url = player.elementum_url("magnet:?xt=urn:btih:abc", "plugin.video.torrest")
    assert url.startswith("plugin://plugin.video.torrest/play?uri=")


def test_play_sets_resolved_url_when_installed(monkeypatch):
    calls = {}
    import xbmcplugin

    monkeypatch.setattr(player, "is_elementum_installed", lambda _id: True)
    monkeypatch.setattr(
        xbmcplugin,
        "setResolvedUrl",
        lambda handle, ok, li: calls.update(handle=handle, ok=ok, li=li),
    )
    result = player.play(5, "magnet:?xt=urn:btih:abc", "Movie")
    assert result is True
    assert calls["handle"] == 5
    assert calls["ok"] is True
    assert calls["li"].path.startswith("plugin://plugin.video.elementum/play?uri=")


def test_play_fails_when_not_installed(monkeypatch):
    import xbmcplugin

    seen = {}
    monkeypatch.setattr(player, "is_elementum_installed", lambda _id: False)
    monkeypatch.setattr(
        xbmcplugin, "setResolvedUrl", lambda handle, ok, li: seen.update(ok=ok)
    )
    result = player.play(5, "magnet:?xt=urn:btih:abc")
    assert result is False
    assert seen["ok"] is False
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_player.py -v`
Expected: FAIL — `No module named 'resources.lib.player'`.

- [ ] **Step 3: Implement `resources/lib/player.py`**

```python
"""Hand a magnet link to Elementum (or a compatible streaming addon)."""
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import settings


def elementum_url(magnet, elementum_id="plugin.video.elementum"):
    return "plugin://%s/play?uri=%s" % (elementum_id, quote(magnet, safe=""))


def is_elementum_installed(elementum_id):
    try:
        import xbmcaddon

        xbmcaddon.Addon(elementum_id)
        return True
    except Exception:
        return False


def play(handle, magnet, name=""):
    elementum_id = settings.elementum_id()
    if not is_elementum_installed(elementum_id):
        xbmcgui.Dialog().notification(
            "SKTorrent",
            "Elementum (%s) is not installed" % elementum_id,
            xbmcgui.NOTIFICATION_ERROR if hasattr(xbmcgui, "NOTIFICATION_ERROR") else "",
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return False
    url = elementum_url(magnet, elementum_id)
    xbmc.log("plugin.video.sktorrent: resolving to %s" % url, xbmc.LOGINFO)
    list_item = xbmcgui.ListItem(label=name, path=url)
    xbmcplugin.setResolvedUrl(handle, True, list_item)
    return True
```

> **Note:** `NOTIFICATION_ERROR` is guarded with `hasattr` so the stub in tests (which lacks it) still works; under real Kodi the constant exists.

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_player.py -v`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit**

```bash
git add resources/lib/player.py tests/test_player.py
git commit -m "feat: add Elementum playback handoff"
```

---

### Task 7: Router (menu wiring and actions)

**Files:**
- Create: `resources/lib/router.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: `sys.argv`, `xbmc*` (stubbed), `resources.lib.{sktorrent, torrent, player, settings}`.
- Produces:
  - `run() -> None` — the entry point called by `addon.py`.
  - `build_url(**params) -> str` — build a `plugin://` callback URL from the current base.
  - Internal handlers `root_menu`, `list_torrents`, `do_search`, `play_torrent` — exercised indirectly.

> **Design:** `run()` reads `sys.argv` (`[0]` base url, `[1]` handle, `[2]` `?query`). To keep it testable, factor the dispatch into `dispatch(base_url, handle, query_string)` and have `run()` call it with real argv.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_router.py`:

```python
from resources.lib import router


def test_build_url_roundtrip():
    router._BASE_URL = "plugin://plugin.video.sktorrent/"
    url = router.build_url(action="list", mode="latest", page=2)
    assert url.startswith("plugin://plugin.video.sktorrent/?")
    assert "action=list" in url
    assert "mode=latest" in url
    assert "page=2" in url


def test_dispatch_play_calls_player(monkeypatch):
    seen = {}

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        def resolve_download_url(self, detail_url):
            seen["detail"] = detail_url
            return "https://sktorrent.eu/download.php?id=1"

    monkeypatch.setattr(router.sktorrent, "SkTorrent", FakeClient)
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    monkeypatch.setattr(router.settings, "get_credentials", lambda: ("u", "p"))
    monkeypatch.setattr(
        router.torrent, "magnet_from_torrent_url", lambda s, url: "magnet:?xt=urn:btih:abc"
    )
    monkeypatch.setattr(
        router.player, "play", lambda handle, magnet, name="": seen.update(magnet=magnet, handle=handle)
    )

    router.dispatch(
        "plugin://plugin.video.sktorrent/",
        7,
        "?action=play&detail_url=https%3A%2F%2Fsktorrent.eu%2Fdetails.php%3Fid%3D1&name=Movie",
    )
    assert seen["detail"] == "https://sktorrent.eu/details.php?id=1"
    assert seen["magnet"] == "magnet:?xt=urn:btih:abc"
    assert seen["handle"] == 7


def test_dispatch_root_without_credentials_notifies(monkeypatch):
    notes = {}
    monkeypatch.setattr(router.settings, "has_credentials", lambda: False)
    import xbmcgui

    monkeypatch.setattr(
        xbmcgui.Dialog, "notification", lambda self, *a, **k: notes.update(shown=True)
    )
    # Should not raise, should still end the directory.
    router.dispatch("plugin://plugin.video.sktorrent/", 3, "")
    assert notes.get("shown") is True
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_router.py -v`
Expected: FAIL — `No module named 'resources.lib.router'`.

- [ ] **Step 3: Implement `resources/lib/router.py`**

```python
"""URL routing and directory building for plugin.video.sktorrent."""
import sys
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import sktorrent
from resources.lib import torrent
from resources.lib import player
from resources.lib import settings

_BASE_URL = ""
_HANDLE = -1


def build_url(**params):
    return _BASE_URL + "?" + urlencode(params)


def _notify(message):
    xbmcgui.Dialog().notification("SKTorrent", message)


def _client():
    username, password = settings.get_credentials()
    return sktorrent.SkTorrent(username, password)


def root_menu():
    xbmcplugin.setContent(_HANDLE, "videos")
    _add_dir("Search", build_url(action="search"))
    _add_dir("Latest torrents", build_url(action="list", mode="latest", page="0"))
    for label, value in sktorrent.CATEGORIES:
        _add_dir(label, build_url(action="list", mode="browse", category=value, page="0"))
    xbmcplugin.endOfDirectory(_HANDLE)


def _add_dir(label, url):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)


def _render_torrents(rows, next_url):
    xbmcplugin.setContent(_HANDLE, "videos")
    for row in rows:
        label = "%s  [%s S:%d L:%d]" % (
            row["title"],
            row["size"],
            row["seeders"],
            row["leechers"],
        )
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": row["title"]})
        li.setProperty("IsPlayable", "true")
        play_url = build_url(
            action="play", detail_url=row["detail_url"], name=row["title"]
        )
        xbmcplugin.addDirectoryItem(_HANDLE, play_url, li, isFolder=False)
    if next_url:
        _add_dir("Next page >>", next_url)
    xbmcplugin.endOfDirectory(_HANDLE)


def list_torrents(params):
    mode = params.get("mode", "latest")
    page = int(params.get("page", "0"))
    client = _client()
    try:
        if mode == "browse":
            category = params.get("category", "")
            rows = client.browse(category, page)
            next_url = build_url(
                action="list", mode="browse", category=category, page=str(page + 1)
            )
        else:
            rows = client.latest(page)
            next_url = build_url(action="list", mode="latest", page=str(page + 1))
    except Exception as exc:  # noqa: BLE001 - surface to user, keep addon alive
        xbmc.log("plugin.video.sktorrent list error: %s" % exc, xbmc.LOGERROR)
        _notify("Could not load torrents")
        xbmcplugin.endOfDirectory(_HANDLE)
        return
    _render_torrents(rows, next_url if rows else None)


def do_search(params):
    query = params.get("query")
    if not query:
        query = xbmcgui.Dialog().input("Search sktorrent.eu")
        if not query:
            xbmcplugin.endOfDirectory(_HANDLE)
            return
    page = int(params.get("page", "0"))
    client = _client()
    try:
        rows = client.search(query, page)
    except Exception as exc:  # noqa: BLE001
        xbmc.log("plugin.video.sktorrent search error: %s" % exc, xbmc.LOGERROR)
        _notify("Search failed")
        xbmcplugin.endOfDirectory(_HANDLE)
        return
    next_url = build_url(action="search", query=query, page=str(page + 1))
    _render_torrents(rows, next_url if rows else None)


def play_torrent(params):
    detail_url = params.get("detail_url")
    name = params.get("name", "")
    client = _client()
    try:
        download_url = client.resolve_download_url(detail_url)
        magnet = torrent.magnet_from_torrent_url(client.session, download_url)
    except Exception as exc:  # noqa: BLE001
        xbmc.log("plugin.video.sktorrent play error: %s" % exc, xbmc.LOGERROR)
        _notify("Could not resolve torrent")
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return
    player.play(_HANDLE, magnet, name)


def dispatch(base_url, handle, query_string):
    global _BASE_URL, _HANDLE
    _BASE_URL = base_url
    _HANDLE = handle
    params = dict(parse_qsl(query_string.lstrip("?")))
    action = params.get("action")

    if action in (None, "root") and not settings.has_credentials():
        _notify("Set your sktorrent.eu username and password in settings")
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    if action == "search":
        do_search(params)
    elif action == "list":
        list_torrents(params)
    elif action == "play":
        play_torrent(params)
    else:
        root_menu()


def run():
    base_url = sys.argv[0]
    handle = int(sys.argv[1])
    query_string = sys.argv[2] if len(sys.argv) > 2 else ""
    dispatch(base_url, handle, query_string)
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_router.py -v`
Expected: PASS (3 tests).

- [ ] **Step 5: Run the full suite**

Run: `pytest -v`
Expected: PASS (all tests across all modules).

- [ ] **Step 6: Commit**

```bash
git add resources/lib/router.py tests/test_router.py
git commit -m "feat: add URL router and menu wiring"
```

---

### Task 8: Packaging, icon, and manual verification notes

**Files:**
- Create: `resources/icon.png` (placeholder 512x512 PNG; replace with real art)
- Create: `README.md`

**Interfaces:**
- Consumes: everything above.
- Produces: an installable addon folder and a manual test checklist.

- [ ] **Step 1: Add a placeholder icon**

Generate a simple 512x512 PNG at `resources/icon.png` (any tool; it just needs to be a valid PNG so Kodi accepts the addon). For example:

```bash
python -c "import struct, zlib, binascii, base64, sys; \
open('resources/icon.png','wb').write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='))"
```

(This writes a 1x1 valid PNG. Replace with real 512x512 artwork before release.)

- [ ] **Step 2: Write `README.md`**

````markdown
# plugin.video.sktorrent

Kodi addon that searches/browses sktorrent.eu and streams torrents via Elementum
(no manual download).

## Requirements
- Kodi 19 (Matrix) or newer
- [Elementum](https://elementum.surge.sh/) installed and configured
- A sktorrent.eu account

## Setup
1. Install this addon (zip the folder or copy into `addons/`).
2. Open addon settings and enter your sktorrent.eu **username** and **password**.
3. Ensure Elementum is installed.

## Usage
- **Search** — enter a query, browse results, click to stream.
- **Latest / categories** — browse recent uploads or by category, with pagination.

## Development
```bash
pip install -r requirements-dev.txt
pytest -v
```
````

- [ ] **Step 3: Commit**

```bash
git add resources/icon.png README.md
git commit -m "chore: add icon and README"
```

- [ ] **Step 4: Manual verification in Kodi (checklist — not automated)**

Because router/login/Elementum handoff are thin glue over Kodi and a live login,
verify by hand:

1. Copy the folder to Kodi's `addons/` directory (or install from zip). Restart Kodi.
2. Enter credentials in addon settings.
3. Open the addon → confirm the root menu shows Search, Latest, and categories.
4. Open **Latest** → confirm a list of torrents renders with size/seeders. If the
   list is empty, capture the real `torrents_v2.php` HTML and re-pin
   `parse_listing` / fixtures (Task 4), then re-run `pytest`.
5. Click a torrent → confirm Elementum opens and begins streaming. If resolution
   fails, capture a real `details.php` page and re-pin `find_download_link`.
6. Confirm **Next page >>** advances pages.

Document any selector adjustments as follow-up commits to Task 4.

---

## Notes on live-site fragility

Two parsers depend on real HTML that could not be captured pre-implementation
(login required): `parse_listing` and `find_download_link` in `sktorrent.py`, plus
`CATEGORIES` values. They are written defensively (anchor/href-driven) and pinned
to representative fixtures. Step 4 of Task 8 is where they get validated and, if
needed, corrected against the live site. This is expected and called out so it is
not mistaken for "done" before manual verification.
