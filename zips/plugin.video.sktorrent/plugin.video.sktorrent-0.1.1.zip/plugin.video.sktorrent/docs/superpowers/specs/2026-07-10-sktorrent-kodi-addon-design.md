# plugin.video.sktorrent — Design

**Date:** 2026-07-10
**Status:** Approved

## Purpose

A Kodi video addon that lets a logged-in sktorrent.eu (Sk-CzTorrent) user search
and browse the tracker and stream torrents via Elementum — no manual `.torrent`
download and no full download before playback.

## Scope

- **Login required.** Credentials stored in addon settings.
- **Navigation:** Search, Browse categories, Latest torrents, with Next/Previous
  pagination on every list.
- **Playback:** magnet handed to the Elementum addon for sequential streaming.

Out of scope (YAGNI): favourites, user profile/ratio display, comments, uploading,
non-Elementum playback backends.

## Playback strategy

Kodi cannot play a magnet link natively, and Elementum cannot carry the
sktorrent login cookie. Therefore:

1. The addon downloads the authenticated `.torrent` file itself (session cookie).
2. It bencode-decodes the file, extracts the `info` dict, and computes the SHA-1
   info-hash.
3. It builds `magnet:?xt=urn:btih:<hash>&dn=<name>` (plus any announce trackers
   found in the `.torrent`).
4. It resolves playback to
   `plugin://plugin.video.elementum/play?uri=<url-encoded-magnet>`.

## Architecture

Standard `plugin://` routed video addon. Single entry point dispatches on URL
query parameters to handler functions. Site interaction, torrent conversion, and
Elementum handoff are isolated in separate modules so each can be understood and
tested independently.

### Directory layout

```
addon.xml                     addon metadata + dependencies
addon.py                      thin entry point -> resources.lib.router.run()
resources/
  settings.xml                username, password, items-per-page, Elementum id
  language/resource.language.en_gb/strings.po
  lib/
    router.py                 parse params, build xbmcplugin directory items
    sktorrent.py              session, login, search, browse, parse listings/detail
    torrent.py                download .torrent (authed), bencode, info-hash -> magnet
    player.py                 hand magnet to plugin.video.elementum
    settings.py               wrapper over xbmcaddon settings + cookie cache
    bencode.py                minimal bencode decoder (no external dep)
```

### Modules and responsibilities

- **router.py** — Maps the `plugin://` query (`action`, `url`, `page`, `query`,
  `category`) to a handler. Builds directory listings and playable list items.
  Depends on `sktorrent`, `torrent`, `player`, `settings`, and `xbmc*` modules.
- **sktorrent.py** — Owns a `requests.Session`. `login()` POSTs `login.php`
  (fields `Meno`, `Heslo`). `search(query, page)`, `browse(category, page)`,
  `latest(page)` return a list of `Torrent` dicts:
  `{title, detail_url, download_url, size, seeders, leechers, category}`.
  Parses HTML with BeautifulSoup. Transparently re-logs-in on session expiry
  (redirect to login / login form detected in response).
- **torrent.py** — `magnet_from_torrent_url(session, download_url)` downloads the
  `.torrent`, decodes it via `bencode.py`, computes the info-hash, and returns a
  magnet URI. Pure logic given a session; unit-testable with fixtures.
- **bencode.py** — Minimal, dependency-free bencode decoder returning Python
  structures plus the raw byte span of the `info` dict (so the info-hash is
  computed over exact original bytes).
- **player.py** — `play(handle, magnet)` builds the Elementum URL and calls
  `xbmcplugin.setResolvedUrl` with a `ListItem`. Checks Elementum is installed;
  notifies with an install hint if not.
- **settings.py** — Reads username/password/items-per-page/Elementum addon id
  from `xbmcaddon`. Caches the session cookie jar in the addon profile dir.

### Data flow (play)

```
user clicks item
  -> router: action=play, url=<detail-or-download>
  -> sktorrent: ensure logged in, resolve download_url
  -> torrent: download .torrent -> bencode -> info-hash -> magnet
  -> player: plugin://plugin.video.elementum/play?uri=<magnet>
  -> Kodi streams via Elementum
```

## Error handling

- Missing/blank credentials -> notification pointing to addon settings; abort.
- Login failure (bad credentials / unexpected response) -> notification; abort.
- Elementum not installed -> notification with install hint.
- Network/parse errors -> logged to `xbmc.log`; user-facing notification; render
  an empty (or partial) list instead of crashing.
- `.torrent` without a usable `info` dict -> notification; skip playback.

## Testing

- **Unit tests** (run outside Kodi, `xbmc*` modules stubbed on `sys.modules`):
  - `bencode.py` decode round-trips and info-span extraction.
  - `torrent.py` info-hash / magnet construction against a saved `.torrent`
    fixture (assert known info-hash).
  - `sktorrent.py` listing parser against saved `torrents_v2.php` HTML fixtures
    (assert extracted titles/sizes/seeders).
- **Manual verification** in Kodi for router wiring, login round-trip, and the
  Elementum handoff (thin glue not worth mocking Kodi for).

## Dependencies (addon.xml)

- `xbmc.python` version `3.0.0` (Python 3 / Kodi 19 Matrix and newer).
- `script.module.requests`
- `script.module.beautifulsoup4`
- `plugin.video.elementum` — optional import (playback backend), checked at
  runtime rather than hard-required, so the addon installs without it.

## Open assumptions to confirm during implementation

- The exact `.torrent` download URL pattern behind auth (derived from the detail
  page / `download.php`-style link) — confirmed by inspecting an authenticated
  page during implementation.
- Precise HTML row structure of `torrents_v2.php` — pinned via a saved fixture.
