"""Minimal, dependency-free bencode decoding with info-hash extraction."""
import hashlib


def decode(data):
    """Decode a bencoded document. Returns int/bytes/list/dict."""
    value, index = _decode(data, 0)
    if index != len(data):
        raise ValueError("trailing bytes after bencoded value")
    return value


def _decode(data, i):
    if i >= len(data):
        raise ValueError("unexpected end of data")
    c = data[i : i + 1]
    if c == b"i":
        end = data.index(b"e", i)
        return int(data[i + 1 : end]), end + 1
    if c == b"l":
        i += 1
        items = []
        while data[i : i + 1] != b"e":
            value, i = _decode(data, i)
            items.append(value)
        return items, i + 1
    if c == b"d":
        i += 1
        result = {}
        while data[i : i + 1] != b"e":
            key, i = _decode(data, i)
            value, i = _decode(data, i)
            result[key] = value
        return result, i + 1
    if c.isdigit():
        colon = data.index(b":", i)
        length = int(data[i:colon])
        start = colon + 1
        return data[start : start + length], start + length
    raise ValueError("invalid bencode at index %d" % i)


def info_hash(data):
    """Hex SHA-1 of the raw bytes of the top-level `info` dictionary."""
    if data[0:1] != b"d":
        raise ValueError("torrent is not a bencoded dict")
    i = 1
    while data[i : i + 1] != b"e":
        key, i = _decode(data, i)
        start = i
        _value, i = _decode(data, i)
        if key == b"info":
            return hashlib.sha1(data[start:i]).hexdigest()
    raise ValueError("no info dict in torrent")
