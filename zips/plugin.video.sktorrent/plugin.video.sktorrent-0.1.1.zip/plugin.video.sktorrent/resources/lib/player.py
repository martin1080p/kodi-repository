"""Hand a magnet link to Elementum (or a compatible streaming addon)."""
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import settings


def elementum_url(magnet, elementum_id="plugin.video.elementum"):
    return "plugin://%s/play?uri=%s" % (elementum_id, quote(magnet, safe=""))


def is_elementum_installed(elementum_id):
    try:
        import xbmcaddon

        xbmcaddon.Addon(elementum_id)
        return True
    except Exception:
        return False


def play(handle, magnet, name=""):
    elementum_id = settings.elementum_id()
    if not is_elementum_installed(elementum_id):
        xbmcgui.Dialog().notification(
            "SKTorrent",
            "Elementum (%s) is not installed" % elementum_id,
            xbmcgui.NOTIFICATION_ERROR if hasattr(xbmcgui, "NOTIFICATION_ERROR") else "",
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return False
    url = elementum_url(magnet, elementum_id)
    xbmc.log("plugin.video.sktorrent: resolving to %s" % url, xbmc.LOGINFO)
    list_item = xbmcgui.ListItem(label=name, path=url)
    xbmcplugin.setResolvedUrl(handle, True, list_item)
    return True
