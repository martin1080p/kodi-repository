"""Thin wrapper over Kodi addon settings."""
import os
import pickle

import xbmcaddon
import xbmcvfs


def _addon():
    return xbmcaddon.Addon()


def get_credentials():
    addon = _addon()
    return addon.getSetting("username"), addon.getSetting("password")


def has_credentials():
    username, password = get_credentials()
    return bool(username) and bool(password)


def elementum_id():
    return _addon().getSetting("elementum_id") or "plugin.video.elementum"


def _profile_dir():
    # getAddonInfo("profile") returns a special:// path; translatePath -> real FS path
    return xbmcvfs.translatePath(_addon().getAddonInfo("profile"))


def _cookie_file():
    return os.path.join(_profile_dir(), "session_cookies.pkl")


def load_cookies():
    """Return a dict of persisted cookies (name->value), or {} if none/unreadable."""
    try:
        with open(_cookie_file(), "rb") as fh:
            data = pickle.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_cookies(cookies):
    """Best-effort persist of a cookies dict (name->value). Failures are swallowed."""
    try:
        path = _cookie_file()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            pickle.dump(dict(cookies), fh)
    except Exception:
        pass
