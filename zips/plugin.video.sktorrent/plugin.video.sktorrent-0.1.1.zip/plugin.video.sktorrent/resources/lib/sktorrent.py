"""sktorrent.eu (Sk-CzTorrent) HTTP client and HTML parsing."""
import re
from urllib.parse import urljoin, urlencode

from bs4 import BeautifulSoup

# The site lives under /torrent/ — the bare host 302-redirects there, and every
# form action (login.php, torrents_v2.php, download.php) is relative to it.
BASE = "https://sktorrent.eu/torrent/"
LOGIN_URL = urljoin(BASE, "login.php")
LIST_URL = urljoin(BASE, "torrents_v2.php")
TIMEOUT = 30

# (menu label, category query value) — real category ids from the live site.
CATEGORIES = [
    ("Filmy CZ/SK dabing", "1"),
    ("Filmy s titulkami", "15"),
    ("Filmy bez titulkov", "31"),
    ("HD Filmy", "19"),
    ("UHD Filmy", "43"),
    ("Blu-ray Filmy", "28"),
    ("3D Filmy", "3"),
    ("Filmy Kreslené", "5"),
    ("Seriál", "16"),
    ("Dokument", "17"),
    ("TV Pořad", "42"),
    ("Sport", "44"),
    ("Hudba", "2"),
    ("Hudební videa", "26"),
    ("Hry na Windows", "18"),
    ("Hry na Konzole", "30"),
    ("Programy", "21"),
    ("Mobil, PDA", "27"),
    ("Knihy a Časopisy", "23"),
]

_SIZE_RE = re.compile(r"Velkost\s+([\d.,]+\s*[KMGTP]?i?B)", re.I)
_SEED_RE = re.compile(r"Odosielaj[uú]\s*:?\s*(\d+)", re.I)
_LEECH_RE = re.compile(r"Stahuj[uú]\s*:?\s*(\d+)", re.I)


def _soup(html):
    return BeautifulSoup(html, "html.parser")


def _first(pattern, text):
    match = pattern.search(text or "")
    return match.group(1).strip() if match else ""


def _int_from(pattern, text):
    value = _first(pattern, text)
    return int(value) if value.isdigit() else 0


def is_logged_in(html):
    lowered = html.lower()
    # A visible login form (uid/pwd inputs) means we are NOT authenticated.
    if 'name="uid"' in lowered and 'name="pwd"' in lowered:
        return False
    # Authenticated pages carry an "Odhlásit" (logout) link.
    return "odhlás" in lowered or "logout" in lowered


def parse_listing(html):
    soup = _soup(html)
    rows = []
    for anchor in soup.select('a[href^="details.php"]'):
        title = anchor.get_text(strip=True)
        if not title:
            continue
        detail_url = urljoin(BASE, anchor.get("href"))
        cell = anchor.find_parent("td")
        cell_text = cell.get_text(" ", strip=True) if cell is not None else ""
        rows.append(
            {
                "title": title,
                "detail_url": detail_url,
                "size": _first(_SIZE_RE, cell_text),
                "seeders": _int_from(_SEED_RE, cell_text),
                "leechers": _int_from(_LEECH_RE, cell_text),
                "category": _cell_category(cell),
            }
        )
    return rows


def _cell_category(cell):
    if cell is None:
        return ""
    link = cell.select_one('a[href*="category="]')
    return link.get_text(strip=True) if link else ""


def find_download_link(html):
    soup = _soup(html)
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"]
        if "download.php" in href or href.endswith(".torrent"):
            return urljoin(BASE, href)
    return None


class SkTorrent:
    def __init__(self, username, password, session=None):
        self.username = username
        self.password = password
        if session is None:
            import requests

            session = requests.Session()
            session.headers.update({"User-Agent": "Kodi plugin.video.sktorrent"})
        self.session = session
        self._logged_in = False

    def login(self):
        # The login POST returns only a tiny JS-redirect stub, so we cannot
        # judge success from its body. Post the credentials (fields uid/pwd),
        # then verify against a real authenticated page.
        resp = self.session.post(
            LOGIN_URL,
            data={"uid": self.username, "pwd": self.password},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        check = self.session.get(
            LIST_URL, params={"active": 0}, timeout=TIMEOUT
        )
        check.raise_for_status()
        self._logged_in = is_logged_in(check.text)
        return self._logged_in

    def load_cookies(self, cookie_dict):
        """Seed the session with persisted cookies and assume logged-in.

        If the cookies are stale, _fetch_list/resolve_download_url detect the
        logged-out response and transparently re-login.
        """
        if cookie_dict:
            self.session.cookies.update(cookie_dict)
            self._logged_in = True

    def dump_cookies(self):
        """Return the session cookies as a plain dict (empty on failure)."""
        try:
            return dict(self.session.cookies)
        except Exception:
            return {}

    def _ensure_login(self):
        if not self._logged_in:
            if not self.login():
                raise SkTorrentError("login failed")

    def _fetch_list(self, params):
        self._ensure_login()
        url = LIST_URL + "?" + urlencode(params)
        resp = self.session.get(url, timeout=TIMEOUT)
        resp.raise_for_status()
        if not is_logged_in(resp.text):
            # Session may have expired; try once more.
            if not self.login():
                raise SkTorrentError("session expired and re-login failed")
            resp = self.session.get(url, timeout=TIMEOUT)
            resp.raise_for_status()
        return parse_listing(resp.text)

    def search(self, query, page=0):
        return self._fetch_list({"search": query, "page": page})

    def browse(self, category, page=0):
        return self._fetch_list({"category": category, "page": page})

    def latest(self, page=0):
        return self._fetch_list({"active": 0, "order": "data", "by": "DESC", "page": page})

    def resolve_download_url(self, detail_url):
        self._ensure_login()
        resp = self.session.get(detail_url, timeout=TIMEOUT)
        resp.raise_for_status()
        if not is_logged_in(resp.text):
            # Session may have expired; try once more.
            if not self.login():
                raise SkTorrentError("session expired and re-login failed")
            resp = self.session.get(detail_url, timeout=TIMEOUT)
            resp.raise_for_status()
        link = find_download_link(resp.text)
        if not link:
            raise SkTorrentError("no .torrent download link on detail page")
        return link


class SkTorrentError(Exception):
    pass
