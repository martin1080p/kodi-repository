"""Convert a .torrent (bytes or authenticated URL) into a magnet link."""
from urllib.parse import quote_plus

from resources.lib import bencode

DEFAULT_TIMEOUT = 30


def build_magnet(info_hash_hex, name="", trackers=None):
    parts = ["xt=urn:btih:" + info_hash_hex]
    if name:
        parts.append("dn=" + quote_plus(name))
    for tracker in trackers or []:
        parts.append("tr=" + quote_plus(tracker))
    return "magnet:?" + "&".join(parts)


def _collect_trackers(meta):
    trackers = []
    announce = meta.get(b"announce")
    if announce:
        trackers.append(announce.decode("utf-8", "replace"))
    for tier in meta.get(b"announce-list", []) or []:
        for url in tier:
            decoded = url.decode("utf-8", "replace")
            if decoded not in trackers:
                trackers.append(decoded)
    return trackers


def magnet_from_torrent_bytes(data):
    meta = bencode.decode(data)
    ih = bencode.info_hash(data)
    info = meta.get(b"info", {})
    name = info.get(b"name", b"").decode("utf-8", "replace")
    return build_magnet(ih, name, _collect_trackers(meta))


def magnet_from_torrent_url(session, url, timeout=DEFAULT_TIMEOUT):
    resp = session.get(url, timeout=timeout)
    resp.raise_for_status()
    return magnet_from_torrent_bytes(resp.content)
