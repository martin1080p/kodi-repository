"""Test harness: put repo root on sys.path and stub Kodi modules.

Pure-logic modules (bencode, torrent, sktorrent) do not import xbmc*, but
router/player/settings do. Stubbing here lets those import under pytest.
"""
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def _install_kodi_stubs():
    xbmc = types.ModuleType("xbmc")
    xbmc.LOGINFO = 1
    xbmc.LOGERROR = 4
    xbmc.log = lambda msg, level=1: None

    xbmcgui = types.ModuleType("xbmcgui")

    class _ListItem:
        def __init__(self, label="", path=""):
            self.label = label
            self.path = path
            self._info = {}
            self._props = {}

        def setInfo(self, kind, values):
            self._info[kind] = values

        def setProperty(self, key, value):
            self._props[key] = value

        def setArt(self, art):
            self._props["art"] = art

    class _Dialog:
        def notification(self, *a, **k):
            return None

        def input(self, *a, **k):
            return ""

    xbmcgui.ListItem = _ListItem
    xbmcgui.Dialog = _Dialog

    xbmcplugin = types.ModuleType("xbmcplugin")
    xbmcplugin.addDirectoryItem = lambda *a, **k: None
    xbmcplugin.endOfDirectory = lambda *a, **k: None
    xbmcplugin.setResolvedUrl = lambda *a, **k: None
    xbmcplugin.setContent = lambda *a, **k: None

    xbmcaddon = types.ModuleType("xbmcaddon")

    class _Addon:
        _store = {
            "username": "",
            "password": "",
            "elementum_id": "plugin.video.elementum",
        }

        def getSetting(self, key):
            return self._store.get(key, "")

        def setSetting(self, key, value):
            self._store[key] = value

        def getAddonInfo(self, key):
            return {"id": "plugin.video.sktorrent", "profile": "special://profile"}.get(key, "")

    xbmcaddon.Addon = _Addon

    xbmcvfs = types.ModuleType("xbmcvfs")
    xbmcvfs.translatePath = lambda p: p

    for name, mod in {
        "xbmc": xbmc,
        "xbmcgui": xbmcgui,
        "xbmcplugin": xbmcplugin,
        "xbmcaddon": xbmcaddon,
        "xbmcvfs": xbmcvfs,
    }.items():
        sys.modules.setdefault(name, mod)


_install_kodi_stubs()
