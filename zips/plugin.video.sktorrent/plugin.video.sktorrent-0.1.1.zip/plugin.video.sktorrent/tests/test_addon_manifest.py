import os
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _tree():
    return ET.parse(os.path.join(ROOT, "addon.xml"))


def test_addon_id_and_version():
    addon = _tree().getroot()
    assert addon.tag == "addon"
    assert addon.get("id") == "plugin.video.sktorrent"
    assert addon.get("version")
    assert addon.get("provider-name")


def test_declares_required_dependencies():
    addon = _tree().getroot()
    imports = {
        i.get("addon"): i.get("optional", "false")
        for i in addon.findall("./requires/import")
    }
    assert imports.get("xbmc.python") == "false" or "xbmc.python" in imports
    assert "script.module.requests" in imports
    assert "script.module.beautifulsoup4" in imports
    # Elementum must be present AND optional
    assert imports.get("plugin.video.elementum") == "true"


def test_is_video_plugin_extension():
    addon = _tree().getroot()
    points = {e.get("point") for e in addon.findall("./extension")}
    assert "xbmc.python.pluginsource" in points
    src = addon.find("./extension[@point='xbmc.python.pluginsource']")
    assert src.get("library") == "addon.py"
