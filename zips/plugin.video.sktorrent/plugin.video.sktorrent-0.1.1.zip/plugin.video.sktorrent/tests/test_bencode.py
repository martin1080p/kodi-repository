import hashlib
from resources.lib import bencode


def test_decode_int():
    assert bencode.decode(b"i42e") == 42
    assert bencode.decode(b"i-7e") == -7


def test_decode_string():
    assert bencode.decode(b"4:spam") == b"spam"


def test_decode_list():
    assert bencode.decode(b"l4:spami42ee") == [b"spam", 42]


def test_decode_dict():
    assert bencode.decode(b"d3:cow3:moo4:spam4:eggse") == {
        b"cow": b"moo",
        b"spam": b"eggs",
    }


def test_info_hash_matches_manual_sha1():
    # A minimal torrent: d ...announce... 4:info <infodict> e
    info = b"d6:lengthi10e4:name4:file12:piece lengthi16384e6:pieces20:" + b"\x00" * 20 + b"e"
    torrent = b"d8:announce19:http://tracker.test4:info" + info + b"e"
    expected = hashlib.sha1(info).hexdigest()
    assert bencode.info_hash(torrent) == expected


def test_info_hash_missing_info_raises():
    import pytest
    with pytest.raises(ValueError):
        bencode.info_hash(b"d8:announce3:abce")
