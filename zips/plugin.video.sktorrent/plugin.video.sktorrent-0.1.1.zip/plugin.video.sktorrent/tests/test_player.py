from resources.lib import player


def test_elementum_url_encodes_magnet():
    url = player.elementum_url("magnet:?xt=urn:btih:abc&dn=x y")
    assert url.startswith("plugin://plugin.video.elementum/play?uri=")
    assert "magnet%3A%3Fxt%3Durn%3Abtih%3Aabc" in url


def test_elementum_url_respects_custom_id():
    url = player.elementum_url("magnet:?xt=urn:btih:abc", "plugin.video.torrest")
    assert url.startswith("plugin://plugin.video.torrest/play?uri=")


def test_play_sets_resolved_url_when_installed(monkeypatch):
    calls = {}
    import xbmcplugin

    monkeypatch.setattr(player, "is_elementum_installed", lambda _id: True)
    monkeypatch.setattr(
        xbmcplugin,
        "setResolvedUrl",
        lambda handle, ok, li: calls.update(handle=handle, ok=ok, li=li),
    )
    result = player.play(5, "magnet:?xt=urn:btih:abc", "Movie")
    assert result is True
    assert calls["handle"] == 5
    assert calls["ok"] is True
    assert calls["li"].path.startswith("plugin://plugin.video.elementum/play?uri=")


def test_play_fails_when_not_installed(monkeypatch):
    import xbmcplugin

    seen = {}
    monkeypatch.setattr(player, "is_elementum_installed", lambda _id: False)
    monkeypatch.setattr(
        xbmcplugin, "setResolvedUrl", lambda handle, ok, li: seen.update(ok=ok)
    )
    result = player.play(5, "magnet:?xt=urn:btih:abc")
    assert result is False
    assert seen["ok"] is False
