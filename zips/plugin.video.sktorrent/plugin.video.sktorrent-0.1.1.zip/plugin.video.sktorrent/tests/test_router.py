from resources.lib import router


def test_build_url_roundtrip():
    router._BASE_URL = "plugin://plugin.video.sktorrent/"
    url = router.build_url(action="list", mode="latest", page=2)
    assert url.startswith("plugin://plugin.video.sktorrent/?")
    assert "action=list" in url
    assert "mode=latest" in url
    assert "page=2" in url


def test_dispatch_play_calls_player(monkeypatch):
    seen = {}
    saved = {}

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        def load_cookies(self, d):
            pass

        def dump_cookies(self):
            return {}

        def resolve_download_url(self, detail_url):
            seen["detail"] = detail_url
            return "https://sktorrent.eu/download.php?id=1"

    monkeypatch.setattr(router.sktorrent, "SkTorrent", FakeClient)
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    monkeypatch.setattr(router.settings, "get_credentials", lambda: ("u", "p"))
    monkeypatch.setattr(router.settings, "load_cookies", lambda: {})
    monkeypatch.setattr(
        router.settings, "save_cookies", lambda cookies: saved.update(cookies=cookies)
    )
    monkeypatch.setattr(
        router.torrent, "magnet_from_torrent_url", lambda s, url: "magnet:?xt=urn:btih:abc"
    )
    monkeypatch.setattr(
        router.player, "play", lambda handle, magnet, name="": seen.update(magnet=magnet, handle=handle)
    )

    router.dispatch(
        "plugin://plugin.video.sktorrent/",
        7,
        "?action=play&detail_url=https%3A%2F%2Fsktorrent.eu%2Fdetails.php%3Fid%3D1&name=Movie",
    )
    assert seen["detail"] == "https://sktorrent.eu/details.php?id=1"
    assert seen["magnet"] == "magnet:?xt=urn:btih:abc"
    assert seen["handle"] == 7
    # Cookies persisted after a successful action.
    assert "cookies" in saved


def test_dispatch_root_without_credentials_notifies(monkeypatch):
    notes = {}
    monkeypatch.setattr(router.settings, "has_credentials", lambda: False)
    import xbmcgui

    monkeypatch.setattr(
        xbmcgui.Dialog, "notification", lambda self, *a, **k: notes.update(shown=True)
    )
    # Should not raise, should still end the directory.
    router.dispatch("plugin://plugin.video.sktorrent/", 3, "")
    assert notes.get("shown") is True


# --- Coverage additions (post-review) -------------------------------------

BASE = "plugin://plugin.video.sktorrent/"


def _fake_row(title, detail_url):
    return {
        "title": title,
        "detail_url": detail_url,
        "size": "1.4 GB",
        "seeders": 10,
        "leechers": 2,
        "category": "Filmy",
    }


def _record_add_dir(monkeypatch):
    """Monkeypatch xbmcplugin.addDirectoryItem to record (url, label) tuples."""
    import xbmcplugin

    calls = []

    def _add(handle, url, li, isFolder=True):
        calls.append((url, li.label, isFolder))

    monkeypatch.setattr(xbmcplugin, "addDirectoryItem", _add)
    return calls


def _record_end_of_directory(monkeypatch):
    import xbmcplugin

    flags = {"count": 0}
    monkeypatch.setattr(
        xbmcplugin, "endOfDirectory", lambda *a, **k: flags.update(count=flags["count"] + 1)
    )
    return flags


def test_root_menu_renders_search_latest_and_categories(monkeypatch):
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "")

    assert len(calls) == 2 + len(router.sktorrent.CATEGORIES)
    assert calls[0][1] == "Search"
    assert calls[1][1] == "Latest torrents"
    labels = [label for (_url, label, _folder) in calls]
    assert "Dokument" in labels
    # Every menu entry is a folder.
    assert all(folder is True for (_url, _label, folder) in calls)


def _record_save_cookies(monkeypatch):
    """Monkeypatch settings.load_cookies/save_cookies; return the save-calls list."""
    monkeypatch.setattr(router.settings, "load_cookies", lambda: {})
    calls = []
    monkeypatch.setattr(router.settings, "save_cookies", lambda cookies: calls.append(cookies))
    return calls


def _install_fake_client(monkeypatch, rows):
    seen = {}

    class FakeClient:
        session = object()

        def __init__(self, *a, **k):
            pass

        def load_cookies(self, d):
            pass

        def dump_cookies(self):
            return {}

        def latest(self, page):
            seen["latest_page"] = page
            return rows

        def browse(self, category, page):
            seen["browse"] = (category, page)
            return rows

        def search(self, query, page):
            seen["search"] = (query, page)
            return rows

    monkeypatch.setattr(router.sktorrent, "SkTorrent", FakeClient)
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    monkeypatch.setattr(router.settings, "get_credentials", lambda: ("u", "p"))
    _record_save_cookies(monkeypatch)
    return seen


def test_list_torrents_latest_renders_rows_and_next_page(monkeypatch):
    rows = [_fake_row("A", "https://x/details.php?id=1"),
            _fake_row("B", "https://x/details.php?id=2")]
    _install_fake_client(monkeypatch, rows)
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 9, "?action=list&mode=latest&page=0")

    # 2 playable rows + 1 Next page item.
    assert len(calls) == 3
    playable = calls[:2]
    assert all(folder is False for (_url, _label, folder) in playable)
    assert all("action=play" in url for (url, _label, _folder) in playable)
    next_url, next_label, next_folder = calls[2]
    assert next_label == "Next page >>"
    assert next_folder is True
    assert "page=1" in next_url
    assert "mode=latest" in next_url


def test_list_torrents_browse_renders_next_page_with_category(monkeypatch):
    rows = [_fake_row("A", "https://x/details.php?id=1"),
            _fake_row("B", "https://x/details.php?id=2")]
    seen = _install_fake_client(monkeypatch, rows)
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 9, "?action=list&mode=browse&category=1&page=0")

    assert seen["browse"] == ("1", 0)
    next_url = calls[-1][0]
    assert calls[-1][1] == "Next page >>"
    assert "category=1" in next_url
    assert "page=1" in next_url
    assert "mode=browse" in next_url


def test_list_torrents_empty_has_no_next_page(monkeypatch):
    _install_fake_client(monkeypatch, [])
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 9, "?action=list&mode=latest&page=0")

    assert calls == []


def test_do_search_prompt_cancelled_no_search(monkeypatch):
    seen = _install_fake_client(monkeypatch, [_fake_row("A", "u")])
    import xbmcgui

    monkeypatch.setattr(xbmcgui.Dialog, "input", lambda self, *a, **k: "")
    _record_add_dir(monkeypatch)
    flags = _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 4, "?action=search")

    assert "search" not in seen
    assert flags["count"] == 1


def test_do_search_prompt_returns_query_and_renders(monkeypatch):
    rows = [_fake_row("A", "https://x/details.php?id=1")]
    seen = _install_fake_client(monkeypatch, rows)
    import xbmcgui

    monkeypatch.setattr(xbmcgui.Dialog, "input", lambda self, *a, **k: "bunny")
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 4, "?action=search")

    assert seen["search"] == ("bunny", 0)
    # 1 playable row + Next page.
    assert calls[0][2] is False
    assert calls[-1][1] == "Next page >>"


def _install_raising_client(monkeypatch, method):
    class FakeClient:
        session = object()

        def __init__(self, *a, **k):
            pass

        def load_cookies(self, d):
            pass

        def dump_cookies(self):
            return {}

        def latest(self, page):
            raise RuntimeError("boom")

        def browse(self, category, page):
            raise RuntimeError("boom")

        def search(self, query, page):
            raise RuntimeError("boom")

        def resolve_download_url(self, detail_url):
            raise RuntimeError("boom")

    monkeypatch.setattr(router.sktorrent, "SkTorrent", FakeClient)
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    monkeypatch.setattr(router.settings, "get_credentials", lambda: ("u", "p"))
    return _record_save_cookies(monkeypatch)


def _record_notification(monkeypatch):
    import xbmcgui

    flags = {"shown": False}
    monkeypatch.setattr(
        xbmcgui.Dialog, "notification", lambda self, *a, **k: flags.update(shown=True)
    )
    return flags


def test_list_torrents_error_notifies_and_ends(monkeypatch):
    save_calls = _install_raising_client(monkeypatch, "latest")
    notes = _record_notification(monkeypatch)
    flags = _record_end_of_directory(monkeypatch)

    # Must not raise.
    router.dispatch(BASE, 9, "?action=list&mode=latest&page=0")

    assert notes["shown"] is True
    assert flags["count"] == 1
    # Cookies persisted even on the error path (finally block).
    assert len(save_calls) == 1


def test_do_search_error_notifies_and_ends(monkeypatch):
    _install_raising_client(monkeypatch, "search")
    notes = _record_notification(monkeypatch)
    flags = _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 9, "?action=search&query=x&page=0")

    assert notes["shown"] is True
    assert flags["count"] == 1


def test_play_torrent_error_notifies_and_sets_failed_resolved_url(monkeypatch):
    _install_raising_client(monkeypatch, "resolve_download_url")
    notes = _record_notification(monkeypatch)
    import xbmcplugin

    resolved = {}
    monkeypatch.setattr(
        xbmcplugin,
        "setResolvedUrl",
        lambda handle, ok, li: resolved.update(handle=handle, ok=ok),
    )
    # Ensure player.play is NOT reached on the error path.
    monkeypatch.setattr(
        router.player, "play", lambda *a, **k: resolved.update(played=True)
    )

    router.dispatch(BASE, 11, "?action=play&detail_url=https%3A%2F%2Fx%2Fdetails.php%3Fid%3D1&name=M")

    assert notes["shown"] is True
    assert resolved["ok"] is False
    assert resolved["handle"] == 11
    assert "played" not in resolved
