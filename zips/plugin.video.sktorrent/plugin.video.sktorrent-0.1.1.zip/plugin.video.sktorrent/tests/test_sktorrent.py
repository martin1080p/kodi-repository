import os

import pytest

from resources.lib import sktorrent

FIX = os.path.join(os.path.dirname(__file__), "fixtures")


def _read(name):
    with open(os.path.join(FIX, name), "r", encoding="utf-8") as fh:
        return fh.read()


def test_parse_listing_extracts_rows():
    rows = sktorrent.parse_listing(_read("listing.html"))
    assert len(rows) == 2
    first = rows[0]
    assert first["title"] == "The Matrix Generation (2023)(CZ)[WEB-DL][1080p] = CSFD 58%"
    assert "details.php?name=The-Matrix-Generation-abc" in first["detail_url"]
    assert first["detail_url"].startswith("https://sktorrent.eu/torrent/")
    assert first["size"] == "1.1 GB"
    assert first["seeders"] == 8
    assert first["leechers"] == 0
    assert first["category"] == "Dokument"

    second = rows[1]
    assert second["title"] == "Matrix Reloaded (2003)"
    assert second["size"] == "5.4 GB"
    assert second["seeders"] == 25
    assert second["leechers"] == 3
    assert second["category"] == "Filmy CZ/SK dabing"


def test_find_download_link():
    link = sktorrent.find_download_link(_read("detail.html"))
    assert "download.php?id=aaaa1111" in link
    assert link.startswith("https://sktorrent.eu/torrent/")


def test_is_logged_in_true_when_logout_present():
    assert sktorrent.is_logged_in(_read("detail.html")) is True


def test_is_logged_in_false_on_login_form():
    html = '<form action="login.php"><input name="uid"><input name="pwd"></form>'
    assert sktorrent.is_logged_in(html) is False


def test_login_posts_credentials_and_detects_success():
    posted = {}

    class FakeResp:
        def __init__(self, text):
            self.text = text
            self.status_code = 200

        def raise_for_status(self):
            return None

    class FakeSession:
        def post(self, url, data=None, **kwargs):
            posted["url"] = url
            posted["data"] = data
            # The real login POST returns only a JS-redirect stub.
            return FakeResp("<script>window.location.href='torrents_v2.php'</script>")

        def get(self, url, **kwargs):
            # login() verifies against an authenticated page.
            return FakeResp('<a href="login.php?logout=1">Odhlásit</a>')

    client = sktorrent.SkTorrent("alice", "secret", session=FakeSession())
    assert client.login() is True
    assert posted["url"].endswith("login.php")
    assert posted["data"] == {"uid": "alice", "pwd": "secret"}


def test_login_returns_false_on_failure():
    class FakeResp:
        # Bad credentials -> the authenticated-page check still shows the form.
        text = '<form action="login.php"><input name="uid"><input name="pwd"></form>'
        status_code = 200

        def raise_for_status(self):
            return None

    class FakeSession:
        def post(self, *a, **k):
            return FakeResp()

        def get(self, *a, **k):
            return FakeResp()

    client = sktorrent.SkTorrent("bad", "creds", session=FakeSession())
    assert client.login() is False


def test_categories_present():
    assert isinstance(sktorrent.CATEGORIES, list)
    assert all(len(pair) == 2 for pair in sktorrent.CATEGORIES)
    assert len(sktorrent.CATEGORIES) >= 1


_LOGGED_OUT_HTML = '<form action="login.php"><input name="uid"><input name="pwd"></form>'
_LOGGED_IN_HTML = '<a href="login.php?logout=1">Odhlásit</a>'


class _RetryResp:
    def __init__(self, text):
        self.text = text
        self.status_code = 200

    def raise_for_status(self):
        return None


class _RetrySession:
    """Fake session: first GET is logged-out, later GETs return listing HTML.

    ``login_succeeds`` controls whether a POST (re-login) flips the state to
    logged-in. Tracks calls so the expiry-retry path can be exercised.
    """

    def __init__(self, listing_html, login_succeeds=True):
        self.listing_html = listing_html
        self.login_succeeds = login_succeeds
        self._logged_in = True  # login() during _ensure_login already ran
        self.get_calls = 0
        self.post_calls = 0

    def post(self, url, data=None, **kwargs):
        self.post_calls += 1
        self._logged_in = self.login_succeeds
        return _RetryResp(_LOGGED_IN_HTML if self.login_succeeds else _LOGGED_OUT_HTML)

    def get(self, url, **kwargs):
        self.get_calls += 1
        # First GET simulates an expired session (logged-out page).
        if self.get_calls == 1:
            return _RetryResp(_LOGGED_OUT_HTML)
        if self._logged_in:
            # Authenticated pages carry the logout marker AND the listing.
            return _RetryResp(_LOGGED_IN_HTML + self.listing_html)
        return _RetryResp(_LOGGED_OUT_HTML)


def _make_logged_in_client(session):
    client = sktorrent.SkTorrent("alice", "secret", session=session)
    client._logged_in = True  # pretend an earlier login succeeded
    return client


def test_fetch_list_reloads_on_expired_session():
    session = _RetrySession(_read("listing.html"), login_succeeds=True)
    client = _make_logged_in_client(session)
    rows = client.search("bunny")
    assert len(rows) == 2
    assert session.post_calls == 1  # re-login happened
    # initial (expired) GET + login's verification GET + retry GET
    assert session.get_calls == 3


def test_browse_reloads_on_expired_session():
    session = _RetrySession(_read("listing.html"), login_succeeds=True)
    client = _make_logged_in_client(session)
    rows = client.browse("1")
    assert len(rows) == 2


def test_latest_reloads_on_expired_session():
    session = _RetrySession(_read("listing.html"), login_succeeds=True)
    client = _make_logged_in_client(session)
    rows = client.latest()
    assert len(rows) == 2


def test_fetch_list_raises_when_relogin_fails():
    session = _RetrySession(_read("listing.html"), login_succeeds=False)
    client = _make_logged_in_client(session)
    with pytest.raises(sktorrent.SkTorrentError):
        client.search("bunny")


class _DetailRetrySession:
    """Fake session for resolve_download_url expiry-retry coverage."""

    def __init__(self, detail_html, login_succeeds=True):
        self.detail_html = detail_html
        self.login_succeeds = login_succeeds
        self.get_calls = 0
        self.post_calls = 0

    def post(self, url, data=None, **kwargs):
        self.post_calls += 1
        return _RetryResp(_LOGGED_IN_HTML if self.login_succeeds else _LOGGED_OUT_HTML)

    def get(self, url, **kwargs):
        self.get_calls += 1
        if self.get_calls == 1:
            return _RetryResp(_LOGGED_OUT_HTML)
        return _RetryResp(self.detail_html if self.login_succeeds else _LOGGED_OUT_HTML)


def test_resolve_download_url_reloads_on_expired_session():
    session = _DetailRetrySession(_read("detail.html"), login_succeeds=True)
    client = _make_logged_in_client(session)
    link = client.resolve_download_url("https://sktorrent.eu/torrent/details.php?id=aaaa1111")
    assert "download.php?id=aaaa1111" in link
    assert link.startswith("https://sktorrent.eu/torrent/")
    assert session.post_calls == 1
    # initial (expired) GET + login's verification GET + retry GET
    assert session.get_calls == 3


def test_resolve_download_url_raises_when_relogin_fails():
    session = _DetailRetrySession(_read("detail.html"), login_succeeds=False)
    client = _make_logged_in_client(session)
    with pytest.raises(sktorrent.SkTorrentError):
        client.resolve_download_url("https://sktorrent.eu/torrent/details.php?id=aaaa1111")


# A listing page that ALSO carries the logged-in marker (logout link), so
# is_logged_in() reports True while parse_listing() still finds both rows.
def _logged_in_listing_html():
    return '<a href="login.php?logout=1">Odhlásiť</a>' + _read("listing.html")


class _CookieSession:
    """Fake session with a plain-dict ``cookies`` attribute.

    Its first GET returns the logged-in listing page directly, so if the
    client trusts a cached cookie (rather than forcing a fresh login) no POST
    should ever happen.
    """

    def __init__(self, listing_html):
        self.cookies = {}
        self.listing_html = listing_html
        self.get_calls = 0
        self.post_calls = 0

    def post(self, url, data=None, **kwargs):
        self.post_calls += 1
        return _RetryResp(_LOGGED_IN_HTML)

    def get(self, url, **kwargs):
        self.get_calls += 1
        return _RetryResp(self.listing_html)


def test_load_cookies_seeds_session_and_skips_login():
    session = _CookieSession(_logged_in_listing_html())
    client = sktorrent.SkTorrent("alice", "secret", session=session)
    client.load_cookies({"uid": "abc"})
    assert client._logged_in is True

    rows = client.search("bunny")

    assert session.post_calls == 0
    assert len(rows) == 2


def test_load_cookies_with_empty_dict_still_requires_login():
    session = _CookieSession(_logged_in_listing_html())
    client = sktorrent.SkTorrent("alice", "secret", session=session)
    client.load_cookies({})
    assert not client._logged_in

    rows = client.search("bunny")

    assert session.post_calls == 1
    assert len(rows) == 2


def test_dump_cookies_returns_session_cookies_dict():
    session = _CookieSession(_logged_in_listing_html())
    client = sktorrent.SkTorrent("alice", "secret", session=session)
    session.cookies["uid"] = "abc"
    assert client.dump_cookies() == {"uid": "abc"}
