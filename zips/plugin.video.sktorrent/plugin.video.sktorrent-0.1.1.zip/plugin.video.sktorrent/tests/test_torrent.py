from resources.lib import torrent


def _sample_torrent():
    info = b"d6:lengthi10e4:name8:file.mkv12:piece lengthi16384e6:pieces20:" + b"\x00" * 20 + b"e"
    return b"d8:announce19:http://tracker.test4:info" + info + b"e", info


def test_build_magnet_minimal():
    m = torrent.build_magnet("abc123")
    assert m == "magnet:?xt=urn:btih:abc123"


def test_build_magnet_with_name_and_trackers():
    m = torrent.build_magnet("abc123", "My File", ["http://a/announce", "http://b/announce"])
    assert m.startswith("magnet:?xt=urn:btih:abc123")
    assert "dn=My+File" in m
    assert "tr=http%3A%2F%2Fa%2Fannounce" in m
    assert "tr=http%3A%2F%2Fb%2Fannounce" in m


def test_magnet_from_torrent_bytes_uses_info_hash_and_name():
    data, _info = _sample_torrent()
    m = torrent.magnet_from_torrent_bytes(data)
    from resources.lib import bencode
    assert ("xt=urn:btih:" + bencode.info_hash(data)) in m
    assert "dn=file.mkv" in m
    assert "tr=http%3A%2F%2Ftracker.test" in m


def test_magnet_from_torrent_url_reads_session_content():
    data, _info = _sample_torrent()

    class FakeResp:
        content = data

        def raise_for_status(self):
            return None

    class FakeSession:
        def __init__(self):
            self.requested = None
            self.kwargs = None

        def get(self, url, **kwargs):
            self.requested = url
            self.kwargs = kwargs
            return FakeResp()

    s = FakeSession()
    m = torrent.magnet_from_torrent_url(s, "http://x/download.php?id=1")
    assert s.requested == "http://x/download.php?id=1"
    assert s.kwargs.get("timeout") == 30
    assert m.startswith("magnet:?xt=urn:btih:")


def test_magnet_from_torrent_url_forwards_custom_timeout():
    data, _info = _sample_torrent()

    class FakeResp:
        content = data

        def raise_for_status(self):
            return None

    class FakeSession:
        def __init__(self):
            self.kwargs = None

        def get(self, url, **kwargs):
            self.kwargs = kwargs
            return FakeResp()

    s = FakeSession()
    torrent.magnet_from_torrent_url(s, "http://x/download.php?id=1", timeout=5)
    assert s.kwargs.get("timeout") == 5
