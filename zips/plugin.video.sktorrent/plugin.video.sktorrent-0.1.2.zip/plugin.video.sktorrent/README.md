# plugin.video.sktorrent

Kodi addon that searches/browses sktorrent.eu and streams torrents via Elementum
(no manual download).

## Requirements
- Kodi 19 (Matrix) or newer
- [Elementum](https://elementum.surge.sh/) installed and configured
- A sktorrent.eu account

## Setup
1. Install this addon (zip the folder or copy into `addons/`).
2. Open addon settings and enter your sktorrent.eu **username** and **password**.
3. Ensure Elementum is installed.

## Usage
- **Search** — enter a query, browse results, click to stream.
- **Latest / categories** — browse recent uploads or by category, with pagination.

## TMDB Helper integration

This addon ships a player file for
[TMDB Helper](https://github.com/jurialmunkey/plugin.video.themoviedb.helper).

Copy `resources/tmdbhelper/sktorrent.json` into TMDB Helper's players folder:

```
<Kodi userdata>/addon_data/plugin.video.themoviedb.helper/players/sktorrent.json
```

(On most systems `<Kodi userdata>` is `~/.kodi/userdata` on Linux,
`%APPDATA%\Kodi\userdata` on Windows, or
`~/Library/Application Support/Kodi/userdata` on macOS.)

Then, on a movie or episode in TMDB Helper, choose **Play** / **Search** and
pick **SKTorrent**. It searches sktorrent (movies by title + year, episodes by
show title), lists the matching releases, and streams the one you pick via
Elementum.

## Development
```bash
pip install -r requirements-dev.txt
pytest -v
```
