# Movies/TV taxonomy, localization, images & TMDB Helper — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restructure the sktorrent addon menu into Search / Movies / TV Shows with localized (en/cs/sk) labels, render results as a poster grid with artwork and info, and ship a TMDB Helper player (`sktorrent.json`).

**Architecture:** Incremental change to the existing `plugin.video.sktorrent` addon. Taxonomy lives in `sktorrent.py`; localization is resolved through a new `settings.localized()` helper backed by three `strings.po` files; the router gains a `group` route and localized menu; `_render_torrents` is enriched with content type, art, and info; a static `sktorrent.json` integrates with TMDB Helper by reusing the existing `action=search` route.

**Tech Stack:** Python 3, Kodi 19+ (Matrix), requests, beautifulsoup4, Elementum, TMDB Helper (`plugin.video.themoviedb.helper`), pytest.

## Global Constraints

- Addon id / plugin id: `plugin.video.sktorrent`.
- Pure-logic modules (`bencode.py`, `torrent.py`, `sktorrent.py`) MUST NOT import `xbmc`/`xbmcgui`/`xbmcplugin`/`xbmcaddon`. `settings.py`, `player.py`, `router.py` are Kodi-facing and may.
- Localization: three language dirs under `resources/language/`: `resource.language.en_gb`, `resource.language.cs_cz`, `resource.language.sk_sk`. Every string id appears in all three files, with the SAME `msgctxt "#id"` and English `msgid`; only `msgstr` differs (empty in en_gb → Kodi uses msgid).
- Menu labels resolved via `settings.localized(string_id, fallback)`; the in-code fallback equals the English label.
- Category taxonomy (source of truth in `sktorrent.py`), each entry `(string_id:int, english_fallback:str, category_id:str)`:
  - MOVIE_CATEGORIES: `(30020,"CZ/SK dubbing","1")`, `(30021,"With subtitles","15")`, `(30022,"Without subtitles","31")`.
  - TVSHOW_CATEGORIES: `(30023,"Series","16")`, `(30024,"TV programmes","42")`, `(30025,"Documentaries","17")`, `(30026,"Sport","44")`.
- Root menu string ids: Search `30011`, Movies `30012`, TV Shows `30013`.
- Poster URL pattern: `https://cdn.sktorrent.eu/obrazky/<id>.jpg` where `<id>` is the `id=` query value of the `details.php` link.
- TMDB Helper query construction: movies `{title} {year}`, episodes `{showname}` (no season/episode).
- The old flat `CATEGORIES` constant is removed (Task 3). `latest()` stays in code but is not surfaced in the menu.
- All commits use conventional-commit messages.

---

### Task 1: Localization foundation (3 PO files + `settings.localized`)

**Files:**
- Modify: `resources/language/resource.language.en_gb/strings.po`
- Create: `resources/language/resource.language.cs_cz/strings.po`
- Create: `resources/language/resource.language.sk_sk/strings.po`
- Modify: `resources/lib/settings.py`
- Modify: `tests/conftest.py`
- Create: `tests/test_localization.py`
- Test: `tests/test_settings.py`

**Interfaces:**
- Consumes: `xbmcaddon` (stubbed).
- Produces: `settings.localized(string_id: int, fallback: str = "") -> str` — returns the addon's localized string for `string_id`, or `fallback` when Kodi returns an empty string.

- [ ] **Step 1: Extend the conftest `_Addon` stub with `getLocalizedString`**

In `tests/conftest.py`, inside the `_Addon` class (which already has `getSetting`/`setSetting`/`getAddonInfo`), add:

```python
        def getLocalizedString(self, string_id):
            return ""
```

- [ ] **Step 2: Write the failing `settings.localized` test**

Add to `tests/test_settings.py`:

```python
def test_localized_returns_translation_when_present(monkeypatch):
    import xbmcaddon

    monkeypatch.setattr(
        xbmcaddon.Addon,
        "getLocalizedString",
        lambda self, i: "Hledat" if i == 30011 else "",
    )
    assert settings.localized(30011, "Search") == "Hledat"


def test_localized_falls_back_when_empty():
    # Stub getLocalizedString returns "" -> fallback is used.
    assert settings.localized(30012, "Movies") == "Movies"
```

- [ ] **Step 3: Run to verify failure**

Run: `pytest tests/test_settings.py::test_localized_returns_translation_when_present -v`
Expected: FAIL — `AttributeError: module 'resources.lib.settings' has no attribute 'localized'`.

- [ ] **Step 4: Implement `settings.localized`**

Append to `resources/lib/settings.py`:

```python
def localized(string_id, fallback=""):
    text = _addon().getLocalizedString(string_id)
    return text if text else fallback
```

- [ ] **Step 5: Run to verify pass**

Run: `pytest tests/test_settings.py -v`
Expected: PASS (all settings tests).

- [ ] **Step 6: Write the full en_gb `strings.po`** (overwrite the file)

`resources/language/resource.language.en_gb/strings.po`:

```po
msgid ""
msgstr ""
"Content-Type: text/plain; charset=UTF-8\n"
"Language: en_GB\n"

msgctxt "#30001"
msgid "Account"
msgstr ""

msgctxt "#30002"
msgid "Username"
msgstr ""

msgctxt "#30003"
msgid "Password"
msgstr ""

msgctxt "#30005"
msgid "Elementum addon id"
msgstr ""

msgctxt "#30011"
msgid "Search"
msgstr ""

msgctxt "#30012"
msgid "Movies"
msgstr ""

msgctxt "#30013"
msgid "TV Shows"
msgstr ""

msgctxt "#30020"
msgid "CZ/SK dubbing"
msgstr ""

msgctxt "#30021"
msgid "With subtitles"
msgstr ""

msgctxt "#30022"
msgid "Without subtitles"
msgstr ""

msgctxt "#30023"
msgid "Series"
msgstr ""

msgctxt "#30024"
msgid "TV programmes"
msgstr ""

msgctxt "#30025"
msgid "Documentaries"
msgstr ""

msgctxt "#30026"
msgid "Sport"
msgstr ""
```

- [ ] **Step 7: Write the Czech `strings.po`**

`resources/language/resource.language.cs_cz/strings.po`:

```po
msgid ""
msgstr ""
"Content-Type: text/plain; charset=UTF-8\n"
"Language: cs_CZ\n"

msgctxt "#30001"
msgid "Account"
msgstr "Účet"

msgctxt "#30002"
msgid "Username"
msgstr "Uživatelské jméno"

msgctxt "#30003"
msgid "Password"
msgstr "Heslo"

msgctxt "#30005"
msgid "Elementum addon id"
msgstr "ID doplňku Elementum"

msgctxt "#30011"
msgid "Search"
msgstr "Hledat"

msgctxt "#30012"
msgid "Movies"
msgstr "Filmy"

msgctxt "#30013"
msgid "TV Shows"
msgstr "Seriály a pořady"

msgctxt "#30020"
msgid "CZ/SK dubbing"
msgstr "CZ/SK dabing"

msgctxt "#30021"
msgid "With subtitles"
msgstr "S titulky"

msgctxt "#30022"
msgid "Without subtitles"
msgstr "Bez titulků"

msgctxt "#30023"
msgid "Series"
msgstr "Seriály"

msgctxt "#30024"
msgid "TV programmes"
msgstr "TV pořady"

msgctxt "#30025"
msgid "Documentaries"
msgstr "Dokumenty"

msgctxt "#30026"
msgid "Sport"
msgstr "Sport"
```

- [ ] **Step 8: Write the Slovak `strings.po`**

`resources/language/resource.language.sk_sk/strings.po`:

```po
msgid ""
msgstr ""
"Content-Type: text/plain; charset=UTF-8\n"
"Language: sk_SK\n"

msgctxt "#30001"
msgid "Account"
msgstr "Účet"

msgctxt "#30002"
msgid "Username"
msgstr "Používateľské meno"

msgctxt "#30003"
msgid "Password"
msgstr "Heslo"

msgctxt "#30005"
msgid "Elementum addon id"
msgstr "ID doplnku Elementum"

msgctxt "#30011"
msgid "Search"
msgstr "Hľadať"

msgctxt "#30012"
msgid "Movies"
msgstr "Filmy"

msgctxt "#30013"
msgid "TV Shows"
msgstr "Seriály a relácie"

msgctxt "#30020"
msgid "CZ/SK dubbing"
msgstr "CZ/SK dabing"

msgctxt "#30021"
msgid "With subtitles"
msgstr "S titulkami"

msgctxt "#30022"
msgid "Without subtitles"
msgstr "Bez titulkov"

msgctxt "#30023"
msgid "Series"
msgstr "Seriály"

msgctxt "#30024"
msgid "TV programmes"
msgstr "TV relácie"

msgctxt "#30025"
msgid "Documentaries"
msgstr "Dokumenty"

msgctxt "#30026"
msgid "Sport"
msgstr "Šport"
```

- [ ] **Step 9: Write the PO-parity test**

Create `tests/test_localization.py`:

```python
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LANGS = ["en_gb", "cs_cz", "sk_sk"]
EXPECTED_IDS = {
    30001, 30002, 30003, 30005,
    30011, 30012, 30013,
    30020, 30021, 30022, 30023, 30024, 30025, 30026,
}


def _ids(lang):
    path = os.path.join(
        ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
    )
    with open(path, encoding="utf-8") as fh:
        return set(int(m) for m in re.findall(r'msgctxt\s+"#(\d+)"', fh.read()))


def test_all_languages_present():
    for lang in LANGS:
        path = os.path.join(
            ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
        )
        assert os.path.exists(path), "missing %s" % path


def test_all_languages_define_the_same_ids():
    id_sets = {lang: _ids(lang) for lang in LANGS}
    for lang, ids in id_sets.items():
        assert EXPECTED_IDS <= ids, "%s missing ids: %s" % (lang, EXPECTED_IDS - ids)
    # All three files agree on the id set.
    assert id_sets["en_gb"] == id_sets["cs_cz"] == id_sets["sk_sk"]


def test_translations_are_non_empty_for_cs_and_sk():
    # cs/sk must actually translate (msgstr non-empty) every new menu id.
    for lang in ["cs_cz", "sk_sk"]:
        path = os.path.join(
            ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
        )
        with open(path, encoding="utf-8") as fh:
            blocks = fh.read().split("msgctxt ")
        translated = {}
        for block in blocks[1:]:
            m_id = re.search(r'"#(\d+)"', block)
            m_str = re.search(r'msgstr\s+"([^"]*)"', block)
            if m_id and m_str:
                translated[int(m_id.group(1))] = m_str.group(1)
        for sid in (30011, 30012, 30013, 30020, 30021, 30022, 30023, 30024, 30025, 30026):
            assert translated.get(sid), "%s: id %d not translated" % (lang, sid)
```

- [ ] **Step 10: Run the localization + full suite**

Run: `pytest tests/test_localization.py tests/test_settings.py -v`
Expected: PASS.
Run: `pytest -q`
Expected: PASS (whole suite).

- [ ] **Step 11: Commit**

```bash
git add resources/language/ resources/lib/settings.py tests/conftest.py tests/test_localization.py tests/test_settings.py
git commit -m "feat: add cs/sk localization and settings.localized helper"
```

---

### Task 2: Poster image in `parse_listing`

**Files:**
- Modify: `resources/lib/sktorrent.py`
- Test: `tests/test_sktorrent.py`

**Interfaces:**
- Consumes: existing `parse_listing(html)`.
- Produces: each listing dict now also has `"image": str` — `https://cdn.sktorrent.eu/obrazky/<id>.jpg` derived from the detail link's `id=` value, or `""` when no id is present.

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_sktorrent.py`:

```python
def test_parse_listing_includes_poster_image():
    rows = sktorrent.parse_listing(_read("listing.html"))
    assert rows[0]["image"] == (
        "https://cdn.sktorrent.eu/obrazky/"
        "6c33aba4bf8d8cce8bbc53b23d684ce4c1766197.jpg"
    )


def test_parse_listing_image_empty_without_id():
    html = '<table><tr><td><a href="details.php?name=x">X</a></td></tr></table>'
    rows = sktorrent.parse_listing(html)
    assert rows[0]["image"] == ""
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_sktorrent.py::test_parse_listing_includes_poster_image -v`
Expected: FAIL — `KeyError: 'image'`.

- [ ] **Step 3: Implement image extraction**

In `resources/lib/sktorrent.py`, update the import line and add a helper, then set `image` in `parse_listing`.

Change the import at the top from:

```python
from urllib.parse import urljoin, urlencode
```

to:

```python
from urllib.parse import urljoin, urlencode, urlparse, parse_qs
```

Add this helper next to the other module-level helpers (e.g. after `_cell_category`):

```python
def _image_for(detail_url):
    ids = parse_qs(urlparse(detail_url).query).get("id")
    if ids and ids[0]:
        return "https://cdn.sktorrent.eu/obrazky/%s.jpg" % ids[0]
    return ""
```

In `parse_listing`, add the `image` key to the appended dict (alongside the existing keys):

```python
        rows.append(
            {
                "title": title,
                "detail_url": detail_url,
                "size": _first(_SIZE_RE, cell_text),
                "seeders": _int_from(_SEED_RE, cell_text),
                "leechers": _int_from(_LEECH_RE, cell_text),
                "category": _cell_category(cell),
                "image": _image_for(detail_url),
            }
        )
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_sktorrent.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add resources/lib/sktorrent.py tests/test_sktorrent.py
git commit -m "feat: extract poster image url in listing parser"
```

---

### Task 3: Taxonomy + localized menu + group navigation

**Files:**
- Modify: `resources/lib/sktorrent.py`
- Modify: `resources/lib/router.py`
- Test: `tests/test_sktorrent.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: `settings.localized(string_id, fallback)` (Task 1); `sktorrent.MOVIE_CATEGORIES` / `sktorrent.TVSHOW_CATEGORIES`.
- Produces: `sktorrent.MOVIE_CATEGORIES` / `sktorrent.TVSHOW_CATEGORIES` (lists of `(int, str, str)`); router route `action=group&group=movie|tv` → `list_group(params)`; localized `root_menu()`.

- [ ] **Step 1: Replace `CATEGORIES` in `sktorrent.py`**

In `resources/lib/sktorrent.py`, replace the whole `CATEGORIES = [ ... ]` block with:

```python
# (string_id, english_fallback, category_id) — the real sktorrent category ids.
MOVIE_CATEGORIES = [
    (30020, "CZ/SK dubbing", "1"),
    (30021, "With subtitles", "15"),
    (30022, "Without subtitles", "31"),
]
TVSHOW_CATEGORIES = [
    (30023, "Series", "16"),
    (30024, "TV programmes", "42"),
    (30025, "Documentaries", "17"),
    (30026, "Sport", "44"),
]
```

- [ ] **Step 2: Update the sktorrent taxonomy test**

In `tests/test_sktorrent.py`, replace `test_categories_present` with:

```python
def test_movie_categories():
    assert sktorrent.MOVIE_CATEGORIES == [
        (30020, "CZ/SK dubbing", "1"),
        (30021, "With subtitles", "15"),
        (30022, "Without subtitles", "31"),
    ]


def test_tvshow_categories():
    assert sktorrent.TVSHOW_CATEGORIES == [
        (30023, "Series", "16"),
        (30024, "TV programmes", "42"),
        (30025, "Documentaries", "17"),
        (30026, "Sport", "44"),
    ]
```

- [ ] **Step 3: Run sktorrent tests (expect the taxonomy tests pass; router still references old constant — do not run full suite yet)**

Run: `pytest tests/test_sktorrent.py -v`
Expected: PASS (the two new taxonomy tests included).

- [ ] **Step 4: Rewrite `root_menu` and add `list_group` in `router.py`**

In `resources/lib/router.py`, replace the existing `root_menu` function with:

```python
def root_menu():
    xbmcplugin.setContent(_HANDLE, "videos")
    _add_dir(settings.localized(30011, "Search"), build_url(action="search"))
    _add_dir(settings.localized(30012, "Movies"), build_url(action="group", group="movie"))
    _add_dir(settings.localized(30013, "TV Shows"), build_url(action="group", group="tv"))
    xbmcplugin.endOfDirectory(_HANDLE)


def list_group(params):
    group = params.get("group")
    if group == "movie":
        categories = sktorrent.MOVIE_CATEGORIES
    elif group == "tv":
        categories = sktorrent.TVSHOW_CATEGORIES
    else:
        categories = []
    xbmcplugin.setContent(_HANDLE, "videos")
    for string_id, fallback, category_id in categories:
        label = settings.localized(string_id, fallback)
        url = build_url(action="list", mode="browse", category=category_id, page="0")
        _add_dir(label, url)
    xbmcplugin.endOfDirectory(_HANDLE)
```

- [ ] **Step 5: Route the `group` action in `dispatch`**

In `resources/lib/router.py`, in `dispatch`, add a branch for `group` (place it alongside the other `elif` branches, before the final `else: root_menu()`):

```python
    elif action == "group":
        list_group(params)
```

- [ ] **Step 6: Replace the root-menu router test and add group tests**

In `tests/test_router.py`, replace `test_root_menu_renders_search_latest_and_categories` with:

```python
def test_root_menu_renders_search_movies_tvshows(monkeypatch):
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "")

    labels = [label for (_url, label, _folder) in calls]
    assert labels == ["Search", "Movies", "TV Shows"]
    assert all(folder is True for (_url, _label, folder) in calls)


def test_group_movie_lists_three_subcategories(monkeypatch):
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "?action=group&group=movie")

    labels = [label for (_url, label, _folder) in calls]
    assert labels == ["CZ/SK dubbing", "With subtitles", "Without subtitles"]
    # Category ids wired into the drill-down URLs.
    urls = [url for (url, _label, _folder) in calls]
    assert "category=1" in urls[0] and "mode=browse" in urls[0]
    assert "category=15" in urls[1]
    assert "category=31" in urls[2]


def test_group_tv_lists_four_subcategories(monkeypatch):
    calls = _record_add_dir(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "?action=group&group=tv")

    labels = [label for (_url, label, _folder) in calls]
    assert labels == ["Series", "TV programmes", "Documentaries", "Sport"]
    assert "category=16" in [u for (u, _l, _f) in calls][0]


def test_group_unknown_renders_empty(monkeypatch):
    calls = _record_add_dir(monkeypatch)
    ended = _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "?action=group&group=bogus")

    assert calls == []
    assert ended["count"] == 1
```

> Note: the `group` action needs no credentials gate (it renders a static
> submenu with no network calls). The `dispatch` credential check only fires
> for `action in (None, "root")`, so these tests do not stub credentials.

- [ ] **Step 7: Run the full suite**

Run: `pytest -q`
Expected: PASS (all tests). If any test still references `sktorrent.CATEGORIES`, it is a leftover — fix it to use the new constants.

- [ ] **Step 8: Commit**

```bash
git add resources/lib/sktorrent.py resources/lib/router.py tests/test_sktorrent.py tests/test_router.py
git commit -m "feat: localized Movies/TV Shows menu with grouped subcategories"
```

---

### Task 4: Enrich listing rendering (poster grid + art + info)

**Files:**
- Modify: `resources/lib/router.py`
- Test: `tests/test_router.py`

**Interfaces:**
- Consumes: listing dicts with `image` (Task 2); `settings` (already imported).
- Produces: `_render_torrents` sets content type `movies`, art from `image`, and a `plot` InfoLabel with size/seeders/leechers/category.

- [ ] **Step 1: Add `image` to the router test row helper**

In `tests/test_router.py`, update `_fake_row` to include an image:

```python
def _fake_row(title, detail_url):
    return {
        "title": title,
        "detail_url": detail_url,
        "size": "1.4 GB",
        "seeders": 10,
        "leechers": 2,
        "category": "Filmy",
        "image": "https://cdn.sktorrent.eu/obrazky/deadbeef.jpg",
    }
```

- [ ] **Step 2: Write the failing rendering test**

Add to `tests/test_router.py`:

```python
def _record_add_dir_items(monkeypatch):
    """Record (url, ListItem, isFolder) so art/info can be asserted."""
    import xbmcplugin

    items = []
    monkeypatch.setattr(
        xbmcplugin,
        "addDirectoryItem",
        lambda handle, url, li, isFolder=True: items.append((url, li, isFolder)),
    )
    return items


def _record_content(monkeypatch):
    import xbmcplugin

    seen = {}
    monkeypatch.setattr(
        xbmcplugin, "setContent", lambda handle, ctype: seen.update(content=ctype)
    )
    return seen


def test_render_sets_poster_art_and_info(monkeypatch):
    monkeypatch.setattr(router.settings, "has_credentials", lambda: True)
    monkeypatch.setattr(router.settings, "get_credentials", lambda: ("u", "p"))
    _record_save_cookies(monkeypatch)
    _install_fake_client(monkeypatch, [_fake_row("Movie A", "https://sktorrent.eu/torrent/details.php?id=1")])
    items = _record_add_dir_items(monkeypatch)
    content = _record_content(monkeypatch)
    _record_end_of_directory(monkeypatch)

    router.dispatch(BASE, 5, "?action=list&mode=latest&page=0")

    # Poster-grid content type.
    assert content["content"] == "movies"
    # First item is the playable torrent, with art + info from the row.
    _url, li, is_folder = items[0]
    assert is_folder is False
    assert li._props["art"]["poster"] == "https://cdn.sktorrent.eu/obrazky/deadbeef.jpg"
    plot = li._info["video"]["plot"]
    assert "1.4 GB" in plot and "10" in plot and "2" in plot and "Filmy" in plot
```

> This uses `li._props`/`li._info` from the conftest `_ListItem` stub, whose
> `setArt` stores into `_props["art"]` and `setInfo` into `_info[kind]`.

- [ ] **Step 3: Run to verify failure**

Run: `pytest tests/test_router.py::test_render_sets_poster_art_and_info -v`
Expected: FAIL — content is not `movies` and/or no art set (current `_render_torrents` sets `content` to `videos` and no art).

- [ ] **Step 4: Rewrite `_render_torrents`**

In `resources/lib/router.py`, replace the existing `_render_torrents` with:

```python
def _render_torrents(rows, next_url):
    xbmcplugin.setContent(_HANDLE, "movies")
    for row in rows:
        list_item = xbmcgui.ListItem(label=row["title"])
        plot = "%s | Seeders: %d | Leechers: %d | %s" % (
            row.get("size", ""),
            row.get("seeders", 0),
            row.get("leechers", 0),
            row.get("category", ""),
        )
        list_item.setInfo("video", {"title": row["title"], "plot": plot})
        image = row.get("image", "")
        if image:
            list_item.setArt(
                {"thumb": image, "poster": image, "icon": image, "fanart": image}
            )
        list_item.setProperty("IsPlayable", "true")
        play_url = build_url(
            action="play", detail_url=row["detail_url"], name=row["title"]
        )
        xbmcplugin.addDirectoryItem(_HANDLE, play_url, list_item, isFolder=False)
    if next_url:
        _add_dir("Next page >>", next_url)
    xbmcplugin.endOfDirectory(_HANDLE)
```

- [ ] **Step 5: Run to verify pass**

Run: `pytest tests/test_router.py -v`
Expected: PASS (new test plus all existing router tests — the existing list/search tests still render rows; `_fake_row` now carries `image`).

- [ ] **Step 6: Run the full suite**

Run: `pytest -q`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add resources/lib/router.py tests/test_router.py
git commit -m "feat: render results as poster grid with art and info"
```

---

### Task 5: TMDB Helper player + README

**Files:**
- Create: `resources/tmdbhelper/sktorrent.json`
- Create: `tests/test_tmdbhelper_player.py`
- Modify: `README.md`

**Interfaces:**
- Consumes: the existing `action=search&query=...` route.
- Produces: `resources/tmdbhelper/sktorrent.json` — a TMDB Helper player targeting `plugin.video.sktorrent`.

- [ ] **Step 1: Write the failing validity test**

Create `tests/test_tmdbhelper_player.py`:

```python
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLAYER = os.path.join(ROOT, "resources", "tmdbhelper", "sktorrent.json")


def _load():
    with open(PLAYER, encoding="utf-8") as fh:
        return json.load(fh)


def test_player_is_valid_json_for_our_plugin():
    data = _load()
    assert data["plugin"] == "plugin.video.sktorrent"
    assert data["name"]
    assert data["is_resolvable"] == "true"


def test_player_defines_all_four_functions():
    data = _load()
    for fn in ("play_movie", "search_movie", "play_episode", "search_episode"):
        assert isinstance(data.get(fn), list) and data[fn], "%s missing/empty" % fn
        assert data[fn][0].startswith("plugin://plugin.video.sktorrent/?action=search")


def test_player_query_tokens():
    data = _load()
    assert "{title} {year}" in data["play_movie"][0]
    assert "{title} {year}" in data["search_movie"][0]
    assert "{showname}" in data["play_episode"][0]
    assert "{showname}" in data["search_episode"][0]


def test_player_assert_block():
    data = _load()
    assert data["assert"]["play_movie"] == ["title", "year"]
    assert data["assert"]["search_movie"] == ["title", "year"]
    assert data["assert"]["play_episode"] == ["showname"]
    assert data["assert"]["search_episode"] == ["showname"]
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_tmdbhelper_player.py -v`
Expected: FAIL — `FileNotFoundError` (player json does not exist yet).

- [ ] **Step 3: Create the player JSON**

`resources/tmdbhelper/sktorrent.json`:

```json
{
    "name": "SKTorrent",
    "plugin": "plugin.video.sktorrent",
    "priority": 200,
    "is_resolvable": "true",
    "assert": {
        "play_movie":     ["title", "year"],
        "search_movie":   ["title", "year"],
        "play_episode":   ["showname"],
        "search_episode": ["showname"]
    },
    "play_movie":     ["plugin://plugin.video.sktorrent/?action=search&query={title} {year}"],
    "search_movie":   ["plugin://plugin.video.sktorrent/?action=search&query={title} {year}"],
    "play_episode":   ["plugin://plugin.video.sktorrent/?action=search&query={showname}"],
    "search_episode": ["plugin://plugin.video.sktorrent/?action=search&query={showname}"]
}
```

- [ ] **Step 4: Run to verify pass**

Run: `pytest tests/test_tmdbhelper_player.py -v`
Expected: PASS (4 tests).

- [ ] **Step 5: Document TMDB Helper integration in `README.md`**

Append this section to `README.md` (before the `## Development` section):

````markdown
## TMDB Helper integration

This addon ships a player file for
[TMDB Helper](https://github.com/jurialmunkey/plugin.video.themoviedb.helper).

Copy `resources/tmdbhelper/sktorrent.json` into TMDB Helper's players folder:

```
<Kodi userdata>/addon_data/plugin.video.themoviedb.helper/players/sktorrent.json
```

(On most systems `<Kodi userdata>` is `~/.kodi/userdata` on Linux,
`%APPDATA%\Kodi\userdata` on Windows, or
`~/Library/Application Support/Kodi/userdata` on macOS.)

Then, on a movie or episode in TMDB Helper, choose **Play** / **Search** and
pick **SKTorrent**. It searches sktorrent (movies by title + year, episodes by
show title), lists the matching releases, and streams the one you pick via
Elementum.
````

- [ ] **Step 6: Run the full suite**

Run: `pytest -q`
Expected: PASS (whole suite).

- [ ] **Step 7: Commit**

```bash
git add resources/tmdbhelper/sktorrent.json tests/test_tmdbhelper_player.py README.md
git commit -m "feat: add TMDB Helper player and integration docs"
```

---

### Task 6: Live verification of the search route used by TMDB Helper

**Files:**
- None (verification only; uses the existing git-excluded `creds.local` and `tools/` diagnostic).

**Interfaces:**
- Consumes: `resources.lib.sktorrent` and the corrected search route.

- [ ] **Step 1: Confirm the TMDB-Helper-style query works against the live site**

The player calls `action=search&query={title} {year}`. Confirm a title+year query returns results through the real module (requires `creds.local` to be present with valid credentials). Run:

```bash
python3 tools/verify_playflow.py "Matrix 1999"
```

Expected: `login() -> True`, `search('Matrix 1999') -> N rows` with N ≥ 1, a `/torrent/` download URL, and a well-formed `magnet:?xt=urn:btih:...`. Ends with `ALL STEPS PASSED`.

> If `creds.local` is absent (e.g. it was deleted), this step is skipped —
> note that in the report and rely on the unit tests plus the earlier live
> verification of the search route.

- [ ] **Step 2: Record the manual (in-Kodi) verification checklist**

These cannot be automated outside Kodi; record them as follow-ups in the task report:

1. Install the addon and TMDB Helper + Elementum in Kodi.
2. Set sktorrent credentials in the addon settings; switch Kodi language to Czech and Slovak and confirm the menu labels change (Filmy / Seriály a pořady / S titulky, etc.).
3. Root menu shows only **Search**, **Movies**, **TV Shows**; Movies has 3 subcategories, TV Shows has 4; each opens a poster grid with artwork.
4. Copy `sktorrent.json` into TMDB Helper's players folder; on a movie choose **SKTorrent** → results list appears → pick one → Elementum streams. Repeat for a TV episode (searches by show title only).

- [ ] **Step 3: No commit** (verification only — nothing to commit unless a defect is found and fixed under systematic-debugging).

---

## Notes

- Kodi auto-discovers `resources/language/resource.language.*`, so `addon.xml`
  needs no change for the new languages.
- The `group` submenu makes no network calls and needs no credentials; only
  the search/list/play actions require login.
- The TMDB Helper → player → Elementum hand-off is only fully verifiable inside
  Kodi (Task 6, Step 2).
