# Movies/TV taxonomy, localization, images & TMDB Helper — Design

**Date:** 2026-07-11
**Status:** Approved
**Builds on:** plugin.video.sktorrent (existing addon)

## Purpose

Make the addon more user-friendly and integrate it with TMDB Helper:

1. Restructure the menu to just **Search**, **Movies** (3 subcategories), and
   **TV Shows** (4 subcategories); drop music/games/apps/etc.
2. Localize every menu label in **three languages**: English (en_gb),
   Czech (cs_cz), Slovak (sk_sk). Labels are context-aware (subcategories do
   not repeat their parent group name).
3. Render results as a **poster grid** with artwork and structured info
   (size · seeders/leechers · category).
4. Ship a **TMDB Helper player** (`sktorrent.json`) so movies/episodes picked
   in TMDB Helper can be streamed from sktorrent via Elementum (browse & pick).

## Scope

In scope: menu restructure, localization (3 languages), poster/art rendering,
TMDB Helper player JSON + docs, tests.

Out of scope (YAGNI): auto-installing the TMDB Helper player, additional
languages beyond en/cs/sk, exposing "Latest" in the menu (the `latest()`
client method stays but is no longer surfaced), non-Elementum playback.

## Menu structure

Root menu (localized):

- **Search** (id 30011) — prompt, searches all categories (existing
  `action=search`, unchanged).
- **Movies** (id 30012) — folder → `action=group&group=movie`.
- **TV Shows** (id 30013) — folder → `action=group&group=tv`.

`action=group` lists the group's subcategories as folders; each drills into the
existing paginated list via `action=list&mode=browse&category=<id>`.

### Taxonomy (source of truth in `sktorrent.py`)

Each entry is `(string_id, english_fallback, category_id)`:

```python
MOVIE_CATEGORIES = [
    (30020, "CZ/SK dubbing", "1"),
    (30021, "With subtitles", "15"),
    (30022, "Without subtitles", "31"),
]
TVSHOW_CATEGORIES = [
    (30023, "Series", "16"),
    (30024, "TV programmes", "42"),
    (30025, "Documentaries", "17"),
    (30026, "Sport", "44"),
]
```

The old flat `CATEGORIES` constant is removed. `latest()` remains but is not
surfaced in the menu.

## Localization

Three `strings.po` files under `resources/language/`:
`resource.language.en_gb`, `resource.language.cs_cz`, `resource.language.sk_sk`.
Each contains the full set of ids. Labels are resolved in the router via a
helper `L(string_id, fallback)` that calls
`xbmcaddon.Addon().getLocalizedString(string_id)` and returns the fallback when
Kodi yields an empty string (missing id / not loaded in tests).

| id | en_gb | cs_cz | sk_sk |
|----|-------|-------|-------|
| 30001 | Account | Účet | Účet |
| 30002 | Username | Uživatelské jméno | Používateľské meno |
| 30003 | Password | Heslo | Heslo |
| 30005 | Elementum addon id | ID doplňku Elementum | ID doplnku Elementum |
| 30011 | Search | Hledat | Hľadať |
| 30012 | Movies | Filmy | Filmy |
| 30013 | TV Shows | Seriály a pořady | Seriály a relácie |
| 30020 | CZ/SK dubbing | CZ/SK dabing | CZ/SK dabing |
| 30021 | With subtitles | S titulky | S titulkami |
| 30022 | Without subtitles | Bez titulků | Bez titulkov |
| 30023 | Series | Seriály | Seriály |
| 30024 | TV programmes | TV pořady | TV relácie |
| 30025 | Documentaries | Dokumenty | Dokumenty |
| 30026 | Sport | Sport | Šport |

The in-code fallback strings equal the en_gb column.

## Images & structured results

Every sktorrent row exposes a poster at
`https://cdn.sktorrent.eu/obrazky/<id>.jpg`, where `<id>` is the torrent id from
the `details.php?...&id=<id>` link (also the info-hash). `parse_listing` adds an
`image` key per row, derived from that id (empty string if no id is parseable).

`router._render_torrents` then:
- calls `xbmcplugin.setContent(handle, "movies")` so skins show a poster grid,
- sets `ListItem` art `{"thumb", "poster", "icon", "fanart"}` to `image`,
- sets video InfoLabels: `title` = row title, `plot` = a line combining size,
  seeders/leechers, and category,
- keeps a readable label (title).

The listing dict becomes:
`{title, detail_url, size, seeders, leechers, category, image}`.

## TMDB Helper player

File: `resources/tmdbhelper/sktorrent.json`. Directory-style, browse & pick.
Both play and search functions open the sktorrent search results list; the user
picks a release, which resolves through the existing `action=play` → Elementum
path. Query construction: **movies = `{title} {year}`, episodes = `{showname}`**
(show title only, no season/episode).

```json
{
  "name": "SKTorrent",
  "plugin": "plugin.video.sktorrent",
  "priority": 200,
  "is_resolvable": "true",
  "assert": {
    "play_movie":     ["title", "year"],
    "search_movie":   ["title", "year"],
    "play_episode":   ["showname"],
    "search_episode": ["showname"]
  },
  "play_movie":     ["plugin://plugin.video.sktorrent/?action=search&query={title} {year}"],
  "search_movie":   ["plugin://plugin.video.sktorrent/?action=search&query={title} {year}"],
  "play_episode":   ["plugin://plugin.video.sktorrent/?action=search&query={showname}"],
  "search_episode": ["plugin://plugin.video.sktorrent/?action=search&query={showname}"]
}
```

It reuses `action=search&query=…` (no prompt when `query` is present).

**Delivery:** shipped in-repo; the README documents copying it to
`<Kodi userdata>/addon_data/plugin.video.themoviedb.helper/players/sktorrent.json`.

## Components changed

- `resources/lib/sktorrent.py` — replace `CATEGORIES` with `MOVIE_CATEGORIES`
  / `TVSHOW_CATEGORIES`; add `image` to `parse_listing`.
- `resources/lib/router.py` — localized root menu; new `group` action; enrich
  `_render_torrents` with content type, art, and info.
- `resources/language/resource.language.{en_gb,cs_cz,sk_sk}/strings.po` — full
  localized string sets.
- `resources/tmdbhelper/sktorrent.json` — new player file.
- `README.md` — TMDB Helper install section.
- `addon.xml` — declare cs_cz/sk_sk language assets if needed (Kodi
  auto-discovers `resources/language/*`, so no change strictly required).

## Error handling

- Missing localized string → in-code fallback (English) via `L()`.
- Missing/absent poster → art simply unset by Kodi (a `.jpg` that 404s shows no
  image; not an error).
- Unknown `group` value → render an empty directory, no crash.
- Existing search/list/play error handling (log + notify + graceful end)
  is unchanged.

## Testing

- `sktorrent.py`: `MOVIE_CATEGORIES` has exactly the 3 expected `(id, label,
  cat)` tuples and `TVSHOW_CATEGORIES` the 4; `parse_listing` returns the
  correct `image` URL derived from the row id (and `""` when absent).
- `router.py`: root menu renders exactly Search/Movies/TV Shows (localized via a
  `getLocalizedString` stub); `action=group&group=movie` lists the 3 movie
  subcategories with correct category URLs; `group=tv` lists the 4; unknown
  group → empty; `_render_torrents` sets content=movies, art from `image`, and
  the info `plot`.
- Localization: a test asserts all three `strings.po` files parse and define the
  same set of msgctxt ids (no missing translations).
- TMDB Helper: a test asserts `sktorrent.json` is valid JSON, targets
  `plugin.video.sktorrent`, includes the four functions and an `assert` block,
  and uses the `{title}`/`{year}`/`{showname}` tokens as specified.
- Test harness: extend the conftest `_Addon` stub with `getLocalizedString`.

## Verification note

Menus, taxonomy, image parsing, localization completeness, and JSON validity are
covered by tests and the live site. The end-to-end TMDB Helper → player →
Elementum hand-off can only be fully confirmed inside Kodi with TMDB Helper and
Elementum installed; this is called out for manual verification.
