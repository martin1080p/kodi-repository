"""URL routing and directory building for plugin.video.sktorrent."""
import sys
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import sktorrent
from resources.lib import torrent
from resources.lib import player
from resources.lib import settings

_BASE_URL = ""
_HANDLE = -1


def build_url(**params):
    return _BASE_URL + "?" + urlencode(params)


def _notify(message):
    xbmcgui.Dialog().notification("SKTorrent", message)


def _client():
    username, password = settings.get_credentials()
    client = sktorrent.SkTorrent(username, password)
    client.load_cookies(settings.load_cookies())
    return client


def _persist(client):
    try:
        settings.save_cookies(client.dump_cookies())
    except Exception:
        pass


def root_menu():
    xbmcplugin.setContent(_HANDLE, "videos")
    _add_dir(settings.localized(30011, "Search"), build_url(action="search"))
    _add_dir(settings.localized(30012, "Movies"), build_url(action="group", group="movie"))
    _add_dir(settings.localized(30013, "TV Shows"), build_url(action="group", group="tv"))
    xbmcplugin.endOfDirectory(_HANDLE)


def list_group(params):
    group = params.get("group")
    if group == "movie":
        categories = sktorrent.MOVIE_CATEGORIES
    elif group == "tv":
        categories = sktorrent.TVSHOW_CATEGORIES
    else:
        categories = []
    xbmcplugin.setContent(_HANDLE, "videos")
    for string_id, fallback, category_id in categories:
        label = settings.localized(string_id, fallback)
        url = build_url(action="list", mode="browse", category=category_id, page="0")
        _add_dir(label, url)
    xbmcplugin.endOfDirectory(_HANDLE)


def _add_dir(label, url):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=True)


def _render_torrents(rows, next_url):
    xbmcplugin.setContent(_HANDLE, "movies")
    for row in rows:
        list_item = xbmcgui.ListItem(label=row["title"])
        plot = "%s | Seeders: %d | Leechers: %d | %s" % (
            row.get("size", ""),
            row.get("seeders", 0),
            row.get("leechers", 0),
            row.get("category", ""),
        )
        list_item.setInfo("video", {"title": row["title"], "plot": plot})
        image = row.get("image", "")
        if image:
            list_item.setArt(
                {"thumb": image, "poster": image, "icon": image, "fanart": image}
            )
        list_item.setProperty("IsPlayable", "true")
        play_url = build_url(
            action="play", detail_url=row["detail_url"], name=row["title"]
        )
        xbmcplugin.addDirectoryItem(_HANDLE, play_url, list_item, isFolder=False)
    if next_url:
        _add_dir("Next page >>", next_url)
    xbmcplugin.endOfDirectory(_HANDLE)


def list_torrents(params):
    mode = params.get("mode", "latest")
    page = int(params.get("page", "0"))
    client = _client()
    try:
        if mode == "browse":
            category = params.get("category", "")
            rows = client.browse(category, page)
            next_url = build_url(
                action="list", mode="browse", category=category, page=str(page + 1)
            )
        else:
            rows = client.latest(page)
            next_url = build_url(action="list", mode="latest", page=str(page + 1))
    except Exception as exc:  # noqa: BLE001 - surface to user, keep addon alive
        xbmc.log("plugin.video.sktorrent list error: %s" % exc, xbmc.LOGERROR)
        _notify("Could not load torrents")
        xbmcplugin.endOfDirectory(_HANDLE)
        return
    finally:
        _persist(client)
    _render_torrents(rows, next_url if rows else None)


def do_search(params):
    query = params.get("query")
    if not query:
        query = xbmcgui.Dialog().input("Search sktorrent.eu")
        if not query:
            xbmcplugin.endOfDirectory(_HANDLE)
            return
    page = int(params.get("page", "0"))
    client = _client()
    try:
        rows = client.search(query, page)
    except Exception as exc:  # noqa: BLE001
        xbmc.log("plugin.video.sktorrent search error: %s" % exc, xbmc.LOGERROR)
        _notify("Search failed")
        xbmcplugin.endOfDirectory(_HANDLE)
        return
    finally:
        _persist(client)
    next_url = build_url(action="search", query=query, page=str(page + 1))
    _render_torrents(rows, next_url if rows else None)


def play_torrent(params):
    detail_url = params.get("detail_url")
    name = params.get("name", "")
    client = _client()
    try:
        download_url = client.resolve_download_url(detail_url)
        magnet = torrent.magnet_from_torrent_url(getattr(client, "session", None), download_url)
    except Exception as exc:  # noqa: BLE001
        xbmc.log("plugin.video.sktorrent play error: %s" % exc, xbmc.LOGERROR)
        _notify("Could not resolve torrent")
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return
    finally:
        _persist(client)
    player.play(_HANDLE, magnet, name)


def dispatch(base_url, handle, query_string):
    global _BASE_URL, _HANDLE
    _BASE_URL = base_url
    _HANDLE = handle
    params = dict(parse_qsl(query_string.lstrip("?")))
    action = params.get("action")

    if action in (None, "root") and not settings.has_credentials():
        _notify("Set your sktorrent.eu username and password in settings")
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    if action == "search":
        do_search(params)
    elif action == "list":
        list_torrents(params)
    elif action == "play":
        play_torrent(params)
    elif action == "group":
        list_group(params)
    else:
        root_menu()


def run():
    base_url = sys.argv[0]
    handle = int(sys.argv[1])
    query_string = sys.argv[2] if len(sys.argv) > 2 else ""
    dispatch(base_url, handle, query_string)
