import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LANGS = ["en_gb", "cs_cz", "sk_sk"]
EXPECTED_IDS = {
    30001, 30002, 30003, 30005,
    30011, 30012, 30013,
    30020, 30021, 30022, 30023, 30024, 30025, 30026,
}


def _ids(lang):
    path = os.path.join(
        ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
    )
    with open(path, encoding="utf-8") as fh:
        return set(int(m) for m in re.findall(r'msgctxt\s+"#(\d+)"', fh.read()))


def test_all_languages_present():
    for lang in LANGS:
        path = os.path.join(
            ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
        )
        assert os.path.exists(path), "missing %s" % path


def test_all_languages_define_the_same_ids():
    id_sets = {lang: _ids(lang) for lang in LANGS}
    for lang, ids in id_sets.items():
        assert EXPECTED_IDS <= ids, "%s missing ids: %s" % (lang, EXPECTED_IDS - ids)
    # All three files agree on the id set.
    assert id_sets["en_gb"] == id_sets["cs_cz"] == id_sets["sk_sk"]


def test_translations_are_non_empty_for_cs_and_sk():
    # cs/sk must actually translate (msgstr non-empty) every new menu id.
    for lang in ["cs_cz", "sk_sk"]:
        path = os.path.join(
            ROOT, "resources", "language", "resource.language.%s" % lang, "strings.po"
        )
        with open(path, encoding="utf-8") as fh:
            blocks = fh.read().split("msgctxt ")
        translated = {}
        for block in blocks[1:]:
            m_id = re.search(r'"#(\d+)"', block)
            m_str = re.search(r'msgstr\s+"([^"]*)"', block)
            if m_id and m_str:
                translated[int(m_id.group(1))] = m_str.group(1)
        for sid in (30011, 30012, 30013, 30020, 30021, 30022, 30023, 30024, 30025, 30026):
            assert translated.get(sid), "%s: id %d not translated" % (lang, sid)
