from resources.lib import settings


def test_defaults_from_stub(monkeypatch):
    # Stub Addon defaults: empty creds, default elementum id.
    assert settings.elementum_id() == "plugin.video.elementum"
    assert settings.has_credentials() is False


def test_has_credentials_true_when_set():
    import xbmcaddon

    addon = xbmcaddon.Addon()
    addon.setSetting("username", "alice")
    addon.setSetting("password", "secret")
    assert settings.has_credentials() is True
    assert settings.get_credentials() == ("alice", "secret")
    # reset so other tests are not affected
    addon.setSetting("username", "")
    addon.setSetting("password", "")


def test_load_cookies_empty_when_no_file(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "_profile_dir", lambda: str(tmp_path))
    assert settings.load_cookies() == {}


def test_save_and_load_cookies_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "_profile_dir", lambda: str(tmp_path))
    settings.save_cookies({"uid": "abc"})
    assert settings.load_cookies() == {"uid": "abc"}


def test_load_cookies_empty_when_file_has_garbage(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "_profile_dir", lambda: str(tmp_path))
    cookie_file = tmp_path / "session_cookies.pkl"
    cookie_file.write_bytes(b"not a pickle at all")
    assert settings.load_cookies() == {}


def test_localized_returns_translation_when_present(monkeypatch):
    import xbmcaddon

    monkeypatch.setattr(
        xbmcaddon.Addon,
        "getLocalizedString",
        lambda self, i: "Hledat" if i == 30011 else "",
    )
    assert settings.localized(30011, "Search") == "Hledat"


def test_localized_falls_back_when_empty():
    # Stub getLocalizedString returns "" -> fallback is used.
    assert settings.localized(30012, "Movies") == "Movies"
