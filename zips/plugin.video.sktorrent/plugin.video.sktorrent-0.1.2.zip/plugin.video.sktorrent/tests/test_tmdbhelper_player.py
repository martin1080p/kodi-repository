import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLAYER = os.path.join(ROOT, "resources", "tmdbhelper", "sktorrent.json")


def _load():
    with open(PLAYER, encoding="utf-8") as fh:
        return json.load(fh)


def test_player_is_valid_json_for_our_plugin():
    data = _load()
    assert data["plugin"] == "plugin.video.sktorrent"
    assert data["name"]
    assert data["is_resolvable"] == "true"


def test_player_defines_all_four_functions():
    data = _load()
    for fn in ("play_movie", "search_movie", "play_episode", "search_episode"):
        assert isinstance(data.get(fn), list) and data[fn], "%s missing/empty" % fn
        assert data[fn][0].startswith("plugin://plugin.video.sktorrent/?action=search")


def test_player_query_tokens():
    data = _load()
    assert "{title} {year}" in data["play_movie"][0]
    assert "{title} {year}" in data["search_movie"][0]
    assert "{showname}" in data["play_episode"][0]
    assert "{showname}" in data["search_episode"][0]


def test_player_assert_block():
    data = _load()
    assert data["assert"]["play_movie"] == ["title", "year"]
    assert data["assert"]["search_movie"] == ["title", "year"]
    assert data["assert"]["play_episode"] == ["showname"]
    assert data["assert"]["search_episode"] == ["showname"]
