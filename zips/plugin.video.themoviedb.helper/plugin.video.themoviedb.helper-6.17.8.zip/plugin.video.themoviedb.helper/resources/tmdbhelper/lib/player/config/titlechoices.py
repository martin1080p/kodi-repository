"""Remembered {ask_<lang>_<route>} title picks, per tmdb_type/tmdb_id/language."""
from tmdbhelper.lib.files.futils import get_json_filecache, set_json_filecache
from tmdbhelper.lib.addon.consts import PLAYERS_TITLE_CHOICES_FILENAME


def _load():
    return get_json_filecache(PLAYERS_TITLE_CHOICES_FILENAME) or {}


def _save(data):
    set_json_filecache(data, PLAYERS_TITLE_CHOICES_FILENAME, 0)


def get_title_choice(tmdb_type, tmdb_id, language):
    return _load().get(tmdb_type, {}).get(f'{tmdb_id}', {}).get(language)


def set_title_choice(tmdb_type, tmdb_id, language, choice):
    data = _load()
    data.setdefault(tmdb_type, {}).setdefault(f'{tmdb_id}', {})[language] = choice
    _save(data)


def forget_title_choice(tmdb_type, tmdb_id):
    """Drop all remembered picks for the item. Returns True if any existed."""
    data = _load()
    if not data.get(tmdb_type, {}).pop(f'{tmdb_id}', None):
        return False
    _save(data)
    return True
