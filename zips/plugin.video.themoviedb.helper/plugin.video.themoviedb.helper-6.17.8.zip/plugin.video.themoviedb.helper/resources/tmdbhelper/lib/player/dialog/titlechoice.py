class PlayerCancelledError(Exception):
    """Raised when the user cancels a player-time selection dialog."""


CHOICES = ('alt', 'default')  # stored remembered picks, same order as candidates


def resolve_title_choice(default_value, alt_value, select_func, remembered=None, remember_func=None, remember_suffix=''):
    """Return the title to search with.

    default_value: the default (English/original) title.
    alt_value:     the alternate-language (e.g. Czech) title, or falsy if none.
    select_func:   callable(candidates: list[str]) -> int chosen index; a
                   negative index or None signals cancel.
    remembered:    'alt' or 'default' to skip the dialog with a stored pick.
    remember_func: callable(choice) storing the pick; when given, the dialog
                   adds "<title>  (<remember_suffix>)" rows that call it.

    If there is no distinct alternate, returns default_value without prompting.
    Raises PlayerCancelledError if the user cancels.
    """
    if not alt_value or alt_value == default_value:
        return default_value

    candidates = [alt_value, default_value]  # alternate (Czech) listed first
    if remembered in CHOICES:
        return candidates[CHOICES.index(remembered)]

    labels = list(candidates)
    if remember_func:
        labels += [f'{i}  ({remember_suffix})' for i in candidates]
    index = select_func(labels)
    if index is None or index < 0 or index >= len(labels):
        raise PlayerCancelledError()
    if index >= len(candidates):
        index -= len(candidates)
        remember_func(CHOICES[index])
    return candidates[index]
