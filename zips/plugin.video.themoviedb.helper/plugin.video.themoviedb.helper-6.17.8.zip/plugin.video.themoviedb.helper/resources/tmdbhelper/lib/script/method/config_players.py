def set_defaultplayer(set_defaultplayer, **kwargs):
    from tmdbhelper.lib.player.config.default import PlayerDefault
    return PlayerDefault(set_defaultplayer).select()


def set_chosenplayer(set_chosenplayer, **kwargs):
    from tmdbhelper.lib.player.config.chosen import PlayerChosenSet
    return PlayerChosenSet(**kwargs).update()


def forget_title_choice(forget_title_choice, tmdb_type=None, tmdb_id=None, **kwargs):
    from xbmcgui import Dialog
    from tmdbhelper.lib.addon.plugin import get_localized
    from tmdbhelper.lib.player.config.titlechoices import forget_title_choice as forget
    forgotten = forget(tmdb_type, tmdb_id)
    Dialog().notification(forget_title_choice, get_localized(32605 if forgotten else 32606))


def customise_players():
    from tmdbhelper.lib.player.config.customise.menu import PlayerCustomiseDialogMenu
    PlayerCustomiseDialogMenu()
