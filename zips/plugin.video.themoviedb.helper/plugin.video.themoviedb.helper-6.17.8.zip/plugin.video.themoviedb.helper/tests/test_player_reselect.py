"""Player.is_player_failed: a plugin signals rejection via TMDbHelper.PlayerFailed."""
import functools
import importlib.util
import os
import sys
import types

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_PROPS = {}
_PLAYING = []


def _get_property(name, clear_property=False, **kwargs):
    value = _PROPS.get(name, '')
    if clear_property:
        _PROPS.pop(name, None)
    return value


for _name, _attrs in (
    ('jurialmunkey.ftools', {'cached_property': functools.cached_property}),
    ('jurialmunkey.window', {'get_property': _get_property}),
    ('tmdbhelper.lib.addon.plugin', {'get_localized': str, 'get_setting': lambda *a: None}),
    ('tmdbhelper.lib.addon.logger', {'kodi_log': lambda *a, **k: None}),
    ('xbmc', {'Player': lambda: types.SimpleNamespace(isPlaying=lambda: bool(_PLAYING))}),
):
    for _pkg in ('jurialmunkey', 'tmdbhelper', 'tmdbhelper.lib', 'tmdbhelper.lib.addon'):
        sys.modules.setdefault(_pkg, types.ModuleType(_pkg))
    _mod = types.ModuleType(_name)
    _mod.__dict__.update(_attrs)
    sys.modules[_name] = _mod

_spec = importlib.util.spec_from_file_location('tmdbplayer', os.path.join(
    _ROOT, 'resources', 'tmdbhelper', 'lib', 'player', 'dialog', 'player.py'))
tmdbplayer = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(tmdbplayer)


def _player():
    player = tmdbplayer.PlayerMovie.__new__(tmdbplayer.PlayerMovie)
    player.xbmc_monitor = types.SimpleNamespace(waitForAbort=lambda t: False)
    return player


def test_failed_property_means_reselect_and_is_cleared():
    _PROPS['PlayerFailed'] = 'true'
    assert _player().is_player_failed() is True
    assert 'PlayerFailed' not in _PROPS


def test_playback_started_means_success():
    _PROPS.clear()
    _PLAYING.append(True)
    try:
        assert _player().is_player_failed() is False
    finally:
        _PLAYING.clear()


def test_timeout_means_success():
    _PROPS.clear()
    assert _player().is_player_failed(timeout=1) is False
