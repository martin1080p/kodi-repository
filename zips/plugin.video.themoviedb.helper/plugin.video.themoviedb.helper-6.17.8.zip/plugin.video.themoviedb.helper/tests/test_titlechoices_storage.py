"""Remembered title picks storage (player/config/titlechoices.py)."""
import importlib.util
import os
import sys
import types

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_STORE = {}

for _name, _attrs in (
    ('tmdbhelper.lib.files.futils', {
        'get_json_filecache': lambda name: _STORE.get(name),
        'set_json_filecache': lambda obj, name, days=14: _STORE.__setitem__(name, obj) if obj else None,
    }),
    ('tmdbhelper.lib.addon.consts', {'PLAYERS_TITLE_CHOICES_FILENAME': 'player_titlechoices'}),
):
    for _pkg in ('tmdbhelper', 'tmdbhelper.lib', 'tmdbhelper.lib.files', 'tmdbhelper.lib.addon'):
        sys.modules.setdefault(_pkg, types.ModuleType(_pkg))
    _mod = types.ModuleType(_name)
    _mod.__dict__.update(_attrs)
    sys.modules[_name] = _mod

_spec = importlib.util.spec_from_file_location('titlechoices', os.path.join(
    _ROOT, 'resources', 'tmdbhelper', 'lib', 'player', 'config', 'titlechoices.py'))
titlechoices = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(titlechoices)


def test_set_get_forget_roundtrip():
    _STORE.clear()
    assert titlechoices.get_title_choice('tv', 1418, 'cs') is None
    titlechoices.set_title_choice('tv', 1418, 'cs', 'alt')
    titlechoices.set_title_choice('movie', 1418, 'cs', 'default')  # same id, other type
    assert titlechoices.get_title_choice('tv', '1418', 'cs') == 'alt'
    assert titlechoices.get_title_choice('movie', 1418, 'cs') == 'default'
    assert titlechoices.forget_title_choice('tv', '1418') is True
    assert titlechoices.get_title_choice('tv', 1418, 'cs') is None
    assert titlechoices.get_title_choice('movie', 1418, 'cs') == 'default'
    assert titlechoices.forget_title_choice('tv', '1418') is False
